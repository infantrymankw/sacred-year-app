(function(){
 if(!window.Capacitor?.isNativePlatform?.())return;
 const plugin=()=>window.Capacitor.Plugins.SacredNotifications;
 let revision=0,authAttached=false;
 const millis=value=>{if(value&&typeof value.toMillis==='function')return value.toMillis();if(value&&Number.isFinite(value.seconds))return value.seconds*1000+Math.floor((value.nanoseconds||0)/1e6);const n=Date.parse(value);return Number.isFinite(n)?n:NaN;};
 async function sync(){
  const version=++revision,fb=window.syFirebase,db=fb?.db,ops=window.syFirebaseOps;
  if(!fb?.auth||!db||!ops)throw new Error('Your Firebase account is still loading. Try again shortly.');
  const currentUser=fb.auth.currentUser;
  if(!currentUser){await plugin().sync({reminders:[]});return 0;}
  const uid=currentUser.uid;
  const entitlement=await window.syGetEntitlements?.();
  if(!entitlement)throw new Error('Your account access is still loading.');
  let rows=[];
  if(entitlement.hall_plus){const result=await ops.getDocs(ops.query(ops.collection(db,'sacred_year_hall_reminders'),ops.where('user_id','==',uid)));rows=result.docs.map(d=>({id:d.id,...d.data()}));}
  // Event RSVPs and event documents are both read directly from Firebase/Firestore.
  const rsvpSnap=await ops.getDocs(ops.query(ops.collection(db,'community_event_rsvps'),ops.where('user_id','==',uid)));
  const rsvpRows=rsvpSnap.docs.map(d=>({id:d.id,...d.data()}));
  const eventIds=[...new Set(rsvpRows.filter(r=>r.status==='interested'||r.status==='going').map(r=>String(r.event_id||'')).filter(Boolean))].slice(0,100);
  const eventRows=[];
  for(const eventId of eventIds){try{const snap=await ops.getDoc(ops.doc(db,'community_events',eventId));if(snap.exists()){const event={id:snap.id,...snap.data()};if(event.status==='approved')eventRows.push(event);}}catch(e){console.warn('Could not sync event reminder',eventId,e?.code||e?.message);}}
  if(version!==revision||fb.auth.currentUser?.uid!==uid)return 0;
  const reminders=rows.filter(r=>r.enabled&&Number.isFinite(millis(r.scheduled_for))).slice(0,100).map(r=>({id:uid+':'+r.id,title:r.title||'Sacred Year reminder',at:millis(r.scheduled_for),repeat:r.recurrence||'none',enabled:true}));
  for(const event of eventRows){const at=millis(event.starts_at);if(Number.isFinite(at)&&at>Date.now())reminders.push({id:uid+':event:'+event.id,title:event.title||'Sacred Year community event',body:'Your saved community event is starting now. Tap to view it.',at,repeat:'none',enabled:true,eventId:event.id});}
  await plugin().sync({reminders});return reminders.length;
 }
 window.syNativeReminderSync=sync;
 window.syNativeNotificationAuthReady=function(){
  if(authAttached||!window.syFirebase?.auth)return;authAttached=true;
  // Firebase Auth state is already observed by the app; sync now and on the app's account observer events.
  setTimeout(()=>sync().catch(()=>{}),0);
 };
 window.syNativeNotificationAuthReady();
 window.syNativeEnableNotifications=window.syEnableNotifications=async function(){
  try{
   const status=await plugin().enable();
   if(!status.granted){alert('Notifications are off. Open Android notification settings for Sacred Year to allow them. Your saved reminders are unchanged.');await paint();return;}
   let text='Android notifications are allowed. Use Test notification to check delivery.';
   try{const count=await sync();text+=count?' Your enabled Hall+ reminders have been copied to this phone.':' You can add a reminder in Hall+ → Advanced Reminders.';}catch(e){text+=' Your saved reminders could not sync yet. Open the app online and tap Enable notifications again.';}
   alert(text);await paint();
  }catch(e){alert(e.message||'Could not enable Android notifications.');}
 };
 window.sy307RequestNotifications=window.syEnableNotifications;
 window.syNativeShowNotification=async function(id,title,body){return await plugin().show({id:String(id||'activity'),title:String(title||'Sacred Year'),body:String(body||'')});};
 window.syNativeTestNotification=async()=>{try{await plugin().test();alert('Test notification sent. Check your Android notification shade.');}catch(e){alert(e.message||'Could not send test notification.');}};
 window.syNativeNotificationSettings=()=>plugin().settings();
 window.syNativeConsumeReminderTap=async()=>{try{const result=await plugin().consumeReminderTap();if(result?.eventId)await window.sy29OpenEvent?.(result.eventId);}catch(e){console.warn('Could not open reminder destination',e?.message||e);}};
 async function paint(){
  const sheet=document.getElementById('sheetContent');if(!sheet)return;
  const text=sheet.textContent||'';
  if(!/Notification Center|Notification settings|Notification Settings|Your Sacred Schedule/.test(text))return;
  sheet.querySelectorAll('button').forEach(b=>{if(/Enable browser alerts|Allow phone\/browser alerts|Enable phone alerts/.test(b.textContent))b.textContent='Enable notifications';});
  sheet.querySelectorAll('p').forEach(p=>{
   if(p.textContent.includes('Browser notification permission:')||p.textContent.includes('Browser notifications unavailable')||p.textContent.includes('Browser notification permission can be enabled'))p.textContent='Android notifications are managed in your phone settings.';
   if(p.textContent.includes('Browser alerts depend on'))p.textContent='Enabled reminders are copied to this phone when you open or update this schedule online. Android may delay alerts to save battery.';
  });
  let box=sheet.querySelector('#syNativeNotificationControls');
  if(!box){box=document.createElement('div');box.id='syNativeNotificationControls';box.className='holiday';box.innerHTML='<p id="syNativeNotificationStatus">Checking Android notification settings…</p><div class="row"><button class="btn secondary" onclick="syNativeTestNotification()">Test notification</button><button class="btn secondary" onclick="syNativeNotificationSettings()">Android notification settings</button></div><p class="note">Saved Hall+ reminders can alert on this phone while the app is closed. Android may delay delivery. Changes made on another device are copied here when you reopen the app online. Creator announcements and community activity are shown in Activity when the app syncs. Creator posts can request closed-app push through the Sacred Year service. Other Community activity appears in Activity when the app syncs.</p>';sheet.appendChild(box);}
  try{const s=await plugin().check();const label=box.querySelector('#syNativeNotificationStatus');if(label)label.textContent=(s.granted?'Android notifications: allowed':'Android notifications: off')+(s.exactAlarms===false?' · Alarms & reminders access: REQUIRED':' · Exact alarms: ready')+(s.lastReminderTrace?' · Last reminder: '+s.lastReminderTrace:'');}catch(e){box.querySelector('#syNativeNotificationStatus').textContent='Could not read Android notification settings.';}
 }
 for(const name of ['syOpenNotifications','syOpenNotificationSettings','sy307Reminders']){const old=window[name];if(old)window[name]=async function(...args){const value=await old.apply(this,args);await paint();return value;};}
 window.syNativeNotificationPaint=paint;
 window.addEventListener('focus',()=>{paint();sync().catch(()=>{});});
 window.addEventListener('load',()=>{window.syEnableNotifications=window.syNativeEnableNotifications;window.sy307RequestNotifications=window.syNativeEnableNotifications;window.syNativeNotificationAuthReady();window.dispatchEvent(new Event('sy-native-notifications-ready'));sync().catch(()=>{});setTimeout(()=>window.syNativeConsumeReminderTap(),900);});
})();
