# Sacred Year notification screen cleanup — v31.47.38

- From the Hall now shows messages and one Notification settings action. The existing drawer Close control is its only exit control.
- Native notification diagnostics, the test action, and alarm access action no longer appear beneath the customer message feed. The internal last-reminder trace is no longer displayed anywhere in the customer settings view.
- Notification preferences use short, customer-facing wording. Phone permission, test notification, and optional exact alarm access remain available in Notification settings.
- RSVPing no longer opens Android Alarms & reminders permission or repeats an explanatory alert. Reminders still sync after RSVP, with Android's inexact scheduling fallback when exact alarm access is unavailable.
- Android versionName 31.47.38, versionCode 26. The prior event visibility and one-hour RSVP reminder changes remain included.

Verification: changed inline JavaScript blocks passed Node syntax checks. Device behavior and customer layout need an Android test build; no Android SDK is available in this workspace.
