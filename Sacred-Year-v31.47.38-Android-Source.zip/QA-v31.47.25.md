# Sacred Year v31.47.25 — Android TEST QA

Built from the exact v31.47.24 Android Source ZIP. Baseline ZIP SHA-256:
`d930a35a7f384f2ce3cfc53fa7082c8b62018bdb4c407fd89d0a51de2c176ff7`
The baseline index.html also matched the v31.47.24 APK byte for byte.

## Requested fixes

| # | Item | Result |
|---|---|---|
| 1 | UID isolation and delayed sync | Fixed client storage scoping, private query ownership checks, delayed-operation cancellation, A→B→A cancellation, account UI reset, and in-memory recording reset. Fixture verified. Ownerless legacy device keys remain untouched and are not imported into any account. Existing cloud data remains in place. Deployed Firebase rules were not supplied or changed. |
| 2 | Community visibility | Fixed visibility/date defaults on new posts and read compatibility for public and approved legacy schemas. Free-account fixture verified. A denied alternate legacy query cannot discard the main public feed. Actual deployed Firebase permissions remain unverified. |
| 3 | Invalid Date | Added handling for missing/invalid values, ISO dates, and Firebase Timestamp forms in affected displays; fixtures pass. |
| 4 | Creator pending posts | Added actual pending/legacy-review count and review queue. Approved posts are excluded from pending count. Fixture verified. |
| 5 | Pending events | Existing pending workflow preserved. Fixture verified pending → approval → public read. |
| 6 | Ritual Save control | Removed inactive Save ritual controls; stored legacy ritual data is retained. |
| 7 | Hávamál study | Seven clickable sections with reading references, context, substantive commentary, reflection questions, and exercises. Completion stays account-specific. Browser verified and mobile layout inspected. |
| 8 | Pending recordings | Creator Activity and dashboard show pending recording counts. Incomplete uploads are excluded. Fixture verified. |
| 9 | Recording moderation | Publish/reject updates reload the manager immediately; actions follow current status. Incomplete uploads cannot be published through the manager. Publish, reject, and republish fixtures pass. |
| 10 | Owner question notifications | Foreground Activity polls while the app is open, routes questions to their recording owner, opens the question, and saves account-specific read status. Enabled/disabled and other-account fixtures pass. Background question push delivery is NOT implemented or verified by this pass. |
| 11 | Android Back | Wired Capacitor Android Back to modal/drawer/view history and root minimize behavior. Nested navigation fixture verified; native bridge dependency/build verified. Physical-device swipe/keyboard behavior still needs device QA. |
| 12 | Login Enter/Done | Login fields handle Enter and expose the keyboard action hint. Browser Enter login fixture passes. Physical Android keyboard Done still needs device QA. |
| 13 | Hall+ entitlement | Preserved sacred_year_entitlements/{uid}.hall_plus_active === true. Free/Hall+ fixture behavior passes. |
| 14 | Firebase audio and microphone | Preserved Firebase Storage adapter, paths, native audio client, and RECORD_AUDIO permission. Android build and native reminder regression checks pass. Real microphone capture/upload/playback was not exercised. Native reminders now clear on account changes. |
| 15 | Stabilization scope | No unrelated feature additions. |

## Checks completed

- All 54 executable inline JavaScript blocks parse.
- Storage/query fixtures: account separation, stale writes, UID document lookup, wrong-owner rejection, public visibility, date normalization, and seven lesson content checks.
- 13 browser scenarios passed with zero page errors. External requests were blocked and Firebase was replaced by in-memory fixtures.
- Native notification regression checks passed; reminder recurrence Java tests passed (monthly anchor, leap year, DST, expiry, weekly).
- Final Android assembleDebug succeeded. Version name 31.47.25, version code 13, same application ID.
- APK bundled index.html matches this source byte for byte. No QA Firebase fixtures are packaged in the APK.
- APK signing certificate matches v31.47.24: SHA-256 `298ccbbd005516cedb36c945faeb030e77d670a1bb58f7882a644b8dcbd79254`.

## Data and installation

No live Firebase reads/writes, test-account edits, migrations, deletion, or device installation were performed. Install this APK as an update to v31.47.24; keep the existing app data. Legacy unscoped local records are deliberately preserved but unavailable in another account's private view. Any future recovery of those records must establish ownership first.

## Build and test source

The archive includes the complete Android/web project and locked npm dependencies. Generated caches, node_modules, build products, local SDK paths, and machine settings are excluded. Use JDK 21, Android SDK 35 and the included Gradle wrapper. In android-project run `npm ci`, configure your SDK path, then run `android/gradlew.bat -p android assembleDebug`. A different machine's default debug certificate will differ; the supplied test APK uses the existing test certificate.

From the archive root: `node qa/check25.cjs` and `node qa/test25.cjs`. For browser fixtures install Playwright locally, then run `node qa/fixture25.cjs` and `node qa/ui25.cjs` (uses installed Microsoft Edge). Test files do not contact Firebase. Build log and browser results are in qa/.

Study commentary is original; the linked reading reference is Benjamin Thorpe's public-domain translation: https://www.gutenberg.org/files/14726/14726-h/14726-h.htm#THE_HIGH_ONES14_LAY
