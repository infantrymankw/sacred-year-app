# Sacred Year notification sweep — v31.47.36

## Confirmed paths
- FCM push: Capacitor PushNotifications -> Firebase token registration -> sacred-year-push-service /api/push -> sacred_year_push channel. This is the path already proven to notify with the app closed for Words from the Hall.
- Local Hall+ reminders: Firestore sacred_year_hall_reminders -> native sync -> AlarmManager -> SacredReminderReceiver -> sacred_year_reminders channel.
- Community event reminders: Firestore community_event_rsvps + community_events -> native sync -> AlarmManager -> SacredReminderReceiver -> sacred_year_push channel. Event alarms are scheduled for event starts_at.
- In-app community activity is not equivalent to closed-app push.

## Root defect found in v31.47.35
The RSVP wrapper called window.syEnsureExactAlarmAccess with optional chaining, but the function was only defined in native-notifications.js. That external file was not loaded by index.html. Therefore the call silently returned undefined and the exact-alarm settings screen never opened. The inline notification code did not define the function.

## v31.47.36 changes
- Define syEnsureExactAlarmAccess in the inline notification runtime actually loaded by the APK.
- Re-sync reminders when Capacitor App reports the app active after returning from Android settings.
- Listen for ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED and reschedule stored alarms immediately.
- Catch exact-alarm SecurityException and retain an inexact fallback instead of losing the reminder.
- Keep POST_NOTIFICATIONS, RECEIVE_BOOT_COMPLETED and SCHEDULE_EXACT_ALARM permissions.
- Keep separate sacred_year_push and sacred_year_reminders channels and the existing FCM registration path.
- Bump Android version to 31.47.36 / versionCode 24.
