# Sacred Year event fix — v31.47.37

- Approved public events stay in the Community Events feed for six hours after their start. Creator Moderation already retained them; the public feed previously filtered them out at the exact start time. Location remains behind the existing 18+ confirmation.
- An interested/going RSVP schedules an Android notification one hour before starts_at. The event start remains the event time. The old alarm at event start is replaced at the next successful reminder sync.
- Events less than one hour away when an RSVP is made do not receive a late notification. Event changes, removal, rejection, and un-RSVP are reflected when the phone next syncs online; this app has no remote alarm update until then.
- Removed the in-memory RSVP set from notification scheduling so an un-RSVP cannot retain a stale alarm after a successful Firestore sync.
- Android versionName 31.47.37 and versionCode 25.

Verification: Node syntax checks passed for the modified inline scripts. Live account visibility and on-device alarm delivery require an Android test with two accounts. This package does not contain Firestore rules, so deployed rules must permit authenticated users to read approved community_events documents.
