package com.alanwolfsie.sacredyear;
import java.util.Calendar;
public final class SacredReminderTime {
    static long next(long start,String repeat,long now){
        if(start>now)return start;
        int field,step=1;
        switch(repeat){case "daily":field=Calendar.DAY_OF_YEAR;break;case "weekly":field=Calendar.DAY_OF_YEAR;step=7;break;case "monthly":field=Calendar.MONTH;break;case "yearly":field=Calendar.YEAR;break;default:return -1;}
        Calendar base=Calendar.getInstance();base.setTimeInMillis(start);
        for(int i=1;i<=40000;i++){Calendar next=(Calendar)base.clone();next.add(field,i*step);if(next.getTimeInMillis()>now)return next.getTimeInMillis();}
        return -1;
    }
}
