package com.alanwolfsie.sacredyear;
import android.Manifest;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.webkit.PermissionRequest;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import com.getcapacitor.Bridge;
import com.getcapacitor.BridgeWebChromeClient;

final class SacredAudioChromeClient extends BridgeWebChromeClient {
    private final Bridge bridge;
    private final ActivityResultLauncher<String> microphone;
    private PermissionRequest pending;
    private boolean asking;
    SacredAudioChromeClient(Bridge bridge) {
        super(bridge);
        this.bridge = bridge;
        microphone = bridge.registerForActivityResult(new ActivityResultContracts.RequestPermission(), granted -> {
            asking = false;
            PermissionRequest request = pending;
            pending = null;
            if (request == null) return;
            if (granted && trusted(request.getOrigin()) && trustedPage()) {
                request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            } else request.deny();
        });
    }
    static boolean trusted(Uri uri) {
        return uri != null && AudioOriginPolicy.trusted(uri.toString());
    }
    private boolean trustedPage() {
        String url = bridge.getWebView().getUrl();
        return url != null && trusted(Uri.parse(url));
    }
    @Override public void onPermissionRequest(PermissionRequest request) {
        String[] resources = request.getResources();
        if (asking || !trusted(request.getOrigin()) || !trustedPage()
            || resources.length != 1 || !PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resources[0])) {
            request.deny(); return;
        }
        if (ContextCompat.checkSelfPermission(bridge.getActivity(), Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
        } else {
            pending = request;
            asking = true;
            microphone.launch(Manifest.permission.RECORD_AUDIO);
        }
    }
    @Override public void onPermissionRequestCanceled(PermissionRequest request) {
        if (pending == request) pending = null;
    }
    void cancelPending() {
        if (pending != null) { pending.deny(); pending = null; }
    }
}
