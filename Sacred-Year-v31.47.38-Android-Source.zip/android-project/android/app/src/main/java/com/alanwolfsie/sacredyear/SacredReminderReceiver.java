package com.alanwolfsie.sacredyear;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import org.json.*;
import java.util.Calendar;

public class SacredReminderReceiver extends BroadcastReceiver {
    static final String CHANNEL="sacred_year_reminders", PUSH_CHANNEL="sacred_year_push", PREF="sacred_reminders";
    static void channel(Context c){if(Build.VERSION.SDK_INT>=26)c.getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel(CHANNEL,"Sacred Year reminders",NotificationManager.IMPORTANCE_DEFAULT));}
    static boolean allowed(Context c){
        if(!NotificationManagerCompat.from(c).areNotificationsEnabled())return false;
        if(Build.VERSION.SDK_INT>=26){NotificationChannel channel=c.getSystemService(NotificationManager.class).getNotificationChannel(CHANNEL);if(channel!=null&&channel.getImportance()==NotificationManager.IMPORTANCE_NONE)return false;}
        return true;
    }
    static JSONArray read(Context c){try{return new JSONArray(c.getSharedPreferences(PREF,0).getString("rows","[]"));}catch(Exception e){return new JSONArray();}}
    static void trace(Context c,String message){
        try{
            String line=System.currentTimeMillis()+" "+message;
            c.getSharedPreferences(PREF,0).edit().putString("last_trace",line).apply();
            android.util.Log.i("SacredReminder",line);
        }catch(Exception ignored){}
    }
    static String lastTrace(Context c){return c.getSharedPreferences(PREF,0).getString("last_trace","");}
    static PendingIntent pending(Context c,String id){return PendingIntent.getBroadcast(c,0,new Intent(c,SacredReminderReceiver.class).setAction("com.alanwolfsie.sacredyear.REMINDER").setData(new Uri.Builder().scheme("sacredyear-reminder").authority("local").appendPath(id).build()),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    static void replace(Context c,JSONArray rows){
        AlarmManager manager=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);JSONArray old=read(c);
        for(int i=0;i<old.length();i++){JSONObject r=old.optJSONObject(i);if(r!=null)manager.cancel(pending(c,r.optString("id")));}
        c.getSharedPreferences(PREF,0).edit().putString("rows",rows.toString()).commit();
        trace(c,"replace rows="+rows.length());
        for(int i=0;i<rows.length();i++)schedule(c,rows.optJSONObject(i),System.currentTimeMillis());
    }
    static void schedule(Context c,JSONObject row,long now){
        if(row==null)return;long at=SacredReminderTime.next(row.optLong("at"),row.optString("repeat"),now);
        if(at>0){
            AlarmManager manager=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
            boolean exact=Build.VERSION.SDK_INT<31||manager.canScheduleExactAlarms();
            trace(c,"schedule id="+row.optString("id")+" event="+row.optString("eventId","")+" at="+at+" exact="+exact);
            if(exact)manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pending(c,row.optString("id")));
            else manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pending(c,row.optString("id")));
        }
    }
    static void show(Context c,String id,String title,String body,String eventId){
        channel(c);
        boolean isEvent=eventId!=null&&!eventId.isEmpty();
        String targetChannel=isEvent?PUSH_CHANNEL:CHANNEL;
        if(Build.VERSION.SDK_INT>=26&&isEvent)c.getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel(PUSH_CHANNEL,"Sacred Year updates",NotificationManager.IMPORTANCE_DEFAULT));
        if(!NotificationManagerCompat.from(c).areNotificationsEnabled()){trace(c,"show blocked: app notifications disabled id="+id);return;}
        if(Build.VERSION.SDK_INT>=26){NotificationChannel nc=c.getSystemService(NotificationManager.class).getNotificationChannel(targetChannel);if(nc!=null&&nc.getImportance()==NotificationManager.IMPORTANCE_NONE){trace(c,"show blocked: channel disabled channel="+targetChannel+" id="+id);return;}}
        Intent open=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("sacred_reminder_tap",true);
        if(eventId!=null&&!eventId.isEmpty())open.putExtra("sacred_event_id",eventId);
        PendingIntent tap=PendingIntent.getActivity(c,id.hashCode(),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(c,targetChannel).setSmallIcon(R.drawable.ic_notification).setContentTitle(title).setContentText(body).setContentIntent(tap).setAutoCancel(true).setVisibility(NotificationCompat.VISIBILITY_PRIVATE);
        try{NotificationManagerCompat.from(c).notify(id,1,b.build());trace(c,"show posted id="+id+" event="+eventId+" channel="+targetChannel);}catch(SecurityException e){trace(c,"show security-error id="+id+" "+e.getMessage());}
    }
    @Override public void onReceive(Context c,Intent intent){
        JSONArray rows=read(c);String action=intent.getAction();trace(c,"receive action="+action+" data="+(intent.getData()==null?"":intent.getData().toString())+" rows="+rows.length());
        if(!"com.alanwolfsie.sacredyear.REMINDER".equals(action)){
            if(Intent.ACTION_BOOT_COMPLETED.equals(action)||Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)||Intent.ACTION_TIME_CHANGED.equals(action)||Intent.ACTION_TIMEZONE_CHANGED.equals(action))for(int i=0;i<rows.length();i++)schedule(c,rows.optJSONObject(i),System.currentTimeMillis());
            return;
        }
        String id=intent.getData()==null?null:intent.getData().getLastPathSegment();
        for(int i=0;i<rows.length();i++){JSONObject row=rows.optJSONObject(i);if(row!=null&&row.optString("id").equals(id)){
            String eventId=row.optString("eventId","");
            String body=row.optString("body",eventId.isEmpty()?"Your Sacred Year reminder is due. Open the app for details.":"Your saved community event is starting now. Tap to view it.");
            show(c,id,row.optString("title"),body,eventId);
            schedule(c,row,System.currentTimeMillis()+1000);break;
        }}
    }
}
