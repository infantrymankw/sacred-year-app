package com.alanwolfsie.sacredyear;
import com.getcapacitor.BridgeActivity;
import android.os.Bundle;
import android.content.Intent;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
public class MainActivity extends BridgeActivity {
    private SacredAudioChromeClient audioClient;
    @Override public void onCreate(Bundle savedInstanceState) {
        registerPlugin(SacredNotificationsPlugin.class);
        super.onCreate(savedInstanceState);
        if(Build.VERSION.SDK_INT>=26)getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel("sacred_year_push","Sacred Year updates",NotificationManager.IMPORTANCE_DEFAULT));
        audioClient = new SacredAudioChromeClient(bridge);
        bridge.getWebView().setWebChromeClient(audioClient);
    }
    @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);}
    @Override public void onDestroy() {
        if (audioClient != null) audioClient.cancelPending();
        super.onDestroy();
    }
}
