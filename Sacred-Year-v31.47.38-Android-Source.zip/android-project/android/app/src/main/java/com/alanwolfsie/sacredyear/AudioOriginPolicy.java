package com.alanwolfsie.sacredyear;
import java.net.URI;
import java.net.URISyntaxException;
final class AudioOriginPolicy {
    static boolean trusted(String origin) {
        if (origin == null) return false;
        try {
            URI uri = new URI(origin);
            return "https".equals(uri.getScheme()) && "www.sacredyear.app".equals(uri.getHost())
                && (uri.getPort() == -1 || uri.getPort() == 443) && uri.getUserInfo() == null;
        } catch (URISyntaxException e) { return false; }
    }
}
