(function(){
 if(!window.Capacitor?.isNativePlatform?.())return;
 const plugin=()=>window.Capacitor.Plugins.SacredNotifications;
 let revision=0,authAttached=false;
 async function sync(){
  const version=++revision,db=window.syFirebase?.db,ops=window.syFirebaseOps,sb=window.sySupabase;
  if(!db||!ops||!sb)throw new Error('Your account is still loading. Try again shortly.');
  const {data:{session}}=await sb.auth.getSession();
  if(!session?.user){await plugin().sync({reminders:[]});return 0;}
  const uid=session.user.id;
  const entitlement=await window.syGetEntitlements?.();
  if(!entitlement)throw new Error('Your account access is still loading.');
  if(!entitlement.hall_plus){await plugin().sync({reminders:[]});return 0;}
  const result=await ops.getDocs(ops.query(ops.collection(db,'sacred_year_hall_reminders'),ops.where('user_id','==',uid)));
  const rows=result.docs.map(d=>({id:d.id,...d.data()}));
  const {data:{session:current}}=await sb.auth.getSession();
  if(version!==revision||current?.user?.id!==uid)return 0;
  const reminders=rows.filter(r=>r.enabled&&Number.isFinite(Date.parse(r.scheduled_for))).slice(0,200).map(r=>({id:uid+':'+r.id,title:r.title||'Sacred Year reminder',at:Date.parse(r.scheduled_for),repeat:r.recurrence||'none',enabled:true}));
  await plugin().sync({reminders});return reminders.length;
 }
 window.syNativeReminderSync=sync;
 window.syNativeNotificationAuthReady=function(){
  if(authAttached||!window.sySupabase)return;authAttached=true;
  window.sySupabase.auth.onAuthStateChange((event,session)=>{
   ++revision;
   if(!session?.user)plugin().sync({reminders:[]}).catch(()=>{});
   else setTimeout(()=>sync().catch(()=>{}),0);
  });
 };
 window.syNativeNotificationAuthReady();
 window.syNativeEnableNotifications=window.syEnableNotifications=async function(){
  try{
   const status=await plugin().enable();
   if(!status.granted){alert('Notifications are off. Open Android notification settings for Sacred Year to allow them. Your saved reminders are unchanged.');await paint();return;}
   let text='Android notifications are allowed. Use Test notification to check delivery.';
   try{const count=await sync();text+=count?' Your enabled Hall+ reminders have been copied to this phone.':' You can add a reminder in Hall+ → Advanced Reminders.';}catch(e){text+=' Your saved reminders could not sync yet. Open the app online and tap Enable notifications again.';}
   alert(text);await paint();
  }catch(e){alert(e.message||'Could not enable Android notifications.');}
 };
 window.sy307RequestNotifications=window.syEnableNotifications;
 window.syNativeShowNotification=async function(id,title,body){try{return await plugin().show({id:String(id||'activity'),title:String(title||'Sacred Year'),body:String(body||'')});}catch(e){console.warn('Native notification unavailable:',e?.message||e);}};
 window.syNativeTestNotification=async()=>{try{await plugin().test();alert('Test notification sent. Check your Android notification shade.');}catch(e){alert(e.message||'Could not send test notification.');}};
 window.syNativeNotificationSettings=()=>plugin().settings();
 async function paint(){
  const sheet=document.getElementById('sheetContent');if(!sheet)return;
  const text=sheet.textContent||'';
  if(!/Notification Center|Notification settings|Notification Settings|Your Sacred Schedule/.test(text))return;
  sheet.querySelectorAll('button').forEach(b=>{if(/Enable browser alerts|Allow phone\/browser alerts|Enable phone alerts/.test(b.textContent))b.textContent='Enable notifications';});
  sheet.querySelectorAll('p').forEach(p=>{
   if(p.textContent.includes('Browser notification permission:')||p.textContent.includes('Browser notifications unavailable')||p.textContent.includes('Browser notification permission can be enabled'))p.textContent='Android notifications are managed in your phone settings.';
   if(p.textContent.includes('Browser alerts depend on'))p.textContent='Enabled reminders are copied to this phone when you open or update this schedule online. Android may delay alerts to save battery.';
  });
  let box=sheet.querySelector('#syNativeNotificationControls');
  if(!box){box=document.createElement('div');box.id='syNativeNotificationControls';box.className='holiday';box.innerHTML='<p id="syNativeNotificationStatus">Checking Android notification settings…</p><div class="row"><button class="btn secondary" onclick="syNativeTestNotification()">Test notification</button><button class="btn secondary" onclick="syNativeNotificationSettings()">Android notification settings</button></div><p class="note">Saved Hall+ reminders can alert on this phone while the app is closed. Android may delay delivery. Changes made on another device are copied here when you reopen the app online. Creator announcements and community activity are shown in Activity when the app syncs. Background push delivery requires the Sacred Year notification service.</p>';sheet.appendChild(box);}
  try{const s=await plugin().check();const label=box.querySelector('#syNativeNotificationStatus');if(label)label.textContent=s.granted?'Android notifications: allowed':'Android notifications: off';}catch(e){box.querySelector('#syNativeNotificationStatus').textContent='Could not read Android notification settings.';}
 }
 for(const name of ['syOpenNotifications','syOpenNotificationSettings','sy307Reminders']){const old=window[name];if(old)window[name]=async function(...args){const value=await old.apply(this,args);await paint();return value;};}
 window.syNativeNotificationPaint=paint;
 window.addEventListener('focus',()=>{paint();sync().catch(()=>{});});
 window.addEventListener('load',()=>{window.syEnableNotifications=window.syNativeEnableNotifications;window.sy307RequestNotifications=window.syNativeEnableNotifications;window.syNativeNotificationAuthReady();sync().catch(()=>{});});
})();
