package com.alanwolfsie.sacredyear;

import android.app.*;
import android.content.*;
import android.net.Uri;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import org.json.*;
import java.util.Calendar;

public class SacredReminderReceiver extends BroadcastReceiver {
    static final String CHANNEL="sacred_year_reminders", PREF="sacred_reminders";
    static void channel(Context c){if(Build.VERSION.SDK_INT>=26)c.getSystemService(NotificationManager.class).createNotificationChannel(new NotificationChannel(CHANNEL,"Sacred Year reminders",NotificationManager.IMPORTANCE_DEFAULT));}
    static boolean allowed(Context c){
        if(!NotificationManagerCompat.from(c).areNotificationsEnabled())return false;
        if(Build.VERSION.SDK_INT>=26){NotificationChannel channel=c.getSystemService(NotificationManager.class).getNotificationChannel(CHANNEL);if(channel!=null&&channel.getImportance()==NotificationManager.IMPORTANCE_NONE)return false;}
        return true;
    }
    static JSONArray read(Context c){try{return new JSONArray(c.getSharedPreferences(PREF,0).getString("rows","[]"));}catch(Exception e){return new JSONArray();}}
    static PendingIntent pending(Context c,String id){return PendingIntent.getBroadcast(c,0,new Intent(c,SacredReminderReceiver.class).setAction("com.alanwolfsie.sacredyear.REMINDER").setData(new Uri.Builder().scheme("sacredyear-reminder").authority("local").appendPath(id).build()),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    static void replace(Context c,JSONArray rows){
        AlarmManager manager=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);JSONArray old=read(c);
        for(int i=0;i<old.length();i++){JSONObject r=old.optJSONObject(i);if(r!=null)manager.cancel(pending(c,r.optString("id")));}
        c.getSharedPreferences(PREF,0).edit().putString("rows",rows.toString()).commit();
        for(int i=0;i<rows.length();i++)schedule(c,rows.optJSONObject(i),System.currentTimeMillis());
    }
    static void schedule(Context c,JSONObject row,long now){
        if(row==null)return;long at=SacredReminderTime.next(row.optLong("at"),row.optString("repeat"),now);
        if(at>0){
            AlarmManager manager=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
            if(Build.VERSION.SDK_INT<31||manager.canScheduleExactAlarms())manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pending(c,row.optString("id")));
            else manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pending(c,row.optString("id")));
        }
    }
    static void show(Context c,String id,String title,String body,String eventId){
        channel(c);if(!allowed(c))return;
        Intent open=new Intent(c,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("sacred_reminder_tap",true);
        if(eventId!=null&&!eventId.isEmpty())open.putExtra("sacred_event_id",eventId);
        PendingIntent tap=PendingIntent.getActivity(c,id.hashCode(),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b=new NotificationCompat.Builder(c,CHANNEL).setSmallIcon(R.drawable.ic_notification).setContentTitle(title).setContentText(body).setContentIntent(tap).setAutoCancel(true).setVisibility(NotificationCompat.VISIBILITY_PRIVATE);
        try{NotificationManagerCompat.from(c).notify(id,1,b.build());}catch(SecurityException ignored){}
    }
    @Override public void onReceive(Context c,Intent intent){
        JSONArray rows=read(c);String action=intent.getAction();
        if(!"com.alanwolfsie.sacredyear.REMINDER".equals(action)){
            if(Intent.ACTION_BOOT_COMPLETED.equals(action)||Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)||Intent.ACTION_TIME_CHANGED.equals(action)||Intent.ACTION_TIMEZONE_CHANGED.equals(action))for(int i=0;i<rows.length();i++)schedule(c,rows.optJSONObject(i),System.currentTimeMillis());
            return;
        }
        String id=intent.getData()==null?null:intent.getData().getLastPathSegment();
        for(int i=0;i<rows.length();i++){JSONObject row=rows.optJSONObject(i);if(row!=null&&row.optString("id").equals(id)){
            String eventId=row.optString("eventId","");
            String body=row.optString("body",eventId.isEmpty()?"Your Sacred Year reminder is due. Open the app for details.":"Your saved community event is starting now. Tap to view it.");
            show(c,id,row.optString("title"),body,eventId);
            schedule(c,row,System.currentTimeMillis()+1000);break;
        }}
    }
}
