const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync('work/android-release/www/index.html','utf8');
let calls=0;const context={syOpenNotifications:()=>{},window:{Capacitor:{isNativePlatform:()=>true},syNativeEnableNotifications:async()=>++calls},alert:()=>{throw Error('Browser fallback reached')}};vm.createContext(context);
const hall=html.match(/async function requestNotifications\(\)\{[^\n]+/)[0];
vm.runInContext(hall+';window.sy307RequestNotifications=requestNotifications;',context);
const regular=html.match(/async function syEnableNotifications\(\)\{[\s\S]*?window.syEnableNotifications=syEnableNotifications;/)[0];vm.runInContext(regular,context);
(async()=>{await context.window.sy307RequestNotifications();await context.window.syEnableNotifications();assert.equal(calls,2);console.log('PASS: later legacy assignments route both notification buttons to Android without browser Notification API.');})();

