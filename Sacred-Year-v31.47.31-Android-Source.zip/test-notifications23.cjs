const fs=require('fs'),vm=require('vm'),assert=require('assert');const code=fs.readFileSync('work/native-notifications.js','utf8');
async function scenario(granted){
 let alerts=[],syncs=[],prompt=0,test=0,auth;
 const plugin={enable:async()=>{prompt++;return {granted}},sync:async x=>syncs.push(x),test:async()=>test++,check:async()=>({granted}),settings:async()=>{}};
 const ops={collection:()=>0,where:()=>0,query:()=>0,getDocs:async()=>({docs:[{id:'one',data:()=>({enabled:true,title:'Study',scheduled_for:'2027-01-01T09:00:00Z',recurrence:'daily'})},{id:'two',data:()=>({enabled:false,scheduled_for:'2027-01-01T09:00:00Z'})}]})};
 const window={Capacitor:{isNativePlatform:()=>true,Plugins:{SacredNotifications:plugin}},syGetEntitlements:async()=>({hall_plus:true}),syFirebase:{db:{}},syFirebaseOps:ops,sySupabase:{auth:{getSession:async()=>({data:{session:{user:{id:'owner'}}}}),onAuthStateChange:cb=>auth=cb}},addEventListener(){}};
 const c={window,document:{getElementById:()=>null},alert:m=>alerts.push(m),Date,setTimeout:fn=>fn()};vm.createContext(c);vm.runInContext(code,c);
 await window.syEnableNotifications();assert.equal(prompt,1);
 if(granted){assert.equal(syncs.length,1);assert.equal(syncs[0].reminders.length,1);assert.equal(syncs[0].reminders[0].id,'owner:one');await window.syNativeTestNotification();assert.equal(test,1);auth('SIGNED_OUT',null);await Promise.resolve();assert.equal(syncs.at(-1).reminders.length,0);}else{assert.equal(syncs.length,0);assert.match(alerts[0],/Notifications are off/)}
}
(async()=>{await scenario(false);await scenario(true);const old=()=>{};const c={window:{Capacitor:{isNativePlatform:()=>false},syEnableNotifications:old}};vm.createContext(c);vm.runInContext(code,c);assert.equal(c.window.syEnableNotifications,old);console.log('PASS: native prompt, denial preserves schedules, enabled-only reminder sync, user scoping, test notification, sign-out cancellation, browser flow preserved.');})();
