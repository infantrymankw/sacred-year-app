const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync('work/android-release/www/index.html','utf8');
const body=html.match(/window\.sy346StartRecording=async function\(\).*?(?=\n)/)[0];
async function run({session=true,plus=true,deny=false}={}){
 let calls=0,stops=0,alerts=[];const state={textContent:''};const elements={sy346Start:{},sy346Stop:{},sy346RecState:state};
 const context={window:{syGetEntitlements:async()=>({hall_plus:plus})},getSession:async()=>session?{user:{id:'test'}}:null,document:{getElementById:id=>elements[id]},navigator:{mediaDevices:{getUserMedia:async()=>{calls++;if(deny){const e=new Error('denied');e.name=typeof deny==='string'?deny:'NotAllowedError';throw e}return {getTracks:()=>[{stop:()=>stops++}]}}}},MediaRecorder:class {static isTypeSupported(){return true} constructor(){this.state='inactive'}start(){this.state='recording'}},alert:x=>alerts.push(x),Date,setInterval:()=>1,clearInterval(){},Blob,URL};
 vm.createContext(context);vm.runInContext('let recorder=null,chunks=[],stream=null,blob=null,started=0,elapsed=0,timer=null;'+body,context);
 await context.window.sy346StartRecording();return {calls,alerts,state,context};
}
(async()=>{assert.equal((await run({session:false})).calls,0);assert.equal((await run({plus:false})).calls,0);let r=await run({deny:true});assert.equal(r.calls,1);assert.match(r.alerts[0],/Android Settings/);assert.equal(r.context.window.syAudioStarting,false);r=await run({deny:'NotReadableError'});assert.match(r.alerts[0],/Close other apps/);r=await run();assert.equal(r.calls,1);assert.equal(r.state.textContent,'Recording…');await r.context.window.sy346StartRecording();assert.equal(r.calls,1);console.log('PASS: signed-out and free-user gating, denial fallback, successful recording start, duplicate-start guard.');})();
