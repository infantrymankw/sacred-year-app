
const runes=[
["ᚠ","Fehu","Wealth, resources, prosperity"],["ᚢ","Uruz","Strength, vitality, endurance"],["ᚦ","Thurisaz","Challenge, defense, controlled force"],["ᚨ","Ansuz","Wisdom, speech, inspiration"],["ᚱ","Raidho","Journey, order, right movement"],["ᚲ","Kenaz","Torch, knowledge, craft"],["ᚷ","Gebo","Gift, exchange, hospitality"],["ᚹ","Wunjo","Joy, harmony, fellowship"],["ᚺ","Hagalaz","Hail, disruption, change"],["ᚾ","Nauthiz","Need, constraint, resilience"],["ᛁ","Isa","Ice, stillness, focus"],["ᛃ","Jera","Harvest, cycles, reward"],["ᛇ","Eihwaz","Yew, endurance, transformation"],["ᛈ","Perthro","Mystery, chance, unknown"],["ᛉ","Algiz","Protection, sacred connection"],["ᛋ","Sowilo","Sun, wholeness, victory"],["ᛏ","Tiwaz","Justice, honor, sacrifice"],["ᛒ","Berkano","Growth, renewal, nurturing"],["ᛖ","Ehwaz","Trust, partnership, movement"],["ᛗ","Mannaz","Humanity, community, self"],["ᛚ","Laguz","Water, flow, intuition"],["ᛜ","Ingwaz","Potential, fertility, completion"],["ᛞ","Dagaz","Dawn, awakening, breakthrough"],["ᛟ","Othala","Heritage, home, inheritance"]
];
const SB=window.SACRED_YEAR_CONFIG||{};
let supabaseClient=null,user=null;

function showView(id){document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));document.getElementById(id).classList.add('active');document.querySelectorAll('.tab').forEach(t=>t.classList.toggle('active',t.dataset.view===id));window.scrollTo({top:0,behavior:'smooth'})}
document.querySelectorAll('.tab').forEach(t=>t.onclick=()=>showView(t.dataset.view));
function openDrawer(x){const sheet=document.getElementById('sheet'),content=document.getElementById('sheetContent');content.innerHTML=x;content.querySelectorAll('button').forEach(b=>{if(b.id!=='syPermanentPanelClose'&&b.textContent.trim()==='Close')b.remove()});document.getElementById('drawer').classList.add('open');sheet.scrollTop=0}
function closeDrawer(){document.getElementById('drawer').classList.remove('open')}
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}

async function initCloud(){
  const status=document.getElementById('cloudStatus');
  if(!status){updateLocalState();return;}
  if(!SB.supabaseUrl||!SB.supabaseAnonKey||SB.supabaseUrl.includes('YOUR_')){
    status.className='notice warn';
    status.innerHTML='<b>Firebase is initializing.</b> Online accounts and sync will appear when the Sacred Year cloud service is ready.';
    updateLocalState();
    return;
  }
  try{
    const mod=await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm');
    supabaseClient=mod.createClient(SB.supabaseUrl,SB.supabaseAnonKey);
    const {data}=await supabaseClient.auth.getSession();
    user=data.session?.user||null;
    status.className='notice good';
    status.innerHTML='<b>Cloud connected.</b> Accounts and synced data are using the configured Firebase project.';
    supabaseClient.auth.onAuthStateChange((_event,session)=>{user=session?.user||null;refreshUI()});
    await refreshUI();
  }catch(e){
    status.className='notice bad';
    status.textContent='Cloud configuration was found, but connection failed: '+e.message;
    updateLocalState();
  }
}

async function openAccount(){
  if(!supabaseClient){
    openDrawer(`<div class="kicker">Online Accounts</div><h3>Backend not connected yet</h3>
    <div class="notice warn">Firebase is initializing. Please try again in a moment.</div>
    <p>Until then, the app stays usable in local demo mode.</p><button class="btn" onclick="sy323BackToMenu()">Close</button>`);
    return;
  }
  if(!user){
    openDrawer(`<div class="kicker">Sacred Year Account</div><h3>Sign in or register</h3>
    <label>Email</label><input id="email" type="email"/>
    <label>Password</label><input id="pass" type="password"/>
    <div class="row" style="margin-top:14px"><button class="btn" onclick="cloudSignUp()">Create account</button><button class="btn secondary" onclick="cloudSignIn()">Sign in</button></div>`);
  }else{
    const creator=await isCreator();
    openDrawer(`<div class="kicker">${creator?'Creator Account':'My Account'}</div><h3>${esc(user.email)}</h3>
    ${creator?'<button class="btn" onclick="openCreator()">Open Creator Dashboard</button>':''}
    <button class="btn secondary" style="margin-top:10px" onclick="cloudSignOut()">Sign out</button>`);
  }
}
async function cloudSignUp(){
  const email=document.getElementById('email').value.trim(),password=document.getElementById('pass').value;
  const {error}=await supabaseClient.auth.signUp({email,password});
  if(error)return alert(error.message);
  alert('Account created. Check your email for the Sacred Year verification message.');closeDrawer();
}
async function cloudSignIn(){
  const email=document.getElementById('email').value.trim(),password=document.getElementById('pass').value;
  const {error}=await supabaseClient.auth.signInWithPassword({email,password});
  if(error)return alert(error.message);closeDrawer();
}
async function cloudSignOut(){await supabaseClient.auth.signOut();closeDrawer()}

async function isCreator(){
  if(!user||!supabaseClient)return false;
  const {data}=await supabaseClient.from('profiles').select('role').eq('id',user.id).maybeSingle();
  return data?.role==='creator';
}
async function openCreator(){
  if(!await isCreator())return alert('Creator role is not enabled for this account.');
  openDrawer(`<div class="kicker">Creator Dashboard</div><h3>Words from the Hall</h3>
  <label>Title</label><input id="postTitle" value="Words from the Hall"/>
  <label>Message</label><textarea id="postMessage" rows="6"></textarea>
  <label>Label</label><select id="postLabel"><option>AlanWolfsie Reflection</option><option>Modern Practice</option><option>Historical Note</option><option>Announcement</option></select>
  <label><input id="postNotify" type="checkbox" checked style="width:auto;margin-right:7px">Queue notification</label>
  <button class="btn" style="margin-top:14px" onclick="publishCloudPost()">Publish</button>
  <p class="note">Publishing saves the post and can request Creator push through the Sacred Year service.</p>`);
}
async function publishCloudPost(){
  const row={author_id:user.id,title:document.getElementById('postTitle').value.trim(),message:document.getElementById('postMessage').value.trim(),label:document.getElementById('postLabel').value,status:'published',send_notification:document.getElementById('postNotify').checked,published_at:new Date().toISOString()};
  if(!row.message)return alert('Write a message first.');
  const {data,error}=await supabaseClient.from('creator_posts').insert(row).select().single();
  if(error)return alert(error.message);
  if(row.send_notification){
    try{await window.syPushSendCreatorPost(data.id);}catch(e){alert('Post published, but push failed: '+(e?.message||e));}
  }
  closeDrawer();await loadLatestWord();alert('Published to the cloud.');
}

function openRune(r){
  openDrawer(`<div class="kicker">Rune Circle</div><h3 style="font-size:38px">${r[0]} ${r[1]}</h3><p>${r[2]}</p><button class="btn" onclick='saveRune(${JSON.stringify(JSON.stringify(r))})'>Save rune</button>`);
}
const legacyRuneGrid=document.getElementById('runeGrid');if(legacyRuneGrid)runes.forEach(r=>{const b=document.createElement('button');b.className='rune';b.innerHTML=`<b>${r[0]}</b><span>${r[1]}</span>`;b.onclick=()=>openRune(r);legacyRuneGrid.appendChild(b)})
function showRuneDraw(){openRune(runes[Math.floor(Math.random()*runes.length)])}
async function saveRune(jsonString){
 const syAccountScope=window.sy25Scope();

  const r=JSON.parse(jsonString);
  syLocalStorage.setItem('sy_saved_rune',JSON.stringify(r));
  if(supabaseClient&&user){
    await window.sy25Await((window.sy25Assert(syAccountScope), (supabaseClient.from('saved_runes').upsert({user_id:user.id,rune:r[1],rune_symbol:r[0],keywords:r[2],saved_at:new Date().toISOString()}))),syAccountScope);
  }
  closeDrawer();refreshUI();
}


const libraryBooks={
  havamal:{
    title:'Hávamál',
    kicker:'Hávamál',
    source:'Henry Adams Bellows, The Poetic Edda (1923)',
    text:document.getElementById('havamalData').textContent.trim()
  },
  poetic:{
    title:'The Poetic Edda',
    kicker:'Poetic Edda',
    source:'Henry Adams Bellows translation (1923)',
    text:document.getElementById('poeticData').textContent.trim()
  },
  prose:{
    title:'The Prose Edda',
    kicker:'Prose Edda',
    source:'Rasmus B. Anderson edition',
    text:document.getElementById('proseData').textContent.trim()
  }
};
let currentBook='havamal';
const reader=document.getElementById('reader');

function currentBookData(){return libraryBooks[currentBook]}

function openBook(key, restore=true){
  if(!libraryBooks[key])return;
  currentBook=key;
  const book=libraryBooks[key];
  document.querySelectorAll('.bookpick').forEach(b=>b.classList.remove('active'));
  const pick=document.getElementById('pick-'+key);if(pick)pick.classList.add('active');
  document.getElementById('readerKicker').textContent=book.kicker;
  document.getElementById('readerTitle').textContent=book.title;
  document.getElementById('readerSource').textContent=book.source;
  document.getElementById('readerSearch').value='';
  document.getElementById('readerSearch').placeholder='Search '+book.title+'…';
  reader.textContent=book.text;
  reader.scrollTop=0;
  if(restore) restoreReaderPlaceForBook(key);
}

function searchReader(){
  const q=document.getElementById('readerSearch').value.trim().toLowerCase();
  const fullText=currentBookData().text;
  if(!q){reader.textContent=fullText;return}
  const lines=fullText.split('\n'),hits=[];
  for(let i=0;i<lines.length;i++){
    if(lines[i].toLowerCase().includes(q)){
      hits.push(lines.slice(Math.max(0,i-2),Math.min(lines.length,i+3)).join('\n'));
    }
  }
  reader.textContent=hits.length?hits.join('\n\n———\n\n'):'No matches found.';
}

function setReaderSize(s){
  reader.style.fontSize=s==='small'?'14px':s==='large'?'20px':'16px';
  syLocalStorage.setItem('sy_reader_size',s);
}

async function saveReaderPlace(){
 const syAccountScope=window.sy25Scope();

  const b={
    work:currentBook,
    title:currentBookData().title,
    position:{scrollTop:reader.scrollTop},
    saved_at:new Date().toISOString()
  };
  syLocalStorage.setItem('sy_reader_bookmark',JSON.stringify(b));
  if(supabaseClient&&user){
    await window.sy25Await((window.sy25Assert(syAccountScope), (supabaseClient.from('bookmarks').upsert({
      user_id:user.id,
      work:currentBook,
      position:b.position,
      saved_at:b.saved_at
    },{onConflict:'user_id,work'}))),syAccountScope);
  }
  updateContinueReading();
  refreshUI();
  alert(currentBookData().title+' reading place saved.');
}

function restoreReaderPlaceForBook(key){
  const b=JSON.parse(syLocalStorage.getItem('sy_reader_bookmark')||'null');
  if(b&&b.work===key){
    setTimeout(()=>reader.scrollTop=b.position?.scrollTop||0,70);
  }
}

function updateContinueReading(){
  const b=JSON.parse(syLocalStorage.getItem('sy_reader_bookmark')||'null');
  const box=document.getElementById('continueReading');
  if(!box)return;
  if(!b){
    box.innerHTML='<div class="kicker">Continue Reading</div><p class="note">No saved reading place yet.</p>';
    return;
  }
  box.innerHTML=`<div class="kicker">Continue Reading</div><h4 style="margin:5px 0">${esc(b.title||b.work)}</h4>
  <p class="note">Saved ${new Date(b.saved_at).toLocaleString()}</p>
  <button class="btn secondary" onclick="openBook('${esc(b.work)}')">Continue</button>`;
}

async function loadLatestWord(){
  const box=document.getElementById('latestWord');
  if(supabaseClient){
    const {data}=await supabaseClient.from('creator_posts').select('title,message,label,published_at').eq('status','published').order('published_at',{ascending:false}).limit(1);
    if(data&&data.length){const p=data[0];box.innerHTML=`<div class="kicker">${esc(p.label)}</div><h4>${esc(p.title)}</h4><p>${esc(p.message)}</p><p class="note">${syDisplayDate(p.published_at)}</p>`;return}
  }
  box.innerHTML='<div class="kicker">AlanWolfsie Reflection</div><p style="font-style:italic">Strength is not only the force to act. Wisdom is knowing what deserves your strength.</p><p class="note">Demo message until cloud publishing is configured.</p>';
}
function updateLocalState(){
  const r=JSON.parse(syLocalStorage.getItem('sy_saved_rune')||'null');
  const b=JSON.parse(syLocalStorage.getItem('sy_reader_bookmark')||'null');
  document.getElementById('savedRuneText').textContent=r?`${r[0]} ${r[1]} — ${r[2]}`:'None saved.';
  document.getElementById('savedReadingText').textContent=b?(b.title||b.work)+' bookmark saved.':'No bookmark.';
}
async function refreshUI(){
  document.getElementById('accountBtn').textContent=user?(await isCreator()?'Creator':'Account'):'Account';
  updateLocalState();await loadLatestWord();
}

function moonInfo(date){
 const known=new Date(Date.UTC(2000,0,6,18,14)),cycle=29.53058867;
 const age=((((date-known)/86400000)%cycle)+cycle)%cycle;
 let name='Waning Crescent',icon='☾';
 if(age<1.85){name='New Moon';icon='●'}else if(age<7.38){name='Waxing Crescent';icon='☽'}else if(age<9.23){name='First Quarter';icon='◐'}else if(age<14.77){name='Waxing Gibbous';icon='◔'}else if(age<16.61){name='Full Moon';icon='○'}else if(age<22.15){name='Waning Gibbous';icon='◕'}else if(age<24){name='Last Quarter';icon='◑'}
 return {age,name,icon}
}
const mi=moonInfo(new Date());
document.getElementById('dateNow').textContent=new Date().toLocaleDateString(undefined,{weekday:'long',month:'long',day:'numeric'});
document.getElementById('moonNow').textContent=`${mi.icon} ${mi.name} • approximately ${mi.age.toFixed(1)} days into the lunar cycle`;
const legacyMoonTitle=document.getElementById('moonTitle');if(legacyMoonTitle)legacyMoonTitle.textContent=mi.name;
const legacyMoonDetail=document.getElementById('moonDetail');if(legacyMoonDetail)legacyMoonDetail.textContent=`Approximate lunar age: ${mi.age.toFixed(1)} days.`;

openBook('havamal',false);updateContinueReading();const rs=syLocalStorage.getItem('sy_reader_size');if(rs)setReaderSize(rs);
