
async function sy20GetRole(){
 try{
  const s=await sy19Session(); if(!s?.user)return null;
  const {data}=await window.sySupabase.from("profiles").select("role").eq("id",s.user.id).maybeSingle();
  return data?.role||null;
 }catch(e){return null}
}

async function sy20OrganizerCenter(){
 const role=await sy20GetRole();
 if(role!=="creator"){alert("Creator access required.");return}
 let rows=[];
 try{
  const {data,error}=await window.sySupabase.from("community_organizers").select("*").order("trusted_recommended",{ascending:false}).order("approved_events_count",{ascending:false}).limit(100);
  if(error)throw error; rows=data||[];
 }catch(e){alert(e.message);return}
 openDrawer(`<div class="kicker">Creator Tools</div><h3>Organizer Center</h3>
 <p class="note">Promote only after reviewing the organizer's track record. Sacred Year recommends Trusted status after 3 approved events with no serious reports, but you still make the final decision.</p>
 <div class="list">${rows.map(o=>`<div class="sy20-org">
  <div class="kicker">${sy19OrganizerBadge(o.organizer_type)}</div>
  <h4>${sy19Esc(o.organization_name||o.display_name||"Organizer")}</h4>
  <span class="sy20-stat">Approved events: ${o.approved_events_count||0}</span>
  <span class="sy20-stat">Serious reports: ${o.serious_reports_count||0}</span>
  ${o.trusted_recommended?'<span class="sy20-stat sy20-rec">Trusted recommended</span>':""}
  <div class="row" style="margin-top:8px">
   <button class="btn secondary" onclick="sy20SetOrganizer('${o.user_id}','community')">Community</button>
   <button class="btn secondary" onclick="sy20SetOrganizer('${o.user_id}','trusted')">Trusted</button>
   <button class="btn secondary" onclick="sy20SetOrganizer('${o.user_id}','verified')">Verified Org</button>
  </div>
 </div>`).join("")||'<p class="note">No organizer profiles yet.</p>'}</div>
 <button class="btn secondary" onclick="sy20EventSources()">External Event Sources</button>`);
}
async function sy20SetOrganizer(userId,type){
 let orgName=null;
 if(type==="verified"){
  orgName=prompt("Verified organization name:");
  if(!orgName)return;
 }
 const patch={organizer_type:type,trusted_recommended:false,updated_at:new Date().toISOString()};
 if(type==="verified"){patch.organization_name=orgName;patch.verified_at=new Date().toISOString()}
 if(type==="community"){patch.verified_at=null}
 const {error}=await window.sySupabase.from("community_organizers").update(patch).eq("user_id",userId);
 if(error){alert(error.message);return}
 alert(type==="verified"?"Organization verified.":type==="trusted"?"Organizer marked Trusted.":"Organizer returned to Community status.");
 sy20OrganizerCenter();
}
window.sy20OrganizerCenter=sy20OrganizerCenter;
window.sy20SetOrganizer=sy20SetOrganizer;



function sy22AdapterName(s){
 const a=s.adapter||s.source_type||"manual";
 return a==="ical"?"iCal / ICS":a==="eventbrite"?"Eventbrite":a==="meetup"?"Meetup Pro":a.toUpperCase();
}
async function sy20EventSources(){
 const role=await sy20GetRole(); if(role!=="creator"){alert("Creator access required.");return}
 let rows=[];
 try{
   const {data,error}=await window.sySupabase.from("external_event_sources").select("*").order("created_at",{ascending:false});
   if(error)throw error; rows=data||[];
 }catch(e){alert(e.message);return}
 openDrawer(`<div class="kicker">External Events</div><h3>Approved Event Sources</h3>
 <p class="note">Enabled sources sync automatically about every six hours. Sacred Year currently supports public iCal feeds, Eventbrite organization events, and Meetup Pro network events.</p>
 <div class="list">${rows.map(s=>{
   const a=s.adapter||s.source_type||"manual", cfg=s.adapter_config||{};
   let setup="";
   if(a==="eventbrite")setup=`Organization ID: ${sy19Esc(cfg.organization_id||"not configured")}`;
   else if(a==="meetup")setup=`Pro network: ${sy19Esc(cfg.network_urlname||"not configured")}`;
   else if(a==="ical")setup=s.source_url?`Feed: ${sy19Esc(s.source_url)}`:"No feed configured";
   else setup="Manual / no automatic adapter";
   return `<div class="sy20-source">
     <div class="kicker">${sy22AdapterName(s)} • ${s.enabled?"Enabled":"Disabled"}</div>
     <h4>${sy19Esc(s.name)}</h4><p>${setup}</p>
     <p class="note">${s.default_city||s.default_region?`Default area: ${sy19Esc(s.default_city||"")}${s.default_city&&s.default_region?", ":""}${sy19Esc(s.default_region||"")}`:"No default city/state configured."}</p>
     <p class="note">Last sync: ${s.last_synced_at?new Date(s.last_synced_at).toLocaleString():"Never"} • ${sy19Esc(s.last_sync_status||"not run")}${s.last_error?`<br>${sy19Esc(s.last_error)}`:""}</p>
     <div class="row"><button class="btn secondary" onclick="sy21ConfigureSource('${s.id}')">Configure</button>
     ${["ical","eventbrite","meetup"].includes(a)?`<button class="btn secondary" onclick="sy21SyncSource('${s.id}')">Sync now</button>`:""}
     <button class="btn secondary" onclick="sy20ToggleSource('${s.id}',${!s.enabled})">${s.enabled?"Disable":"Enable"}</button></div>
   </div>`}).join("")||'<p class="note">No external sources added yet.</p>'}</div>
 <button class="btn" onclick="sy20AddEventSource()">Add approved source</button>
 <div class="holiday" style="margin-top:12px"><div class="kicker">Credentials</div><p>Eventbrite and Meetup credentials must stay in a server-side secret store, never in the app. Automatic external-event sync will be enabled after the Firebase server function is connected.</p></div>`);
}

async function sy20AddEventSource(){
 const name=prompt("Source or organization name:"); if(!name)return;
 const pick=(prompt("Type: ical, eventbrite, meetup, or manual","ical")||"manual").toLowerCase();
 if(!["ical","eventbrite","meetup","manual"].includes(pick)){alert("Use ical, eventbrite, meetup, or manual.");return}
 const source_type=pick==="ical"?"ical":pick==="manual"?"manual":"api";
 let source_url=null,adapter_config={};
 if(pick==="ical"){
   source_url=prompt("Public HTTPS iCal / ICS feed URL:")||null;
   if(!source_url||!/^https:\/\//i.test(source_url)){alert("iCal sources require a public HTTPS URL.");return}
 }else if(pick==="eventbrite"){
   const organization_id=prompt("Eventbrite Organization ID:");
   if(!organization_id)return; adapter_config={organization_id:organization_id.trim()};
 }else if(pick==="meetup"){
   const network_urlname=prompt("Meetup Pro network URL name:");
   if(!network_urlname)return; adapter_config={network_urlname:network_urlname.trim()};
 }
 const {data,error}=await window.sySupabase.from("external_event_sources").insert({name,source_type,source_url,enabled:false,adapter:pick,adapter_config}).select().single();
 if(error){alert(error.message);return}
 alert("Source added. Configure its location defaults before enabling it.");
 sy21ConfigureSource(data.id);
}

async function sy21ConfigureSource(id){
 let s=null;
 try{
  const {data,error}=await window.sySupabase.from("external_event_sources").select("*").eq("id",id).maybeSingle();
  if(error)throw error; s=data;
 }catch(e){alert(e.message);return}
 if(!s)return;
 const a=s.adapter||s.source_type||"manual", cfg=s.adapter_config||{};
 let adapterFields="";
 if(a==="ical")adapterFields=`<label>Public iCal feed URL</label><input id="sy22SourceUrl" value="${sy19Esc(s.source_url||"")}">`;
 if(a==="eventbrite")adapterFields=`<label>Eventbrite Organization ID</label><input id="sy22OrgId" value="${sy19Esc(cfg.organization_id||"")}"><p class="note">Requires the server secret <b>EVENTBRITE_TOKEN</b>.</p>`;
 if(a==="meetup")adapterFields=`<label>Meetup Pro network URL name</label><input id="sy22MeetupNetwork" value="${sy19Esc(cfg.network_urlname||"")}"><p class="note">Requires Meetup Pro API access and the server secret <b>MEETUP_TOKEN</b>.</p>`;
 openDrawer(`<div class="kicker">${sy22AdapterName(s)}</div><h3>${sy19Esc(s.name)}</h3>
 ${adapterFields}
 <label>Default country</label><input id="sy21Country" value="${sy19Esc(s.default_country||"United States")}">
 <label>Default state / region</label><input id="sy21Region" value="${sy19Esc(s.default_region||"")}" placeholder="Required">
 <label>Default city</label><input id="sy21City" value="${sy19Esc(s.default_city||"")}" placeholder="Required">
 <label>Default public venue (optional fallback)</label><input id="sy21Venue" value="${sy19Esc(s.default_venue_name||"")}" placeholder="Example: City Library">
 <label>Timezone</label><input id="sy21Timezone" value="${sy19Esc(s.default_timezone||"America/Chicago")}" placeholder="Example: America/Chicago">
 <label>Imported organizer label</label><select id="sy21OrgType">
 <option value="official" ${s.organizer_type==="official"?"selected":""}>Sacred Year Official</option>
 <option value="verified" ${(!s.organizer_type||s.organizer_type==="verified")?"selected":""}>Verified Organization</option>
 <option value="trusted" ${s.organizer_type==="trusted"?"selected":""}>Trusted Organizer</option></select>
 <button class="btn" onclick="sy21SaveSource('${id}','${a}')">Save source</button>
 <p class="note">Default city/state are used when the external platform does not provide enough safe public location data. Events without a usable public venue are skipped.</p>`);
}

async function sy21SaveSource(id,adapter){
 let adapter_config={}, source_url;
 if(adapter==="ical"){
   source_url=document.getElementById("sy22SourceUrl")?.value.trim()||null;
   if(!source_url||!/^https:\/\//i.test(source_url)){alert("Enter a public HTTPS iCal URL.");return}
 }else if(adapter==="eventbrite"){
   const organization_id=document.getElementById("sy22OrgId")?.value.trim();
   if(!organization_id){alert("Enter the Eventbrite Organization ID.");return}
   adapter_config={organization_id};
 }else if(adapter==="meetup"){
   const network_urlname=document.getElementById("sy22MeetupNetwork")?.value.trim();
   if(!network_urlname){alert("Enter the Meetup Pro network URL name.");return}
   adapter_config={network_urlname};
 }
 const patch={default_country:document.getElementById("sy21Country").value.trim()||null,default_region:document.getElementById("sy21Region").value.trim()||null,default_city:document.getElementById("sy21City").value.trim()||null,default_venue_name:document.getElementById("sy21Venue").value.trim()||null,default_timezone:document.getElementById("sy21Timezone").value.trim()||"UTC",organizer_type:document.getElementById("sy21OrgType").value,adapter,adapter_config};
 if(source_url!==undefined)patch.source_url=source_url;
 if(!patch.default_region||!patch.default_city){alert("City and state/region are required before automatic import is enabled.");return}
 const {error}=await window.sySupabase.from("external_event_sources").update(patch).eq("id",id);
 if(error){alert(error.message);return}
 sy20EventSources();
}

async function sy21SyncSource(id){
 alert("Automatic external-event sync is temporarily unavailable in the Firebase test build. Existing source settings are unchanged.");
}

async function sy20ToggleSource(id,enabled){
 if(enabled){
   const {data:s}=await window.sySupabase.from("external_event_sources").select("*").eq("id",id).maybeSingle();
   const a=s?.adapter||s?.source_type;
   if(!s?.default_region||!s?.default_city){alert("Configure city and state/region before enabling this source.");return}
   if(a==="ical"&&!s?.source_url){alert("Configure the iCal URL before enabling.");return}
   if(a==="eventbrite"&&!s?.adapter_config?.organization_id){alert("Configure the Eventbrite Organization ID before enabling.");return}
   if(a==="meetup"&&!s?.adapter_config?.network_urlname){alert("Configure the Meetup Pro network URL name before enabling.");return}
 }
 const {error}=await window.sySupabase.from("external_event_sources").update({enabled}).eq("id",id);
 if(error){alert(error.message);return}
 sy20EventSources();
}

window.sy20EventSources=sy20EventSources;
window.sy20AddEventSource=sy20AddEventSource;
window.sy20ToggleSource=sy20ToggleSource;
window.sy21ConfigureSource=sy21ConfigureSource;
window.sy21SaveSource=sy21SaveSource;
window.sy21SyncSource=sy21SyncSource;
window.sy20AddEventSource=sy20AddEventSource;
window.sy20ToggleSource=sy20ToggleSource;

/* Add organizer center into event moderation */
const sy20OldEventModeration=window.sy19EventModeration;
if(sy20OldEventModeration)window.sy19EventModeration=async function(){
 const syAccountScope=window.sy25Scope();

 await window.sy25Await((window.sy25Assert(syAccountScope), (sy20OldEventModeration())),syAccountScope);
 setTimeout(()=>{
  const sheet=document.getElementById("sheet"); if(!sheet)return;
  if(!document.getElementById("sy20OrganizerBtn")){
   const b=document.createElement("button");b.id="sy20OrganizerBtn";b.className="btn secondary";b.style.marginTop="10px";b.textContent="Organizer Center";b.onclick=sy20OrganizerCenter;sheet.appendChild(b);
  }
 },40);
};

/* Add creator-only event tools shortcut to account/settings */
setTimeout(async()=>{
 const role=await sy20GetRole(); if(role!=="creator")return;
 const today=document.querySelector("#today .section-nav");
 if(today&&!document.getElementById("sy20CreatorEvents")){
  /* v23 simplification: organizer tools stay inside event moderation instead of cluttering Today */
 }
},1200);
