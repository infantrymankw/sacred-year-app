
(function(){
  const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
  const client=()=>window.sySupabase||window.supabase;

  async function creatorGate(){
    const c=client();
    if(!c)throw new Error("Sacred Year could not connect to the database.");
    const {data:{session},error}=await c.auth.getSession();
    if(error)throw error;
    if(!session?.user){ openAccount(); return null; }
    const {data:profile,error:pe}=await c.from("profiles").select("role").eq("id",session.user.id).maybeSingle();
    if(pe)throw pe;
    if(profile?.role!=="creator")throw new Error("Creator access is not enabled for this account.");
    return {c,session};
  }

  window.sy328ManagePublishedContent=async function(){
    try{
      const gate=await creatorGate(); if(!gate)return;
      const {c}=gate;
      const {data,error}=await c.from("creator_posts").select("*").order("published_at",{ascending:false}).limit(100);
      if(error)throw error;

      openDrawer(`<div class="kicker">Creator Content</div><h3>Manage Published Content</h3>
        <p class="note">Edit or remove your published Words from the Hall content.</p>
        <div class="sy321-list">${(data||[]).map(p=>`<div class="sy321-item">
          <div class="kicker">${esc(p.label||"Words from the Hall")} • ${esc(p.status||"published")}</div>
          <h4>${esc(p.title||"Words from the Hall")}</h4>
          <p>${esc(p.message||"")}</p>
          <div class="sy321-meta">${p.published_at?syDisplayDate(p.published_at):""}</div>
          <div class="sy321-actions">
            <button type="button" class="btn secondary" data-sy328-action="edit" data-id="${p.id}">Edit</button>
            <button type="button" class="btn secondary sy321-danger" data-sy328-action="delete" data-id="${p.id}">Delete</button>
          </div>
        </div>`).join("")||'<p class="sy321-empty">No published creator content yet.</p>'}</div>
        <button type="button" class="btn secondary" data-sy328-action="creator-back" style="margin-top:14px">Back to Creator Dashboard</button>`);
    }catch(e){ alert(e?.message||"Published content could not be loaded."); }
  };

  window.sy328EditCreatorPost=async function(id){
    try{
      const gate=await creatorGate(); if(!gate)return;
      const {c}=gate;
      const {data:p,error}=await c.from("creator_posts").select("*").eq("id",id).single();
      if(error)throw error;
      openDrawer(`<div class="kicker">Creator Content</div><h3>Edit Published Content</h3>
        <label>Title</label><input id="sy328Title" value="${esc(p.title||"")}">
        <label>Message</label><textarea id="sy328Message" rows="8">${esc(p.message||"")}</textarea>
        <label>Label</label><select id="sy328Label">
          ${["AlanWolfsie Reflection","Modern Practice","Historical Note","Announcement"].map(x=>`<option ${x===p.label?"selected":""}>${x}</option>`).join("")}
        </select>
        <button type="button" class="btn" data-sy328-action="save" data-id="${id}" style="margin-top:14px">Save changes</button>
        <button type="button" class="btn secondary" data-sy328-action="manage-back" style="margin-top:10px">Cancel</button>`);
    }catch(e){ alert(e?.message||"Published content could not be opened."); }
  };

  window.sy328SaveCreatorPost=async function(id){
    try{
      const gate=await creatorGate(); if(!gate)return;
      const {c}=gate;
      const title=(document.getElementById("sy328Title")?.value||"").trim();
      const message=(document.getElementById("sy328Message")?.value||"").trim();
      const label=document.getElementById("sy328Label")?.value||"AlanWolfsie Reflection";
      if(!message){alert("Message cannot be empty.");return}
      const {error}=await c.from("creator_posts").update({title:title||"Words from the Hall",message,label}).eq("id",id);
      if(error)throw error;
      try{ await window.syLoadWord?.(); }catch(e){}
      alert("Published content updated.");
      await window.sy328ManagePublishedContent();
    }catch(e){ alert(e?.message||"Published content could not be updated."); }
  };

  window.sy328DeleteCreatorPost=async function(id){
    if(!confirm("Delete this published Sacred Year post? This cannot be undone."))return;
    try{
      const gate=await creatorGate(); if(!gate)return;
      const {c}=gate;
      const {error}=await c.from("creator_posts").delete().eq("id",id);
      if(error)throw error;
      try{ await window.syLoadWord?.(); }catch(e){}
      alert("Published content removed.");
      await window.sy328ManagePublishedContent();
    }catch(e){ alert(e?.message||"Published content could not be deleted."); }
  };

  // Replace the dashboard opener so Manage always has a direct, durable handler.
  const baseCreator=window.syOpenCreator;
  if(baseCreator){
    window.syOpenCreator=async function(...args){
      const r=await baseCreator.apply(this,args);
      return r;
    };
  }

  // Document-level event delegation survives drawer re-renders and fixes the
  // Android "first tap does nothing" behavior.
  document.addEventListener("click",function(ev){
    const target=ev.target?.closest?.("button, [role='button']");
    if(!target)return;

    if(target.id==="sy325Manage" || target.id==="sy324ManageCard"){
      ev.preventDefault(); ev.stopPropagation();
      window.sy328ManagePublishedContent();
      return;
    }

    const action=target.dataset?.sy328Action;
    if(!action)return;
    ev.preventDefault(); ev.stopPropagation();

    const id=target.dataset.id;
    if(action==="edit") window.sy328EditCreatorPost(id);
    else if(action==="delete") window.sy328DeleteCreatorPost(id);
    else if(action==="save") window.sy328SaveCreatorPost(id);
    else if(action==="manage-back") window.sy328ManagePublishedContent();
    else if(action==="creator-back") window.syOpenCreator?.();
  }, true);

  // Also override older function names so every existing route uses the fixed code.
  window.sy325ManagePublishedContent=window.sy328ManagePublishedContent;
  window.sy322CreatorPosts=window.sy328ManagePublishedContent;
  window.sy322EditCreatorPost=window.sy328EditCreatorPost;
  window.sy322SaveCreatorPost=window.sy328SaveCreatorPost;
  window.sy322DeleteCreatorPost=window.sy328DeleteCreatorPost;
})();
