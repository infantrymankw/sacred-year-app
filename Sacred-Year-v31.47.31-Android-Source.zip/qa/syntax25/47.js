
(function(){
  function esc(v){ return String(v ?? '').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function ops(){ return window.sySupabase || window.supabaseClient || null; }

  window.syOpenCreatorAudioManager = async function(){
 const syAccountScope=window.sy25Scope();

    const m=document.getElementById('syCreatorAudioManager');
    if(!m) return;
    const c=ops(),session=(await window.sy25Await((window.sy25Assert(syAccountScope), (c?.auth.getSession())),syAccountScope))?.data?.session;
    const profile=session?await window.sy25Await((window.sy25Assert(syAccountScope), (c.from('profiles').select('role').eq('id',session.user.id).maybeSingle())),syAccountScope):null;
    if(profile?.data?.role!=='creator'){alert('Creator access is required.');return;}
    m.hidden=false;
    await window.sy25Await((window.sy25Assert(syAccountScope), (window.syLoadCreatorAudioManager())),syAccountScope);
  };
  window.syCloseCreatorAudioManager = function(){
    const m=document.getElementById('syCreatorAudioManager');
    if(m) m.hidden=true;
  };

  async function loadRows(){
 const syAccountScope=window.sy25Scope();

    const c=ops();
    if(!c) throw new Error('Firebase is not ready.');
    if(c.from){
      const q=await window.sy25Await((window.sy25Assert(syAccountScope), (c.from('audio_hall_recordings').select('*').order('submitted_at',{ascending:false}))),syAccountScope);
      if(q.error) throw q.error;
      return q.data||[];
    }
    throw new Error('Recording query adapter unavailable.');
  }

  async function updateRow(id, patch){
 const syAccountScope=window.sy25Scope();

    const c=ops();
    patch.updated_at=new Date().toISOString();
    if(c?.from){
      const r=await window.sy25Await((window.sy25Assert(syAccountScope), (c.from('audio_hall_recordings').update(patch).eq('id',id))),syAccountScope);
      if(r.error) throw r.error;
      return;
    }
    throw new Error('Recording update adapter unavailable.');
  }

  async function deleteRow(id){
 const syAccountScope=window.sy25Scope();

    const c=ops();
    if(c?.from){
      const r=await window.sy25Await((window.sy25Assert(syAccountScope), (c.from('audio_hall_recordings').delete().eq('id',id))),syAccountScope);
      if(r.error) throw r.error;
      return;
    }
    throw new Error('Recording delete adapter unavailable.');
  }

  async function audioUrl(path){
 const syAccountScope=window.sy25Scope();

    try{
      const c=ops();
      if(c?.storage?.from){
        const r=await window.sy25Await((window.sy25Assert(syAccountScope), (c.storage.from('audio-hall').createSignedUrl(path.replace(/^audio-hall\//,''),3600))),syAccountScope);
        return r?.data?.signedUrl || r?.data?.publicUrl || null;
      }
    }catch(e){ console.warn(e); }
    return null;
  }

  window.syCreatorAudioSave = async function(id){
 const syAccountScope=window.sy25Scope();

    const root=document.querySelector('[data-audio-card="'+CSS.escape(id)+'"]');
    if(!root) return;
    const patch={
      title:root.querySelector('[data-f="title"]').value.trim(),
      description:root.querySelector('[data-f="description"]').value.trim(),
      category:root.querySelector('[data-f="category"]').value,
      discussion_enabled:root.querySelector('[data-f="discussion"]').checked,
      notify_questions:root.querySelector('[data-f="notify"]').checked
    };
    try{ await window.sy25Await((window.sy25Assert(syAccountScope), (updateRow(id,patch))),syAccountScope); alert('Recording updated.'); await window.sy25Await((window.sy25Assert(syAccountScope), (syLoadCreatorAudioManager())),syAccountScope); }
    catch(e){ alert(e.message||String(e)); }
  };

  window.syCreatorAudioStatus = async function(id,status){
 const syAccountScope=window.sy25Scope();

    if(!['pending','published','rejected'].includes(status))return;
    const card=document.querySelector('[data-audio-card="'+CSS.escape(id)+'"]');
    if(card?.dataset.busy)return;
    const patch={status,rejection_reason:null};
    if(status==='published') patch.published_at=new Date().toISOString();
    if(status==='rejected'){const reason=prompt('Optional rejection reason:');if(reason===null)return;patch.rejection_reason=reason;}
    if(status==='pending')patch.published_at=null;
    if(card){card.dataset.busy='1';card.querySelectorAll('button').forEach(b=>b.disabled=true);}
    try{ await window.sy25Await((window.sy25Assert(syAccountScope), (updateRow(id,patch))),syAccountScope); await window.sy25Await((window.sy25Assert(syAccountScope), (syLoadCreatorAudioManager())),syAccountScope); window.sy25RefreshActivity?.(); alert('Recording '+status+'.'); }
    catch(e){ if(card){delete card.dataset.busy;card.querySelectorAll('button').forEach(b=>b.disabled=false);} alert(e.message||String(e)); }
  };

  window.syCreatorAudioRemove = async function(id,path){
 const syAccountScope=window.sy25Scope();

    if(!confirm('Remove this recording?')) return;
    try{
      const c=ops();
      if(path && c?.storage?.from){
        await window.sy25Await((window.sy25Assert(syAccountScope), (c.storage.from('audio-hall').remove([path.replace(/^audio-hall\//,'')]))),syAccountScope);
      }
      await window.sy25Await((window.sy25Assert(syAccountScope), (deleteRow(id))),syAccountScope);
      alert('Recording removed.');
      await window.sy25Await((window.sy25Assert(syAccountScope), (syLoadCreatorAudioManager())),syAccountScope);
    }catch(e){ alert(e.message||String(e)); }
  };

  window.syLoadCreatorAudioManager = async function(){
 const syAccountScope=window.sy25Scope();

    const list=document.getElementById('syCreatorAudioList');
    if(!list) return;
    list.innerHTML='<p class="muted">Loading recordings…</p>';
    try{
      const rows=await window.sy25Await((window.sy25Assert(syAccountScope), (loadRows())),syAccountScope);
      if(!rows.length){ list.innerHTML='<p class="muted">No Hall+ recordings found.</p>'; return; }
      const items=[];
      for(const r of rows) items.push([r, await window.sy25Await((window.sy25Assert(syAccountScope), (audioUrl(r.storage_path||''))),syAccountScope)]);
      list.innerHTML=items.map(([r,url])=>`
        <article class="account-card" data-audio-card="${esc(r.id)}" style="display:block;margin:12px 0;">
          <div style="display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;">
            <div>
              <div class="eyebrow">${esc((r.status||'pending').toUpperCase())}</div>
              <strong>${esc(r.title||'Untitled recording')}</strong>
              <div class="muted">${esc(r.category||'Other')}</div>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
              ${r.upload_complete===false?'Upload incomplete':r.status==='published'?`<button type="button" onclick="syCreatorAudioStatus('${esc(r.id)}','pending')">Unpublish</button>`:r.status!=='removed'?`<button type="button" onclick="syCreatorAudioStatus('${esc(r.id)}','published')">Publish</button>${r.status==='pending'?`<button type="button" onclick="syCreatorAudioStatus('${esc(r.id)}','rejected')">Reject</button>`:''}`:''}
              <button type="button" onclick="syCreatorAudioRemove('${esc(r.id)}','${esc(r.storage_path||'')}')">Remove</button>
            </div>
          </div>
          ${url?`<audio controls preload="metadata" src="${esc(url)}" style="width:100%;margin:12px 0;"></audio>`:'<p class="muted">Audio preview unavailable.</p>'}
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">
            <label>Title<input data-f="title" value="${esc(r.title||'')}"></label>
            <label>Category<select data-f="category">
              ${['Ritual','Teaching','Lesson','Prayer / Invocation','Meditation','Story / Myth','Other'].map(c=>`<option ${r.category===c?'selected':''}>${esc(c)}</option>`).join('')}
            </select></label>
            <label style="grid-column:1/-1">Description<textarea data-f="description" rows="3">${esc(r.description||'')}</textarea></label>
            <label><input type="checkbox" data-f="discussion" ${r.discussion_enabled!==false?'checked':''}> Allow questions/comments</label>
            <label><input type="checkbox" data-f="notify" ${r.notify_questions?'checked':''}> Question notifications preference</label>
          </div>
          <div style="margin-top:10px"><button type="button" onclick="syCreatorAudioSave('${esc(r.id)}')">Save changes</button></div>
        </article>`).join('');
    }catch(e){
      console.error(e);
      list.innerHTML='<p class="muted">Could not load recordings: '+esc(e.message||String(e))+'</p>';
    }
  };
})();
