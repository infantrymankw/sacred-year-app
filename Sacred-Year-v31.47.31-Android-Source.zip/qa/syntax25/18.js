
const SY24_GODS={
 odin:{name:"Óðinn / Odin",group:"Æsir",tags:["wisdom","poetry","runes","war","the dead"],
 summary:"A complex god of wisdom-seeking, poetry, ecstatic inspiration, rulership, war, magic, and the dead.",
 stories:"He sacrifices himself on the wind-swept tree to gain runes in Hávamál; wins the mead of poetry in the skaldic tradition; questions Vafþrúðnir; and repeatedly travels in disguise seeking knowledge.",
 sources:"Hávamál, Vafþrúðnismál, Grímnismál, Völuspá, Lokasenna, Prose Edda, skaldic poetry.",
 evidence:"Odin is exceptionally well attested, but modern claims that reduce him to a single role such as a generic 'god of wisdom' miss how unsettling and contradictory he can be in the sources."},
 thor:{name:"Þórr / Thor",group:"Æsir",tags:["thunder","protection","strength","jötnar"],
 summary:"A widely attested god associated with thunder, protection, strength, and the defense of gods and humans.",
 stories:"He fishes for Jörmungandr, journeys to Útgarða-Loki, retrieves Mjölnir after Þrymr steals it, and confronts numerous jötnar.",
 sources:"Þrymskviða, Hymiskviða, Hárbarðsljóð, Lokasenna, Prose Edda; archaeological hammer amulets and inscriptions.",
 evidence:"Thor's hammer was a powerful religious symbol in the Viking Age. Modern portrayals often emphasize warrior strength, but protection and hallowing are also important."},
 frigg:{name:"Frigg",group:"Æsir",tags:["foreknowledge","marriage","queenship","Baldr"],
 summary:"A major goddess, wife of Odin, associated in the surviving material with queenship, marriage, foreknowledge, and the story of Baldr.",
 stories:"She obtains oaths from things not to harm Baldr, but mistletoe is omitted; Lokasenna and other poems preserve additional glimpses of her status and knowledge.",
 sources:"Völuspá, Lokasenna, Grímnismál, Prose Edda.",
 evidence:"Modern lists sometimes assign Frigg a tidy portfolio of 'home and motherhood.' Some of that may fit later interpretation, but the medieval evidence is more limited and nuanced."},
 freyja:{name:"Freyja",group:"Vanir",tags:["seiðr","desire","wealth","the dead","Brísingamen"],
 summary:"A prominent Vanir goddess associated with desire, wealth, seiðr, precious objects, and a share of the battle-dead.",
 stories:"She owns Brísingamen; receives half of those slain in battle at Fólkvangr according to Grímnismál; and is repeatedly sought as a bride by hostile beings.",
 sources:"Grímnismál, Lokasenna, Þrymskviða, Hyndluljóð, Prose Edda.",
 evidence:"Calling Freyja merely a 'love goddess' badly understates her. The sources give her connections to magic, death, status, sexuality, wealth, and conflict."},
 freyr:{name:"Freyr",group:"Vanir",tags:["prosperity","peace","fertility","Álfheimr"],
 summary:"A Vanir god strongly associated with prosperity, good seasons, peace, fertility, and sacral rulership.",
 stories:"Grímnismál says Álfheimr was given to him as a tooth-gift. Skírnismál tells of his desire for Gerðr and the surrender of his sword.",
 sources:"Grímnismál, Skírnismál, Lokasenna, Prose Edda, Ynglinga saga, place-name evidence.",
 evidence:"Freyr's cult appears to have been important in Scandinavia, but later saga descriptions must be distinguished from contemporary pagan evidence."},
 tyr:{name:"Týr / Tyr",group:"Æsir",tags:["Fenrir","courage","assembly/law?"],
 summary:"An old Germanic god best known in Norse myth for sacrificing his hand when the gods bind Fenrir.",
 stories:"Týr alone places his hand in Fenrir's mouth as a pledge while the gods test Gleipnir; when the wolf realizes he is trapped, the hand is bitten off.",
 sources:"Lokasenna, Hymiskviða, Prose Edda; comparative Germanic evidence including the weekday name Tuesday.",
 evidence:"Týr is often confidently labeled 'the god of law and justice.' There are reasons for that interpretation, but the surviving Old Norse material does not give us a simple job description."},
 njord:{name:"Njörðr / Njord",group:"Vanir",tags:["sea","ships","wealth","Noatun"],
 summary:"A Vanir god connected with seafaring, favorable winds, wealth, and the coastal dwelling Nóatún.",
 stories:"Njörðr and Skaði attempt to divide their time between sea and mountains, but neither can tolerate the other's preferred home.",
 sources:"Grímnismál, Lokasenna, Prose Edda, Ynglinga saga.",
 evidence:"His maritime and prosperity associations are well represented in literary sources, though details of actual cult practice remain incomplete."},
 loki:{name:"Loki",group:"Complex/Æsir-associated",tags:["trickery","shape-changing","Baldr","Ragnarök"],
 summary:"A profoundly ambiguous mythic figure: companion and problem-solver of the gods in some stories, their enemy in others, and central to Baldr's death and Ragnarök in Snorri's account.",
 stories:"Loki helps recover Iðunn, engineers treasures of the gods, insults the divine assembly in Lokasenna, and is bound after Baldr's death in the prose tradition.",
 sources:"Lokasenna, Þrymskviða, Reginsmál, Haustlöng, Prose Edda.",
 evidence:"There is little secure evidence for a widespread pre-Christian cult of Loki. Modern devotional practice exists, but it should not be projected backward as established Viking-age practice."},
 heimdall:{name:"Heimdallr / Heimdall",group:"Æsir",tags:["watchman","Gjallarhorn","Bifröst"],
 summary:"The watchman of the gods, famous for keen senses and his role at the onset of Ragnarök.",
 stories:"He guards Bifröst, possesses Gjallarhorn, contests with Loki, and is linked enigmatically to humanity and social classes in Rígsþula.",
 sources:"Völuspá, Grímnismál, Lokasenna, Rígsþula, Prose Edda.",
 evidence:"Heimdall's mythology contains tantalizing fragments. Attempts to force every fragment into one clean modern profile go beyond the evidence."},
 baldr:{name:"Baldr",group:"Æsir",tags:["death","dreams","Hel","Ragnarök"],
 summary:"A son of Odin and Frigg whose death becomes one of the central tragedies of Norse mythology.",
 stories:"After ominous dreams, Baldr becomes seemingly invulnerable. Höðr kills him with mistletoe through Loki's intervention in Snorri's account. Hermóðr rides to Hel seeking his return.",
 sources:"Baldrs draumar, Völuspá, Lokasenna, Prose Edda; Saxo preserves a strikingly different version.",
 evidence:"Baldr's story demonstrates why comparing sources matters: Snorri and Saxo do not tell the same story."},
 idunn:{name:"Iðunn / Idunn",group:"Æsir-associated",tags:["apples","youth","poetry"],
 summary:"Keeper of apples associated with the gods' continued youth in Snorri's account.",
 stories:"The jötunn Þjazi abducts Iðunn after Loki's involvement, and the gods begin to age until Loki brings her back.",
 sources:"Lokasenna; Haustlöng; Prose Edda.",
 evidence:"The famous youth-restoring apples are especially clear in Snorri. We should avoid automatically turning Iðunn into a broad modern 'goddess of youth' without qualification."},
 skadi:{name:"Skaði / Skadi",group:"Jötunn / divine marriage",tags:["mountains","skiing","hunting","Njörðr"],
 summary:"A jötunn who comes armed to the gods seeking compensation for her father Þjazi and becomes the wife of Njörðr.",
 stories:"She chooses a husband by looking only at the gods' feet and selects Njörðr rather than Baldr; their incompatible homes lead to separation in the mythic narrative.",
 sources:"Grímnismál, Lokasenna, Prose Edda.",
 evidence:"Skaði is a useful reminder that the boundary between 'gods' and jötnar is not a simple good-versus-evil divide."},
 nerthus:{name:"Nerthus",group:"Germanic goddess",tags:["earth","peace","procession","Tacitus"],
 summary:"A goddess described by the Roman author Tacitus among Germanic peoples centuries before the Viking Age.",
 stories:"Tacitus describes a sacred vehicle/procession connected with Nerthus, during which weapons are put away and peace is observed.",
 sources:"Tacitus, Germania 40.",
 evidence:"Nerthus is not attested in the Old Norse Eddas. A linguistic relationship with Njörðr is widely discussed by scholars, but reconstructing her directly into Viking-age Norse practice requires caution."},
 eostre:{name:"Ēostre / Ostara",group:"Anglo-Saxon goddess",tags:["spring?","Bede","Ēosturmōnaþ"],
 summary:"A goddess named by the eighth-century English scholar Bede in his explanation of the month Ēosturmōnaþ.",
 stories:"Bede says the month had once been named for a goddess called Eostre and that Christian Paschal celebrations later occupied that season.",
 sources:"Bede, The Reckoning of Time (De temporum ratione), chapter 15.",
 evidence:"Ēostre is Anglo-Saxon evidence, not an attested Norse goddess from the Eddas. Rabbits, eggs, dawn mythology, and elaborate 'Ostara' stories commonly circulated today are not supplied by Bede's short notice."}
};

function sy24GodsStudy(){
 const order=["odin","thor","frigg","freyja","freyr","tyr","njord","loki","heimdall","baldr","idunn","skadi","nerthus","eostre"];
 openDrawer(`<div class="kicker">Study Hall</div><h3>Gods, Goddesses & Divine Figures</h3>
 <p class="note">These are study profiles, not a fixed pantheon checklist. Tap a figure for stories, source trails, and an evidence note separating the medieval record from later interpretation.</p>
 <div class="sy24-godgrid">${order.map(id=>{const g=SY24_GODS[id];return `<button class="sy24-god" onclick="sy24OpenGod('${id}')"><div class="kicker">${g.group}</div><h4>${g.name}</h4><p>${g.summary}</p></button>`}).join("")}</div>
 <div class="holiday" style="margin-top:12px"><div class="kicker">Important</div><p>Norse religion was never a modern character encyclopedia. Local cult, family tradition, place, time period, and social role mattered, and our surviving evidence is uneven.</p></div>`);
}
function sy24OpenGod(id){
 const g=SY24_GODS[id];if(!g)return;
 openDrawer(`<div class="kicker">${g.group}</div><h3>${g.name}</h3>
 <div>${g.tags.map(t=>`<span class="sy24-tag">${t}</span>`).join("")}</div>
 <div class="item" style="margin-top:10px"><h4>Who is this figure?</h4><p>${g.summary}</p></div>
 <div class="item" style="margin-top:10px"><h4>Stories to know</h4><p>${g.stories}</p></div>
 <div class="item" style="margin-top:10px"><h4>Source trail</h4><p>${g.sources}</p></div>
 <div class="holiday" style="margin-top:10px"><div class="kicker">Evidence note</div><p class="sy24-evidence">${g.evidence}</p></div>
 <button class="btn secondary" onclick="sy24GodsStudy()">Back to Gods & Goddesses</button>`);
}
window.sy24GodsStudy=sy24GodsStudy;window.sy24OpenGod=sy24OpenGod;

/* Upgrade existing Gods/Goddesses doors when possible, without removing old content. */
setTimeout(()=>{
 const candidates=[...document.querySelectorAll("button,.section-card")];
 const old=candidates.find(x=>/gods\s*&\s*goddesses|gods and goddesses/i.test((x.textContent||"").trim()));
 if(old&&!old.dataset.sy24){old.dataset.sy24="1";old.onclick=sy24GodsStudy;}
},700);
