
(function(){
const sb=()=>window.sySupabase||window.supabase;
const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
async function creatorSession(){
  const c=sb(); if(!c) return null;
  const {data:{session}}=await c.auth.getSession();
  if(!session?.user) return null;
  const {data:p}=await c.from("profiles").select("id,display_name,role").eq("id",session.user.id).maybeSingle();
  return p?.role==="creator"?{session,profile:p}:null;
}
async function ensureCreator(){
  const x=await creatorSession();
  if(!x){alert("Creator access is not enabled for this account.");return null}
  return x;
}
async function audit(action_type,target_type,target_id,target_label,notes){
  const x=await creatorSession(); if(!x) return;
  try{await sb().from("community_moderation_actions").insert({
    moderator_id:x.session.user.id,action_type,target_type,target_id:String(target_id||""),
    target_label:target_label||null,notes:notes||null
  })}catch(e){}
}
async function counts(){
  const c=sb();
  const [cr,mr,er,pe]=await Promise.all([
    c.from("community_reports").select("id",{count:"exact",head:true}).eq("status","open"),
    c.from("moderation_reports").select("id",{count:"exact",head:true}).in("status",["submitted","open"]),
    c.from("community_event_reports").select("id",{count:"exact",head:true}).eq("status","open"),
    c.from("community_events").select("id",{count:"exact",head:true}).eq("status","pending")
  ]);
  return {reports:(cr.count||0)+(mr.count||0)+(er.count||0),pending:pe.count||0};
}

window.syOpenCreator=async function(){
  const x=await ensureCreator(); if(!x)return;
  const n=await counts();
  openDrawer(`<div class="kicker">Private Creator Dashboard</div><h3>Creator Control Center</h3>
    <p class="note">Publishing and moderation tools are available only to the creator account.</p>
    <div class="sy321-grid">
      <button class="sy321-card" onclick="sy321OpenPublisher()"><div class="kicker">Publish</div><h4>Words from the Hall</h4><p>Create a Sacred Year announcement or reflection.</p></button>
      <button class="sy321-card" onclick="sy321ModerationHome()"><div class="kicker">Moderation</div><h4>Moderation Center</h4><p>${n.reports} open report${n.reports===1?"":"s"} • ${n.pending} pending event${n.pending===1?"":"s"}</p></button>
    </div>
    <button class="btn secondary" onclick="openAccount()">Back to account</button>`);
};

window.sy321OpenPublisher=function(){
  openDrawer(`<div class="kicker">Private Creator Dashboard</div><h3>Words from the Hall</h3>
  <label>Title</label><input id="syPT" value="Words from the Hall"/>
  <label>Message</label><textarea id="syPM" rows="6"></textarea>
  <label>Label</label><select id="syPL"><option>AlanWolfsie Reflection</option><option>Modern Practice</option><option>Historical Note</option><option>Announcement</option></select>
  <label><input id="syPN" type="checkbox" checked style="width:auto;margin-right:7px">Queue notification</label>
  <button class="btn" style="margin-top:14px" onclick="syPublish()">Publish</button>
  <button class="btn secondary" style="margin-top:10px" onclick="sy321ModerationHome()">Moderation Center</button>`);
};

window.sy321ModerationHome=async function(){
  const x=await ensureCreator(); if(!x)return;
  const n=await counts();
  openDrawer(`<div class="kicker">Creator Moderation</div><h3>Moderation Center</h3>
    <p class="note">Review reports, moderate community content, approve events, restrict community access, and review the moderation audit trail.</p>
    <div class="sy321-grid">
      <button class="sy321-card" onclick="sy321Reports()"><div class="kicker">Queue</div><h4>Reports</h4><p>${n.reports} open report${n.reports===1?"":"s"}</p></button>
      <button class="sy321-card" onclick="sy321Posts()"><div class="kicker">Community</div><h4>Posts & Replies</h4><p>Hide, restore, or permanently remove content.</p></button>
      <button class="sy321-card" onclick="sy321Events()"><div class="kicker">Events</div><h4>Event Moderation</h4><p>${n.pending} pending event${n.pending===1?"":"s"} • approve, reject, or remove.</p></button>
      <button class="sy321-card" onclick="sy321Users()"><div class="kicker">Members</div><h4>User Restrictions</h4><p>Suspend or restore Community Hall posting access.</p></button>
      <button class="sy321-card" onclick="sy321Audit()"><div class="kicker">History</div><h4>Audit Trail</h4><p>Review recent moderation actions.</p></button>
    </div>
    <button class="btn secondary" onclick="syOpenCreator()">Back to Creator Dashboard</button>`);
};

window.sy321Reports=async function(){
  const x=await ensureCreator();if(!x)return;
  const c=sb();
  const [a,b,d]=await Promise.all([
    c.from("community_reports").select("*").eq("status","open").order("created_at",{ascending:false}).limit(50),
    c.from("moderation_reports").select("*").in("status",["submitted","open"]).order("created_at",{ascending:false}).limit(50),
    c.from("community_event_reports").select("*").eq("status","open").order("created_at",{ascending:false}).limit(50)
  ]);
  let rows=[];
  (a.data||[]).forEach(r=>rows.push({kind:r.post_id?"post":"reply",id:r.id,target:r.post_id||r.reply_id,reason:r.reason,created_at:r.created_at}));
  (b.data||[]).forEach(r=>rows.push({kind:(r.target_event_id?"event":r.target_user_id?"user":"general"),id:r.id,target:r.target_event_id||r.target_user_id||"",label:r.target_label,reason:r.details,created_at:r.created_at,table:"moderation_reports"}));
  (d.data||[]).forEach(r=>rows.push({kind:"event",id:r.id,target:r.event_id,reason:r.reason,created_at:r.created_at,table:"community_event_reports"}));
  rows.sort((u,v)=>new Date(v.created_at)-new Date(u.created_at));
  openDrawer(`<div class="kicker">Creator Moderation</div><h3>Open Reports</h3>
   <div class="sy321-list">${rows.map(r=>`<div class="sy321-item">
    <div class="kicker">${esc(r.kind)} report</div>
    <h4>${esc(r.label||"Reported content")}</h4>
    <p>${esc(r.reason)}</p><div class="sy321-meta">${syDisplayDate(r.created_at)}</div>
    <div class="sy321-actions">
      ${r.kind==="post"?`<button class="btn secondary" onclick="sy321ContentAction('hide','post','${r.target}','${r.id}')">Hide post</button><button class="btn secondary sy321-danger" onclick="sy321ContentAction('delete','post','${r.target}','${r.id}')">Remove post</button>`:""}
      ${r.kind==="reply"?`<button class="btn secondary" onclick="sy321ContentAction('hide','reply','${r.target}','${r.id}')">Hide reply</button><button class="btn secondary sy321-danger" onclick="sy321ContentAction('delete','reply','${r.target}','${r.id}')">Remove reply</button>`:""}
      ${r.kind==="event"?`<button class="btn secondary sy321-danger" onclick="sy321RemoveEvent('${r.target}','${r.id}','${r.table||"community_reports"}')">Remove event</button>`:""}
      ${r.kind==="user"&&r.target?`<button class="btn secondary" onclick="sy321Suspend('${r.target}',true,'Reported user')">Suspend posting</button>`:""}
      <button class="btn secondary" onclick="sy321ResolveReport('${r.id}','${r.table||"community_reports"}','dismissed')">Dismiss</button>
      <button class="btn secondary" onclick="sy321ResolveReport('${r.id}','${r.table||"community_reports"}','reviewed')">Mark reviewed</button>
    </div>
   </div>`).join("")||'<p class="sy321-empty">No open reports.</p>'}</div>
   <button class="btn secondary" style="margin-top:14px" onclick="sy321ModerationHome()">Back</button>`);
};

window.sy321ResolveReport=async function(id,table,status){
  const c=sb();
  let writeStatus=status;
  if(table==="moderation_reports"){
    // moderation_reports has a tighter status CHECK; resolve creator-reviewed items safely.
    writeStatus = (status==="dismissed"||status==="reviewed"||status==="actioned") ? "resolved" : status;
  }
  const {error}=await c.from(table).update({status:writeStatus}).eq("id",id);
  if(error){alert(error.message);return}
  await audit("report_"+status,"report",id,table,null);
  sy321Reports();
};

window.sy321ContentAction=async function(action,kind,id,reportId){
  const table=kind==="post"?"community_posts":"community_replies";
  if(action==="delete"&&!confirm("Permanently remove this "+kind+"? This cannot be undone."))return;
  let q=action==="hide"?sb().from(table).update({is_hidden:true}).eq("id",id):sb().from(table).delete().eq("id",id);
  const {error}=await q;if(error){alert(error.message);return}
  if(reportId)await sb().from("community_reports").update({status:"actioned"}).eq("id",reportId);
  await audit(action+"_"+kind,kind,id,null,reportId?"Action taken from report "+reportId:null);
  alert(action==="hide"?"Content hidden.":"Content removed.");
  sy321Reports();
};

window.sy321Posts=async function(){
  const x=await ensureCreator();if(!x)return;
  const c=sb();
  const [p,r]=await Promise.all([
    c.from("community_posts").select("id,user_id,channel,title,body,is_hidden,created_at").order("created_at",{ascending:false}).limit(80),
    c.from("community_replies").select("id,post_id,user_id,body,is_hidden,created_at").order("created_at",{ascending:false}).limit(80)
  ]);
  const userIds=[...new Set([...(p.data||[]).map(x=>x.user_id),...(r.data||[]).map(x=>x.user_id)])];
  let names={};
  if(userIds.length){const {data:ps}=await c.from("profiles").select("id,display_name").in("id",userIds);(ps||[]).forEach(x=>names[x.id]=x.display_name||"Member")}
  const posts=(p.data||[]).map(x=>({...x,kind:"post"}));
  const reps=(r.data||[]).map(x=>({...x,kind:"reply",title:"Reply"}));
  const rows=[...posts,...reps].sort((a,b)=>new Date(b.created_at)-new Date(a.created_at));
  openDrawer(`<div class="kicker">Creator Moderation</div><h3>Posts & Replies</h3>
   <div class="sy321-list">${rows.map(r=>`<div class="sy321-item">
    <div class="kicker">${r.kind} • ${r.kind==="post"?esc(r.channel):"thread reply"} ${r.is_hidden?"• hidden":""}</div>
    <h4>${esc(r.title||"Community post")}</h4><p>${esc(r.body)}</p>
    <div class="sy321-meta">By ${esc(names[r.user_id]||"Member")} • ${syDisplayDate(r.created_at)}</div>
    <div class="sy321-actions">
      <button class="btn secondary" onclick="sy321SetHidden('${r.kind}','${r.id}',${!r.is_hidden})">${r.is_hidden?"Restore":"Hide"}</button>
      <button class="btn secondary sy321-danger" onclick="sy321DeleteContent('${r.kind}','${r.id}')">Permanently remove</button>
      <button class="btn secondary" onclick="sy321Suspend('${r.user_id}',true,'Community content moderation')">Suspend member</button>
    </div></div>`).join("")||'<p class="sy321-empty">No community content found.</p>'}</div>
   <button class="btn secondary" style="margin-top:14px" onclick="sy321ModerationHome()">Back</button>`);
};
window.sy321SetHidden=async function(kind,id,hidden){
  const table=kind==="post"?"community_posts":"community_replies";
  const {error}=await sb().from(table).update({is_hidden:hidden}).eq("id",id);
  if(error){alert(error.message);return}
  await audit(hidden?"hide_content":"restore_content",kind,id,null,null);sy321Posts();
};
window.sy321DeleteContent=async function(kind,id){
  if(!confirm("Permanently remove this "+kind+"? This cannot be undone."))return;
  const table=kind==="post"?"community_posts":"community_replies";
  const {error}=await sb().from(table).delete().eq("id",id);
  if(error){alert(error.message);return}
  await audit("delete_content",kind,id,null,null);sy321Posts();
};

window.sy321Events=async function(){
  const x=await ensureCreator();if(!x)return;
  const {data,error}=await sb().from("community_events").select("*").order("created_at",{ascending:false}).limit(100);
  if(error){alert(error.message);return}
  openDrawer(`<div class="kicker">Creator Moderation</div><h3>Event Moderation</h3>
   <div class="sy321-list">${(data||[]).map(e=>`<div class="sy321-item">
    <div class="kicker">${esc(e.status)} • ${esc(e.organizer_type)}</div>
    <h4>${esc(e.title)}</h4><p>${esc(e.description||"")}</p>
    <div class="sy321-meta">${syDisplayDate(e.starts_at)} • ${esc(e.city)}, ${esc(e.region)} • ${esc(e.venue_name)}</div>
    <div class="sy321-actions">
      ${e.status!=="approved"?`<button class="btn secondary" onclick="sy321EventStatus('${e.id}','approved','${esc(e.title).replace(/'/g,"&#039;")}')">Approve</button>`:""}
      ${e.status!=="rejected"?`<button class="btn secondary" onclick="sy321EventStatus('${e.id}','rejected','${esc(e.title).replace(/'/g,"&#039;")}')">Reject</button>`:""}
      <button class="btn secondary sy321-danger" onclick="sy321DeleteEvent('${e.id}','${esc(e.title).replace(/'/g,"&#039;")}')">Remove event</button>
    </div></div>`).join("")||'<p class="sy321-empty">No events found.</p>'}</div>
   <button class="btn secondary" style="margin-top:14px" onclick="sy321ModerationHome()">Back</button>`);
};
window.sy321EventStatus=async function(id,status,label){
  const {error}=await sb().from("community_events").update({status,updated_at:new Date().toISOString()}).eq("id",id);
  if(error){alert(error.message);return}
  await audit("event_"+status,"event",id,label,null);sy321Events();
};
window.sy321DeleteEvent=async function(id,label){
  if(!confirm("Permanently remove this event? This cannot be undone."))return;
  const {error}=await sb().from("community_events").delete().eq("id",id);
  if(error){alert(error.message);return}
  await audit("delete_event","event",id,label,null);alert("Event removed.");sy321Events();
};
window.sy321RemoveEvent=async function(id,reportId,reportTable){
  if(!confirm("Remove the reported event? This cannot be undone."))return;
  const {error}=await sb().from("community_events").delete().eq("id",id);
  if(error){alert(error.message);return}
  if(reportId&&reportTable)await sb().from(reportTable).update({status:"actioned"}).eq("id",reportId);
  await audit("delete_event","event",id,null,reportId?"Action taken from report "+reportId:null);sy321Reports();
};

window.sy321Users=async function(){
  const x=await ensureCreator();if(!x)return;
  const c=sb();
  const [p,m]=await Promise.all([
    c.from("profiles").select("id,display_name,role").order("display_name",{ascending:true}).limit(100),
    c.from("community_user_moderation").select("*")
  ]);
  let mm={};(m.data||[]).forEach(x=>mm[x.user_id]=x);
  const rows=(p.data||[]).filter(u=>u.role!=="creator");
  openDrawer(`<div class="kicker">Creator Moderation</div><h3>User Restrictions</h3>
   <p class="note">Suspension blocks new Community Hall posts and replies without deleting the person's Sacred Year account.</p>
   <div class="sy321-list">${rows.map(u=>{const s=!!mm[u.id]?.suspended;return `<div class="sy321-item">
     <div class="kicker">${s?"Community posting suspended":"Member"}</div><h4>${esc(u.display_name||"Sacred Year member")}</h4>
     ${mm[u.id]?.reason?`<p>${esc(mm[u.id].reason)}</p>`:""}
     <div class="sy321-actions"><button class="btn secondary" onclick="sy321Suspend('${u.id}',${!s},'Manual creator moderation')">${s?"Restore posting":"Suspend posting"}</button></div>
   </div>`}).join("")||'<p class="sy321-empty">No members found.</p>'}</div>
   <button class="btn secondary" style="margin-top:14px" onclick="sy321ModerationHome()">Back</button>`);
};
window.sy321Suspend=async function(userId,suspended,reason){
  const x=await ensureCreator();if(!x)return;
  const {error}=await sb().from("community_user_moderation").upsert({
    user_id:userId,suspended,reason:suspended?(reason||"Creator moderation"):null,
    updated_by:x.session.user.id,updated_at:new Date().toISOString()
  },{onConflict:"user_id"});
  if(error){alert(error.message);return}
  await audit(suspended?"suspend_community_posting":"restore_community_posting","user",userId,null,reason||null);
  alert(suspended?"Community posting suspended.":"Community posting restored.");
  if(document.querySelector(".drawer"))sy321Users();
};

window.sy321Audit=async function(){
  const x=await ensureCreator();if(!x)return;
  const {data,error}=await sb().from("community_moderation_actions").select("*").order("created_at",{ascending:false}).limit(100);
  if(error){alert(error.message);return}
  openDrawer(`<div class="kicker">Creator Moderation</div><h3>Audit Trail</h3>
   <div class="sy321-list">${(data||[]).map(a=>`<div class="sy321-item">
    <div class="kicker">${esc(a.action_type)} • ${esc(a.target_type)}</div>
    <h4>${esc(a.target_label||a.target_id||"Moderation action")}</h4>
    ${a.notes?`<p>${esc(a.notes)}</p>`:""}<div class="sy321-meta">${syDisplayDate(a.created_at)}</div>
   </div>`).join("")||'<p class="sy321-empty">No moderation actions recorded yet.</p>'}</div>
   <button class="btn secondary" style="margin-top:14px" onclick="sy321ModerationHome()">Back</button>`);
};

// Give creator visible controls directly in Community Hall post cards too.
const oldRender=window.syCommunityRender;
if(oldRender){
  window.syCommunityRender=async function(){
 const syAccountScope=window.sy25Scope();

    await window.sy25Await((window.sy25Assert(syAccountScope), (oldRender())),syAccountScope);
    const x=await window.sy25Await((window.sy25Assert(syAccountScope), (creatorSession())),syAccountScope); if(!x)return;
    const feed=document.getElementById("syCommunityFeed"); if(!feed)return;
    feed.querySelectorAll(".community-post").forEach(card=>{
      const id=card.querySelector("button[onclick*='syCommunityOpenThread']")?.getAttribute("onclick")?.match(/'([^']+)'/)?.[1];
      if(!id)return;
      const actions=card.querySelector(".community-actions"); if(!actions)return;
      if(!actions.querySelector(".sy321-mod-remove")){
        const b=document.createElement("button");b.className="btn secondary sy321-mod-remove";b.textContent="Moderator remove";
        b.onclick=()=>sy321DeleteContent("post",id);actions.appendChild(b);
      }
    });
  };
}

// Creator controls on public event cards.
const oldEventRender=window.sy19RenderEvents;
if(oldEventRender){
  window.sy19RenderEvents=function(){
    oldEventRender();
    creatorSession().then(x=>{
      if(!x)return;
      document.querySelectorAll(".sy19-event").forEach((card,i)=>{
        const e=window.sy19Events?.[i]; if(!e)return;
        let actions=card.querySelector(".community-actions");if(!actions)return;
        if(!actions.querySelector(".sy321-event-remove")){
          const b=document.createElement("button");b.className="btn secondary sy321-event-remove";b.textContent="Creator remove";
          b.onclick=()=>sy321DeleteEvent(e.id,e.title);actions.appendChild(b);
        }
      });
    });
  };
}
})();
