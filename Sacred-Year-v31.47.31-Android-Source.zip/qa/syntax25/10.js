
const SY_RITUALS=[
 {id:"blot",name:"Blót",icon:"🔥",label:"Historically rooted / modern reconstruction",
 summary:"A modern non-harmful offering rite inspired by historical Germanic sacrificial practice.",
 history:"Historical blót could involve communal feasting, offerings, and animal sacrifice. Sacred Year does not attempt to reproduce every historical form and uses food, drink, incense, flowers, or symbolic offerings instead.",
 when:"Use for seasonal observances, thanksgiving, honoring a deity, household milestones, or land-focused practice.",
 items:["A clean cup or bowl","A modest offering such as bread, fruit, grain, milk, juice, mead/beer if appropriate, or flowers","Optional candle"],
 steps:["Clean the space and decide who or what you are honoring.","Light a candle if desired and state your purpose plainly.","Address the deity, ancestors, or land powers respectfully.","Present the offering and explain why it is being given.","Pause for reflection; do not force yourself to interpret ordinary events as supernatural signs.","Close with thanks.","Dispose of the offering responsibly according to local conditions; do not leave food that harms wildlife."],
 short:["Name who you honor.","Give a small offering.","Speak gratitude.","Close clearly."],
 caution:"Historical blót was diverse across time and place. This is a modern household format, not a claim to reproduce one universal Viking-Age ceremony."},

 {id:"sumbel",name:"Sumbel",icon:"🍻",label:"Historically inspired / modern Heathen form",
 summary:"A structured round of toasts, remembrance, and words of commitment inspired by Germanic feast traditions.",
 history:"Feasting, formal drinking, boasting, remembrance, and oath-making are well represented in Germanic literature. The standardized modern Heathen 'three-round sumbel' is a reconstruction rather than a single preserved ancient liturgy.",
 when:"Good for gatherings, Yule, ancestor remembrance, group milestones, or serious commitments.",
 items:["A shared or individual drinking vessel","Any drink suitable for the participants","A clear agreement about the order of speaking"],
 steps:["Set expectations: everyone may pass, and no one should be pressured to drink alcohol.","First round: honor gods or sacred powers.","Second round: honor ancestors, heroes, or people whose example matters.","Third round: speak a boast, gratitude, hope, or carefully considered commitment.","Treat serious oaths as serious; do not encourage reckless promises.","Close with thanks and fellowship."],
 short:["Raise a cup.","Honor gods/powers.","Honor ancestors.","Speak one meaningful commitment or gratitude."],
 caution:"Do not pressure anyone to make an oath. A modern sumbel can use water, juice, tea, or any non-alcoholic drink."},

 {id:"ancestor",name:"Ancestor Remembrance",icon:"🕯️",label:"Historically rooted / modern household rite",
 summary:"A simple rite of memory, gratitude, and family continuity.",
 history:"Germanic societies placed great importance on kinship, burial, inheritance, memorialization, and the dead. Exact domestic ancestor rites are not preserved as one standardized ceremony.",
 when:"Use on meaningful family dates, Winter Nights, Mōdraniht, Álfablót-adjacent household practice, funerary anniversaries, or whenever remembrance feels appropriate.",
 items:["Candle or lamp","Photograph, heirloom, or written name","Optional food or drink connected to the person"],
 steps:["Prepare a quiet space.","Place a photograph, heirloom, or written name before you.","Light a candle.","Say the names of those you are remembering.","Share a memory, lesson, or gratitude.","Offer food/drink symbolically if meaningful.","Sit quietly for a moment.","Close by stating that they are remembered and the rite is complete."],
 short:["Light a candle.","Say a name.","Tell one memory.","Give thanks."],
 caution:"This is remembrance practice. Sacred Year does not claim that candles, photographs, or a fixed script were universal ancient Germanic customs."},

 {id:"land",name:"Land / Wight Offering",icon:"🌿",label:"Historically inspired / modern practice",
 summary:"A respectful offering to the local land, household, or place-based powers.",
 history:"Landvættir and other place-linked beings appear in Old Norse material, while household and local spirit traditions vary widely across Germanic regions and later folklore.",
 when:"Moving into a home, beginning a garden, seasonal change, land stewardship, or simply expressing gratitude for a place.",
 items:["Water, grain, flowers, or another wildlife-safe offering","Optional candle indoors"],
 steps:["Learn about the land you are on before ritualizing it.","Choose a safe place and avoid invasive or harmful offerings.","State that you are offering in gratitude and respect.","Give a modest offering.","Commit to one act of stewardship: litter removal, planting native species, reducing waste, or caring for water/soil.","Close with thanks."],
 short:["Acknowledge the place.","Offer something safe.","Promise one act of care.","Close."],
 caution:"Do not leave salt, alcohol, plastic, processed foods, or anything dangerous to animals or ecosystems."},

 {id:"home",name:"Home Hallowing / Blessing",icon:"🏠",label:"Modern reconstruction with historical inspiration",
 summary:"A household rite for protection, order, and setting intentions for the home.",
 history:"Thor is associated with hallowing/consecration in literary and archaeological contexts, but a single preserved ancient 'house blessing script' does not survive.",
 when:"Moving in, after major conflict, seasonal cleaning, before a family milestone, or whenever the home needs a reset.",
 items:["Candle","Clean water","Optional hammer symbol or other devotional item"],
 steps:["Physically clean the area first.","Open windows if practical and safe.","Light a candle.","Walk through the home and name what you want the household to embody: safety, hospitality, honesty, peace, courage.","If you honor Thor, ask for protection and hallowing in your own words.","Touch a small amount of clean water to doorways if meaningful.","Close at the main entrance with thanks."],
 short:["Clean the space.","Name the values of the home.","Ask for protection.","Close at the doorway."],
 caution:"This is a modern devotional practice, not a surviving historical liturgy."},

 {id:"remembrance",name:"Funeral / Memorial Remembrance",icon:"⚱️",label:"Modern rite informed by Germanic memorial traditions",
 summary:"A non-clergy memorial format centered on memory, deeds, kinship, and continuing remembrance.",
 history:"Burial customs varied enormously across Germanic societies and periods. Archaeology and literature attest grave goods, cremation and inhumation, mounds, memorial stones, feasting, and strong concern with reputation and memory.",
 when:"Memorial service, anniversary of death, scattering ashes where lawful, or private grief ritual.",
 items:["Photographs or heirlooms","Candle","Optional written memories","Food for a shared meal"],
 steps:["Welcome those present and name the person who died.","Tell their story in concrete terms rather than idealizing everything.","Invite memories from others.","Name what they taught, built, protected, loved, or changed.","Light a candle or place a symbolic item.","If desired, give a toast or share a meal.","Close with a statement that their deeds and memory continue through those who remember them."],
 short:["Say their name.","Tell one true story.","Name what continues because they lived.","Close with remembrance."],
 caution:"Follow all local laws and family wishes regarding remains, ashes, graves, fires, and public gatherings."},

 {id:"birth",name:"Birth / Naming Welcome",icon:"👶",label:"Modern family rite",
 summary:"A welcoming rite for a child centered on name, kinship, protection, and responsibility.",
 history:"Germanic naming customs, kinship, fostering, and household rites are historically important, but Sacred Year does not claim one universal ancient infant-naming ceremony survives intact.",
 when:"Birth, naming day, adoption, family welcoming, or first gathering of kin.",
 items:["Water","Family heirloom or symbolic gift","Written family names"],
 steps:["Gather close family or chosen community.","State the child’s name clearly.","Name the people responsible for protecting and teaching the child.","Touch clean water gently to the child’s hand or forehead if desired.","Offer a symbolic family gift or heirloom.","Speak hopes focused on character rather than destiny.","Close by welcoming the child into the household and community."],
 short:["Speak the name.","Name the family/community.","Promise care.","Offer a symbolic gift."],
 caution:"This rite is modern. Keep infant safety and comfort above ceremonial symbolism."},

 {id:"marriage",name:"Marriage / Handfasting",icon:"💍",label:"Modern ceremony with historical inspiration",
 summary:"A relationship rite centered on consent, vows, gift exchange, household, and kinship.",
 history:"Marriage in historical Germanic societies involved family, property, gift exchange, law, and feast. Modern handfasting ceremonies are largely reconstructed or modern Pagan practice.",
 when:"Wedding, vow renewal, or private commitment ceremony.",
 items:["Rings or gifts","Optional cord","Cup for a shared toast","Written vows"],
 steps:["State that both people enter freely and knowingly.","Name the household or life they intend to build.","Exchange vows in plain language.","Exchange rings, gifts, or another symbol.","If using a cord, bind hands loosely and briefly as symbolism only.","Share a toast.","Invite family/community to witness and support the relationship.","Close with a shared meal or celebration."],
 short:["Confirm consent.","Speak vows.","Exchange a symbol.","Share a toast."],
 caution:"A ritual is not a substitute for legal marriage requirements where legal status matters."},

 {id:"quick",name:"Five-Minute Daily Rite",icon:"⏱️",label:"Modern beginner practice",
 summary:"A short daily format for people who want consistency without elaborate ritual.",
 history:"This is intentionally modern and is designed for accessibility rather than historical reconstruction.",
 when:"Any day.",
 items:["Optional candle or cup of water"],
 steps:["Stand or sit quietly for a few breaths.","Name one thing you are grateful for.","Address a deity, ancestors, or simply your own values if desired.","Give a tiny offering or make one concrete promise of action.","Close with a clear phrase such as 'With thanks, this rite is ended.'"],
 short:["Pause.","Give thanks.","State one intention.","Close."],
 caution:"There is no requirement to perform daily ritual in order to practice Heathenry."}
];

function syRitualCard(r){
 return `<button class="section-card ritual-card-v131" onclick="syOpenRitual('${r.id}')"><div style="font-size:30px">${r.icon}</div><div class="ritual-name">${r.name}</div><div class="ritual-summary">${r.summary}</div><div class="kicker ritual-label">${r.label}</div></button>`;
}
function syOpenRitualHall(){
 openDrawer(`<div class="kicker">Ritual Hall</div><h3>Practice with context</h3>
 <p class="note">Sacred Year favors safe, lawful, non-harmful household practice and labels reconstruction honestly.</p>
 <div class="section-nav">${SY_RITUALS.map(syRitualCard).join("")}</div>`);
}
function syOpenRitual(id){
 const r=SY_RITUALS.find(x=>x.id===id);if(!r)return;
 openDrawer(`<div class="kicker">${r.label}</div><h3>${r.icon} ${r.name}</h3>
 <p>${r.summary}</p>
 <div class="item"><h4>Historical context</h4><p>${r.history}</p></div>
 <div class="item" style="margin-top:10px"><h4>When to use it</h4><p>${r.when}</p></div>
 <div class="item" style="margin-top:10px"><h4>What you need</h4><ul>${r.items.map(x=>`<li>${x}</li>`).join("")}</ul></div>
 <div class="item" style="margin-top:10px"><h4>Full rite</h4><ol>${r.steps.map(x=>`<li>${x}</li>`).join("")}</ol></div>
 <div class="item" style="margin-top:10px"><h4>Quick version</h4><ol>${r.short.map(x=>`<li>${x}</li>`).join("")}</ol></div>
 <div class="holiday" style="margin-top:10px"><div class="kicker">Practice note</div><p>${r.caution}</p></div>
 <div class="row"><button class="btn secondary" onclick="syOpenRitualHall()">Back</button></div>`);
}
function sySaveRitual(id){
 const r=SY_RITUALS.find(x=>x.id===id);if(!r)return;
 const arr=JSON.parse(syLocalStorage.getItem("sy_saved_rituals")||"[]");
 if(!arr.includes(id))arr.push(id);
 syLocalStorage.setItem("sy_saved_rituals",JSON.stringify(arr));
 alert(`${r.name} saved.`);
}
window.syOpenRitualHall=syOpenRitualHall;
window.syOpenRitual=syOpenRitual;
window.sySaveRitual=sySaveRitual;
