
window.sy19UnlockEventLocation=async function(){
 const syAccountScope=window.sy25Scope();

 const s=await window.sy25Await((window.sy25Assert(syAccountScope), (sy19Session())),syAccountScope);
 if(!s?.user){closeDrawer();openAccount();return}
 if(!window.sy313AttendeeAgreement){alert("Age confirmation is unavailable. Please refresh and try again.");return}
 sy313AttendeeAgreement(async function(){
   try{
     if(window.sy314RecordConsent)await sy314RecordConsent("event_location_access","2026-08-17");
     await sy19LoadEvents();
   }catch(e){alert(e.message||"Could not unlock event locations.")}
 });
};
