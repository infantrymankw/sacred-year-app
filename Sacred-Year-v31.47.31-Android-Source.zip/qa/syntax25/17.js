
const SY23_LESSONS={
 "what-is":{
  title:"What is Norse Paganism?",
  body:`<p>Norse Paganism is a modern umbrella term for religious paths inspired by the pre-Christian traditions of Norse and other Germanic-speaking peoples. You may also encounter terms such as Heathenry or Ásatrú. Modern communities do not all practice in exactly the same way.</p>
  <div class="item"><h4>What survives?</h4><p>Our evidence comes from archaeology, inscriptions, place-names, law codes, later sagas, skaldic poetry, the Poetic Edda, Snorri Sturluson's Prose Edda, and outside observers. Much was recorded after Christianization, so evidence has to be read critically.</p></div>
  <div class="holiday" style="margin-top:10px"><div class="kicker">Sacred Year approach</div><p>We separate historical evidence from modern reconstruction whenever possible. “We know,” “the sources suggest,” and “a modern practitioner might” are not the same claim.</p></div>`
 },
 "gods":{
  title:"Gods, Goddesses & Other Beings",
  body:`<p>The surviving tradition includes the Æsir and Vanir, but Norse cosmology is much larger than a simple list of gods. Jötnar, álfar, dvergar, landvættir, ancestors, and other beings also appear.</p>
  <p>The gods are not neatly divided into “good” and “evil.” Kinship, hospitality, conflict, oath, wisdom, fertility, protection, death, poetry, and fate intertwine throughout the myths.</p>
  <div class="sy23-source"><b>Study next:</b> Open Gods & Goddesses and begin with Odin, Thor, Frigg, Freyja, Freyr, Tyr, Njörðr, Loki, and the figures that interest you rather than trying to memorize everyone.</div>`
 },
 "sources":{
  title:"Meet the Sources",
  body:`<p><b>Poetic Edda:</b> a modern name for a collection of Old Norse mythological and heroic poems preserved principally in medieval manuscripts.</p>
  <p><b>Prose Edda:</b> Snorri Sturluson's thirteenth-century work on poetics and mythology. Extremely valuable, but not a neutral pagan “Bible.”</p>
  <p><b>Hávamál:</b> an Eddic poem containing several distinct sections of wisdom, social advice, mythic material, and Odin's rune-related passages.</p>
  <p><b>Sagas and archaeology:</b> useful in different ways. A literary story and a physical grave find are different kinds of evidence.</p>
  <div class="holiday"><div class="kicker">Reading habit</div><p>Ask: Who recorded this? When? What kind of source is it? What does it actually say—and what are modern people adding?</p></div>`
 },
 "practice":{
  title:"Practice Without Pretending",
  body:`<p>There was no single surviving instruction manual for “how to be Norse pagan.” Modern practice is reconstructed from incomplete evidence and living community choices.</p>
  <p>A simple practice can begin with learning, gratitude, keeping promises, hospitality, remembrance of ancestors, respectful offerings where appropriate, and observing the turning year.</p>
  <div class="item"><h4>Blót</h4><p>Historically, blót refers to sacrificial/ritual activity. Modern Heathens use the word for several reconstructed forms of offering and communal rite. Sacred Year labels its ritual suggestions as modern practice where that is what they are.</p></div>`
 },
 "calendar":{
  title:"The Sacred Year",
  body:`<p>Historical Germanic calendars were lunisolar and varied by time and place. Modern fixed-date pagan calendars are useful, but they should not be mistaken for one universal Viking-age calendar.</p>
  <p>Sacred Year lets you follow major seasonal observances while showing where dates or practices are reconstructed, regional, or modern.</p>
  <div class="sy23-source"><b>Study next:</b> Explore Yule, Winter Nights, Álfablót, Dísablót, Sigrblót, Midsummer, and the Wild Hunt material in their individual sections.</div>`
 },
 "runes":{
  title:"Runes: Start Historically",
  body:`<p>Runes are alphabets first. The Elder Futhark, Younger Futhark, and Anglo-Saxon Futhorc belong to different periods and language communities.</p>
  <p>Runes also appear in magical and ritual contexts, but the neat one-word divination meanings common on modern websites are largely modern systems—not a surviving ancient rune dictionary.</p>
  <div class="holiday"><div class="kicker">Good first goal</div><p>Learn the rune's name, sound, historical rune-poem evidence where available, and inscriptional context before adding a modern spiritual interpretation.</p></div>`
 },
 "community":{
  title:"Community, Frith & Safety",
  body:`<p>Community can be valuable without turning religion into social media. Sacred Year's Community Hall is for learning, discussion, and arranging public gatherings.</p>
  <p>Meet new people in public places. Do not post private home addresses. Organizer labels tell you whether an event comes from a new community organizer, a trusted organizer, or a verified organization.</p>
  <div class="holiday"><div class="kicker">Worth remembering</div><p>No app badge replaces judgment. You decide whom you trust, what groups you join, and what practices fit your own path.</p></div>`
 }
};

function sy23StartHere(){
 const steps=[
  ["what-is","What is Norse Paganism?","Understand the modern religion and the historical evidence behind it."],
  ["gods","Gods & Other Beings","Meet the divine and mythic landscape without reducing it to a character list."],
  ["sources","Meet the Sources","Learn what the Eddas, Hávamál, sagas, and archaeology can—and cannot—tell us."],
  ["practice","Practice Without Pretending","Learn the difference between attested practice and modern reconstruction."],
  ["calendar","The Sacred Year","Understand holidays, seasonal observance, and why dates can differ."],
  ["runes","Runes: Start Historically","Begin with alphabets and source evidence before modern divination meanings."],
  ["community","Community & Safety","Connect with others while keeping Sacred Year focused and safe."]
 ];
 openDrawer(`<div class="kicker">Start Here</div><h3>New to Norse Paganism?</h3>
 <p class="note">You do not need to learn everything at once. This short path gives you enough foundation to explore Sacred Year without getting buried in terminology.</p>
 <div class="sy23-path">${steps.map((x,i)=>`<button class="sy23-step" onclick="sy23Lesson('${x[0]}')"><h4><span class="sy23-num">${i+1}</span>${x[1]}</h4><p>${x[2]}</p></button>`).join("")}</div>
 <div class="holiday" style="margin-top:12px"><div class="kicker">One rule for the whole app</div><p><b>Simple enough to use every day. Deep enough to keep learning from.</b></p></div>`);
}
function sy23Lesson(id){
 const l=SY23_LESSONS[id];if(!l)return;
 openDrawer(`<div class="kicker">Start Here • Lesson</div><h3>${l.title}</h3>${l.body}
 <button class="btn secondary" onclick="sy23StartHere()">Back to Start Here</button>`);
}
window.sy23StartHere=sy23StartHere;window.sy23Lesson=sy23Lesson;

/* Add Start Here prominently to Today without replacing existing tools */
setTimeout(()=>{
 const nav=document.querySelector("#today .section-nav");
 if(nav&&!document.getElementById("sy23StartHere")){
  const b=document.createElement("button");b.id="sy23StartHere";b.className="section-card";b.onclick=sy23StartHere;
  b.innerHTML='<div style="font-size:30px">ᚱ</div><h4>Start Here</h4><p>New to Norse Paganism? Learn the foundations in seven short lessons.</p>';
  nav.insertBefore(b,nav.firstChild);
 }
},500);
