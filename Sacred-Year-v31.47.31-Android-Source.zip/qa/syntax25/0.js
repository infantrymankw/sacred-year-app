
(function(){
 const raw=window.localStorage;
let observed=null,epoch=0;
window.sy25ObserveAccount=()=>{const current=window.syStorageUID?.()||null;if(current!==observed){observed=current;epoch++;}return epoch;};
window.sy25Scope=()=>({epoch:window.sy25ObserveAccount(),uid:window.syStorageUID?.()||null});
window.sy25Assert=s=>{if(s.epoch!==window.sy25ObserveAccount()||s.uid!==(window.syStorageUID?.()||null)){const e=new Error('Account changed. Please reopen this screen.');e.code='sy/account-changed';throw e;}};
window.sy25Await=async(p,s)=>{const result=await p;window.sy25Assert(s);return result;};
window.addEventListener('unhandledrejection',e=>{if(e.reason?.code==='sy/account-changed')e.preventDefault();});
 const deviceKeys=new Set(['sy_v30_quality_pass']);
 const uid=()=>window.syStorageUID?.()||null;
 const key=(k,u)=>deviceKeys.has(k)||k.startsWith('sy_verified_access_v1_')||k.startsWith('sy_v16_initial_sync_done_')?k:'sy25:user:'+encodeURIComponent(u||'signed-out')+':'+k;
 function bound(u){const scope=window.sy25Scope();return {
  getItem(k){return raw.getItem(key(String(k),u));},
  setItem(k,v){if(uid()!==u||scope.epoch!==window.sy25ObserveAccount())return;raw.setItem(key(String(k),u),v);},
  removeItem(k){if(uid()!==u||scope.epoch!==window.sy25ObserveAccount())return;raw.removeItem(key(String(k),u));},
  clear(){if(uid()!==u||scope.epoch!==window.sy25ObserveAccount())return;const prefix='sy25:user:'+encodeURIComponent(u||'signed-out')+':';for(const k of Object.keys(raw))if(k.startsWith(prefix))raw.removeItem(k);}
 };}
 window.syLocalStorage={getItem:k=>bound(uid()).getItem(k),setItem:(k,v)=>bound(uid()).setItem(k,v),removeItem:k=>bound(uid()).removeItem(k),clear:()=>bound(uid()).clear(),forUser:u=>bound(u||null)};
 // Do not claim legacy unscoped data for whichever account happens to sign in first.
 window.syDisplayDate=function(value){
  if(value==null||value==='')return 'Date unavailable';
  const d=value?.toDate?value.toDate():new Date(typeof value==='object'&&('seconds'in value||'_seconds'in value)?(value.seconds??value._seconds)*1000:value);
  return Number.isFinite(d.getTime())?d.toLocaleString():'Date unavailable';
 };
})();

