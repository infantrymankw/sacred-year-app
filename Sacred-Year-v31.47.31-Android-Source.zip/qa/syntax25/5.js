
const SY_REALMS={
 asgard:{
  name:"Ásgarðr / Asgard",icon:"⚡",short:"Stronghold associated with the Æsir.",
  beings:"The Æsir; halls such as Valhöll, Fensalir, Breiðablik, and others are placed within the divine landscape in different sources.",
  description:"Ásgarðr is the fortified dwelling-region of the Æsir. Snorri describes it as a central divine stronghold, while Eddic poems name individual halls and sacred places rather than presenting a modern fantasy-style map.",
  sources:"Prose Edda, Gylfaginning; Grímnismál and other Eddic poems preserve many divine halls.",
  note:"It is better understood as a mythic divine enclosure/region than as a planet floating in space."
 },
 midgard:{
  name:"Miðgarðr / Midgard",icon:"🏠",short:"The enclosed human world.",
  beings:"Humanity; surrounded in Snorri’s cosmology by the sea in which Jörmungandr lies.",
  description:"Miðgarðr literally carries the sense of a middle enclosure. It is the human-inhabited world, protected and ordered against the dangerous outer regions of mythic geography.",
  sources:"Völuspá; Vafþrúðnismál; Prose Edda, Gylfaginning.",
  note:"Midgard is not simply 'Earth' in a modern astronomical sense; it is the human zone within Germanic mythic cosmology."
 },
 jotunheim:{
  name:"Jötunheimr / Jötunheim",icon:"🏔️",short:"Region associated with the jötnar.",
  beings:"Jötnar, including many figures who interact, marry, feud, or exchange knowledge with the gods.",
  description:"Jötunheimr is the region of the jötnar, often placed eastward or beyond the gods’ protected enclosure. The jötnar are not a simple race of 'evil giants'; they include dangerous enemies, wise beings, ancestors, spouses, and kin of gods.",
  sources:"Þrymskviða, Skírnismál, Vafþrúðnismál, Prose Edda.",
  note:"The English word 'giant' can flatten the much broader Old Norse category jötunn."
 },
 vanaheim:{
  name:"Vanaheimr / Vanaheim",icon:"🌾",short:"Home associated with the Vanir.",
  beings:"The Vanir, including the divine family associated with Njörðr, Freyr, and Freyja in the surviving tradition.",
  description:"Vanaheimr is named as the home/region of the Vanir. It is less fully described than Ásgarðr or Jötunheimr, but the Vanir-Æsir exchange after their conflict makes it important to the divine geography.",
  sources:"Vafþrúðnismál; Prose Edda; Ynglinga saga for later euhemerized tradition.",
  note:"The sources do not provide a detailed physical description of Vanaheimr."
 },
 alfheim:{
  name:"Álfheimr / Alfheim",icon:"✨",short:"Realm associated with the álfar and Freyr.",
  beings:"Álfar; Grímnismál says the gods gave Álfheimr to Freyr as a tooth-gift.",
  description:"Álfheimr is one of the clearest named mythic regions outside the better-known divine and human enclosures. Its exact nature is still elusive because the sources say surprisingly little about the álfar as a single organized people.",
  sources:"Grímnismál 5; later prose references.",
  note:"Modern fantasy depictions of 'light elves' often go far beyond what the medieval sources actually preserve."
 },
 svartalfheim:{
  name:"Svartálfaheimr / Niðavellir",icon:"⛏️",short:"A debated dwarven/underground realm grouping.",
  beings:"Dvergar (dwarfs) are strongly associated with underground/stone environments and extraordinary craftsmanship.",
  description:"Snorri uses Svartálfaheimr in connection with beings he calls svartálfar, while Völuspá names Niðavellir in a dwarven context. Modern nine-world lists often merge these into one 'dwarf realm,' but whether the medieval sources intended them as exactly the same place is debated.",
  sources:"Völuspá; Prose Edda, Gylfaginning and Skáldskaparmál.",
  note:"Sacred Year groups the names for study convenience while explicitly marking the identification as uncertain."
 },
 muspelheim:{
  name:"Múspellsheimr / Muspelheim",icon:"🔥",short:"Fiery region associated with Muspell.",
  beings:"The sons/forces of Muspell; Surtr is the most famous figure associated with the fiery destructive power at Ragnarök.",
  description:"Múspellsheimr is the hot, bright, fiery region in Snorri’s creation account. Its heat meets the cold of Niflheimr in the Ginnungagap creation framework.",
  sources:"Prose Edda, Gylfaginning; Völuspá contains Muspell-associated Ragnarök material.",
  note:"The fully systematized 'fire world' presentation owes much to Snorri’s prose cosmography."
 },
 niflheim:{
  name:"Niflheimr / Niflheim",icon:"🌫️",short:"Mist-cold region in Snorri’s cosmology.",
  beings:"Associated with primordial cold, mist, rivers, and the spring Hvergelmir in Snorri’s account.",
  description:"Niflheimr is a cold and misty primordial region. Snorri places Hvergelmir there and uses its icy rivers in his account of creation. It should not automatically be collapsed into Hel.",
  sources:"Prose Edda, Gylfaginning.",
  note:"Niflheimr and Hel overlap in some later popular diagrams, but the surviving texts do not make them simply identical."
 },
 hel:{
  name:"Hel",icon:"🕯️",short:"Realm of many of the dead, ruled by Hel.",
  beings:"The goddess/figure Hel and many of the dead. Baldr comes to Hel after his death in the Eddic/Prose tradition.",
  description:"Hel is both the name of a powerful being in Snorri’s account and the realm of the dead. The sources do not portray it simply as a Christian-style place of punishment.",
  sources:"Baldrs draumar; Völuspá; Prose Edda, Gylfaginning.",
  note:"Sacred Year uses 'Hel,' not the popular modern term 'Helheim,' because Hel is the name actually used in the medieval Old Norse sources."
 }
};

function syOpenRealm(id){
 const r=SY_REALMS[id];if(!r)return;
 openDrawer(`<div class="kicker">Cosmology Study</div><h3>${r.icon} ${r.name}</h3>
 <div class="realm-detail">
  <div class="item"><h4>What it is</h4><p>${r.description}</p></div>
  <div class="item" style="margin-top:10px"><h4>Associated beings</h4><p>${r.beings}</p></div>
  <div class="item" style="margin-top:10px"><h4>Source trail</h4><p>${r.sources}</p></div>
  <div class="holiday" style="margin-top:10px"><div class="kicker">Evidence note</div><p>${r.note}</p></div>
 </div>
 <button class="btn secondary" onclick="syOpenHallSection('worlds')">Back to Nine Worlds</button>`);
}
window.syOpenRealm=syOpenRealm;
