
const SY_RUNES=[
 {s:"ᚠ",n:"Fehu",pg:"*Fehu",hist:"Cattle; movable wealth, property, resources.",modern:"Resources, prosperity, exchange, stewardship.",prompt:"What resources are in my care, and how am I using them?",note:"Rune-poem traditions strongly associate this rune with wealth/cattle."},
 {s:"ᚢ",n:"Uruz",pg:"*Ūruz",hist:"Aurochs / wild ox; strength and untamed vitality.",modern:"Strength, vitality, endurance, raw potential.",prompt:"Where do I need strength without losing control?",note:"The exact reconstructed referent varies across scholarship, but aurochs is the common interpretation."},
 {s:"ᚦ",n:"Thurisaz",pg:"*Þurisaz",hist:"Thurs / giant; dangerous or powerful being.",modern:"Challenge, defense, force, boundaries.",prompt:"What deserves caution, resistance, or protection?",note:"Later rune poems connect the rune with thorn/giant imagery depending on tradition."},
 {s:"ᚨ",n:"Ansuz",pg:"*Ansuz",hist:"A god / divine being; later traditions also connect the rune with mouth/speech.",modern:"Speech, wisdom, inspiration, message.",prompt:"What truth needs to be spoken or heard?",note:"Germanic linguistic evidence supports a divine-being association."},
 {s:"ᚱ",n:"Raidho",pg:"*Raidō",hist:"Ride, journey, wagon movement.",modern:"Journey, rhythm, order, right movement.",prompt:"What path am I actually traveling?",note:"Rune-poem evidence consistently preserves travel/ride imagery."},
 {s:"ᚲ",n:"Kenaz",pg:"*Kaunan",hist:"Torch / ulcer depending on later rune-poem traditions; etymology is debated.",modern:"Illumination, craft, knowledge, controlled fire.",prompt:"What needs light, skill, or understanding?",note:"This rune is a good example of why Sacred Year separates historical uncertainty from modern keyword systems."},
 {s:"ᚷ",n:"Gebo",pg:"*Gebō",hist:"Gift.",modern:"Gift, exchange, reciprocity, relationship.",prompt:"What am I giving, receiving, or obligated to return?",note:"Gift exchange was socially important across Germanic cultures."},
 {s:"ᚹ",n:"Wunjo",pg:"*Wunjō",hist:"Joy / pleasure.",modern:"Joy, harmony, fellowship, belonging.",prompt:"Where do I experience genuine fellowship?",note:"Old English rune-poem evidence preserves a joy/bliss meaning."},
 {s:"ᚺ",n:"Hagalaz",pg:"*Hag(a)laz",hist:"Hail.",modern:"Disruption, sudden change, destructive natural force.",prompt:"What disruption is forcing me to adapt?",note:"Hail imagery is consistently preserved in later rune poems."},
 {s:"ᚾ",n:"Nauthiz",pg:"*Naudiz",hist:"Need, distress, constraint.",modern:"Need, hardship, necessity, resilience.",prompt:"What is necessary even if it is uncomfortable?",note:"Later rune poems strongly preserve themes of need and constraint."},
 {s:"ᛁ",n:"Isa",pg:"*Īsaz",hist:"Ice.",modern:"Stillness, delay, concentration, preservation.",prompt:"Where is stillness useful, and where has it become stagnation?",note:"Ice is one of the most stable rune-name meanings across traditions."},
 {s:"ᛃ",n:"Jera",pg:"*Jēran",hist:"Year; harvest / seasonal cycle.",modern:"Harvest, cycles, earned results, timing.",prompt:"What am I harvesting from earlier choices?",note:"The word is related to year and seasonal reward."},
 {s:"ᛇ",n:"Eihwaz",pg:"*Īhwaz",hist:"Yew tree.",modern:"Endurance, transformation, resilience, continuity.",prompt:"What must I endure long enough to understand?",note:"Yew is strongly supported by rune-poem evidence."},
 {s:"ᛈ",n:"Perthro",pg:"*Perþō",hist:"Meaning uncertain; possible lot-cup/game piece association.",modern:"Mystery, chance, hidden factors, uncertainty.",prompt:"What am I trying to know before it can be known?",note:"Historical meaning is genuinely uncertain; modern 'fate/mystery' meanings are interpretive."},
 {s:"ᛉ",n:"Algiz",pg:"*Algiz",hist:"Meaning debated; elk/sedge/protection associations arise from differing evidence.",modern:"Protection, boundary, sacred awareness.",prompt:"What deserves protection, and what boundary is needed?",note:"This rune has one of the more debated historical name histories."},
 {s:"ᛋ",n:"Sowilo",pg:"*Sōwilō",hist:"Sun.",modern:"Clarity, vitality, success, wholeness.",prompt:"What becomes clear when I stop hiding from it?",note:"Sun meaning is strongly supported across later rune traditions."},
 {s:"ᛏ",n:"Tiwaz",pg:"*Tīwaz",hist:"The god Tīwaz / Týr.",modern:"Justice, honor, courage, sacrifice, duty.",prompt:"What is the honorable course even if it costs me something?",note:"The rune name is directly connected linguistically with Tīwaz/Týr."},
 {s:"ᛒ",n:"Berkano",pg:"*Berkanan",hist:"Birch.",modern:"Growth, renewal, nurturing, beginnings.",prompt:"What needs steady care rather than force?",note:"Birch meaning is well preserved in later rune poems."},
 {s:"ᛖ",n:"Ehwaz",pg:"*Ehwaz",hist:"Horse.",modern:"Trust, movement, partnership, cooperation.",prompt:"Who or what am I relying on to move forward?",note:"Horse meaning is strongly supported by linguistic evidence."},
 {s:"ᛗ",n:"Mannaz",pg:"*Mannaz",hist:"Human / person.",modern:"Self, humanity, society, relationship.",prompt:"How am I functioning within my community?",note:"Human/person meaning is straightforward linguistically."},
 {s:"ᛚ",n:"Laguz",pg:"*Laguz",hist:"Water / lake.",modern:"Flow, emotion, intuition, adaptability.",prompt:"What should move rather than be forced?",note:"Water/lake associations are preserved in later rune-poem evidence."},
 {s:"ᛜ",n:"Ingwaz",pg:"*Ingwaz",hist:"The god/hero Ing; associated linguistically with Ing/Freyr traditions.",modern:"Potential, fertility, gestation, completion.",prompt:"What is developing quietly before it becomes visible?",note:"The rune name is connected with Ing, a figure tied to Germanic fertility traditions."},
 {s:"ᛞ",n:"Dagaz",pg:"*Dagaz",hist:"Day.",modern:"Dawn, breakthrough, transition, awakening.",prompt:"What new understanding is becoming visible?",note:"Day/dawn meaning is linguistically secure."},
 {s:"ᛟ",n:"Othala",pg:"*Ōþala",hist:"Inherited property, ancestral estate, homeland.",modern:"Heritage, home, inheritance, ancestry.",prompt:"What have I inherited, and what will I pass on?",note:"The historical meaning centers on inherited estate/property, not simply abstract 'ancestry'."}
];

function syRuneCard(r){
 return `<button class="rune" onclick="syOpenRune('${r.n}')"><b>${r.s}</b><span>${r.n}</span></button>`;
}
function syRenderRunes(){
 const g=document.getElementById("runeGridFull");
 if(g)g.innerHTML=SY_RUNES.map(syRuneCard).join("");
}
function syOpenRune(name){
 const r=SY_RUNES.find(x=>x.n===name);if(!r)return;
 openDrawer(`<div class="kicker">Rune Circle</div>
 <h3 style="font-size:42px;margin:6px 0">${r.s} ${r.n}</h3>
 <p class="note">${r.pg}</p>
 <div class="item"><h4>Historical core</h4><p>${r.hist}</p></div>
 <div class="item" style="margin-top:10px"><h4>Modern interpretation</h4><p>${r.modern}</p></div>
 <div class="item" style="margin-top:10px"><h4>Reflection</h4><p>${r.prompt}</p></div>
 <p class="mini-source">${r.note}</p>
 <div class="row"><button class="btn" onclick="sySaveRuneV11('${r.n}')">Save Rune</button><button class="btn secondary" onclick="syJournalRune('${r.n}')">Journal</button></div>`);
}
function syDrawRune(){
 const r=SY_RUNES[Math.floor(Math.random()*SY_RUNES.length)];
 syOpenRune(r.n);
}
async function sySaveRuneV11(name){
 const syAccountScope=window.sy25Scope();

 const r=SY_RUNES.find(x=>x.n===name);if(!r)return;
 syLocalStorage.setItem("sy_saved_rune",JSON.stringify([r.s,r.n,r.modern]));
 try{
   if(window.sySupabase){
     const {data:{session}}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.auth.getSession())),syAccountScope);
     if(session?.user)await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("saved_runes").upsert({user_id:session.user.id,rune:r.n,rune_symbol:r.s,keywords:r.modern,saved_at:new Date().toISOString()}))),syAccountScope);
   }
 }catch(e){}
 syRefreshSavedCards();
 alert(`${r.n} saved.`);
}
function syJournalRune(name){
 const r=SY_RUNES.find(x=>x.n===name);if(!r)return;
 openDrawer(`<div class="kicker">Rune Journal</div><h3>${r.s} ${r.n}</h3>
 <p class="note">Personal reflection / modern rune practice.</p>
 <label>Question or context</label><input id="syRuneQ" placeholder="What were you asking or reflecting on?"/>
 <label>Your notes</label><textarea id="syRuneNote" rows="7" placeholder="Record your interpretation, thoughts, or what happened afterward…"></textarea>
 <button class="btn" onclick="sySaveRuneJournal('${r.n}')">Save entry</button>`);
}
function sySaveRuneJournal(name){
 const r=SY_RUNES.find(x=>x.n===name),q=document.getElementById("syRuneQ").value.trim(),note=document.getElementById("syRuneNote").value.trim();
 if(!note&&!q)return;
 const a=JSON.parse(syLocalStorage.getItem("sy_rune_journal")||"[]");
 a.unshift({rune:r.n,symbol:r.s,question:q,note,created_at:new Date().toISOString()});
 syLocalStorage.setItem("sy_rune_journal",JSON.stringify(a.slice(0,250)));
 syLocalStorage.setItem("sy_saved_rune",JSON.stringify([r.s,r.n,r.modern]));
 syRefreshSavedCards();
 closeDrawer();alert("Rune journal entry saved.");
}
function syOpenRuneJournal(){
 const a=JSON.parse(syLocalStorage.getItem("sy_rune_journal")||"[]");
 openDrawer(`<div class="kicker">Rune Journal</div><h3>Your Entries</h3>
 <div class="list">${a.map(x=>`<div class="item"><h4>${x.symbol} ${x.rune}</h4>${x.question?`<p><b>Question:</b> ${x.question}</p>`:""}<p>${x.note||""}</p><div class="note">${syDisplayDate(x.created_at)}</div></div>`).join("")||'<p class="note">No rune journal entries yet.</p>'}</div>`);
}
window.syOpenRune=syOpenRune;
window.syDrawRune=syDrawRune;
window.sySaveRuneV11=sySaveRuneV11;
window.syJournalRune=syJournalRune;
window.sySaveRuneJournal=sySaveRuneJournal;
window.syOpenRuneJournal=syOpenRuneJournal;
syRenderRunes();
