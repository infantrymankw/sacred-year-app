
for(const [id,season] of [['ostara',0],['midsummer',1],['autumn',2],['yule',3]]){const e=SY_HOLIDAYS.find(h=>h.season===season);SY26_HOLIDAYS[id]=[e.name,e.label,e.whyDate,e.summary,e.source,e.practice,'Astronomy identifies a turning point; it does not establish one universal ancient festival or ritual.'];}
