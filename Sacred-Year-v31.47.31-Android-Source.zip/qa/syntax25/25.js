
function sy301AddHallPlus(){
 const hall=document.getElementById("hall");
 if(!hall || document.getElementById("sy301HallPlus")) return;

 const grids=hall.querySelectorAll(".section-nav");
 const target=grids[0] || hall;

 const b=document.createElement("button");
 b.id="sy301HallPlus";
 b.className="section-card";
 b.onclick=()=>window.syOpenHallPlus ? syOpenHallPlus() : null;
 b.innerHTML=`
   <div style="font-size:28px">🔥</div>
   <h4>Hall+</h4>
   <p>Support Sacred Year and explore deeper practice tools.</p>
   <div class="kicker">Optional</div>
 `;
 target.appendChild(b);
}
setTimeout(sy301AddHallPlus,900);
window.sy301AddHallPlus=sy301AddHallPlus;
