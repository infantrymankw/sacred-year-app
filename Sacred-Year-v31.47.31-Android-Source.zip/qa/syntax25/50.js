
for(const [id,part] of [['winter','Samhain'],['disablot','Imbolc'],['walpurgis','Bealtaine'],['harvest','Lughnasadh']]){
 const entry=SY_HOLIDAYS.find(x=>x.name.includes(part));if(!entry)continue;
 SY26_HOLIDAYS[id]=[entry.name,entry.label,entry.whyDate,entry.summary,entry.source,entry.practice,'These traditions share a seasonal entry, not a single historical origin or identical date.'];
}
