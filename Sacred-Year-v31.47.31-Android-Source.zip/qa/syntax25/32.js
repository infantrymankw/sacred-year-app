
(function(){
 window.sy315OpenDelete=function(){document.getElementById("sy315DeleteConfirm").value="";document.getElementById("sy315DeleteStatus").textContent="";document.getElementById("sy315Delete").classList.add("open")};
 window.sy315CloseDelete=function(){document.getElementById("sy315Delete").classList.remove("open")};
 window.sy315DeleteAccount=async function(){
   const status=document.getElementById("sy315DeleteStatus");
   if(document.getElementById("sy315DeleteConfirm").value.trim()!=="DELETE"){status.textContent="Type DELETE exactly to confirm.";return}
   if(!window.sySupabase){status.textContent="Account service is unavailable. Please try again.";return}
   status.textContent="Deleting your account…";
   try{
     const {data:{session}}=await window.sySupabase.auth.getSession();
     if(!session){status.textContent="Please sign in before deleting your account.";return}
     const {data,error}=await window.sySupabase.functions.invoke("delete-account",{body:{confirm:"DELETE"}});
     if(error)throw error;
     await window.sySupabase.auth.signOut();
     try{syLocalStorage.clear()}catch(e){}
     alert("Your Sacred Year account has been deleted.");
     location.reload();
   }catch(e){status.textContent="We could not complete deletion. Contact Sacredyear1@gmail.com if the problem continues."}
 };
 window.sy315RecordLegalAcceptance=async function(){
 const syAccountScope=window.sy25Scope();

   const rec={terms_version:"2026-08-17",privacy_version:"2026-08-17",accepted_at:new Date().toISOString()};
   syLocalStorage.setItem("sy_terms_acceptance_v1",JSON.stringify(rec));
   try{
     if(window.sySupabase){
       const {data:{session}}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.auth.getSession())),syAccountScope);
       if(session?.user)await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("legal_consents").upsert({user_id:session.user.id,consent_type:"terms_privacy",version:"2026-08-17",accepted_at:rec.accepted_at},{onConflict:"user_id,consent_type"}))),syAccountScope);
     }
   }catch(e){}
 };
})();
