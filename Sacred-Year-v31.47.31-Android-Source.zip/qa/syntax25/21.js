
const SY27_BOOKS={
 havamal:{title:"Hávamál",sub:"Wisdom, hospitality, Odin, and rune lore",sections:[
  ["How to read Hávamál","Hávamál is not one continuous modern self-help book. Scholars commonly recognize several sections or layers within the poem. Read individual stanzas in context and compare translations when a line matters."],
  ["Guest and host","The opening wisdom material repeatedly deals with entering halls, watching carefully, hospitality, moderation, friendship, reputation, and practical judgment."],
  ["Odin and the runes","Later portions shift toward Odin, charms, sacrifice, and the famous account of hanging on the wind-swept tree. These passages should not be flattened into the same genre as the earlier social advice."]
 ]},
 poetic:{title:"Poetic Edda",sub:"Mythological and heroic poems",sections:[
  ["What it is","The Poetic Edda is a modern name for a collection of Old Norse poems, many preserved in the medieval Codex Regius. The poems differ in date, voice, subject, and genre."],
  ["Mythological poems","Völuspá, Hávamál, Vafþrúðnismál, Grímnismál, Skírnismál, Lokasenna, Þrymskviða and others are major sources for Norse myth. They do not always agree neatly with one another or with Snorri."],
  ["Heroic poems","A large portion of the collection concerns legendary heroes rather than the gods. Sacred Year keeps those poems visible so the Edda is not reduced to a mythology quote book."]
 ]},
 prose:{title:"Prose Edda",sub:"Snorri's handbook of myth and poetry",sections:[
  ["What it is","Written in thirteenth-century Iceland and associated with Snorri Sturluson, the Prose Edda is an indispensable source for mythology and skaldic poetics—but it was composed in a Christian medieval setting."],
  ["Gylfaginning","Gylfaginning presents a broad mythological narrative through a framed dialogue. It is one of the easiest places to encounter Snorri's organized account of the cosmos, gods, and Ragnarök."],
  ["Skáldskaparmál","Skáldskaparmál explains poetic diction, kennings, and mythic references needed by poets. Many myths survive because Snorri needed to explain the language of older poetry."]
 ]}
};
function sy27Library(){
 openDrawer(`<div class="kicker">Library</div><h3>Read • Search • Study</h3>
 <p class="note">The Library is organized as a study reader rather than a wall of text. Search notes, bookmark your place, and keep the source type visible while you read.</p>
 <input class="sy27-search" id="sy27Search" placeholder="Search the Library…" oninput="sy27Search(this.value)">
 <div id="sy27Results"></div>
 ${Object.entries(SY27_BOOKS).map(([id,b])=>`<button class="sy27-book" onclick="sy27OpenBook('${id}')"><div class="kicker">Study edition</div><h4>${b.title}</h4><p>${b.sub}</p></button>`).join("")}
 <div class="holiday" style="margin-top:12px"><div class="kicker">Translations</div><p>Translations are interpretations too. Sacred Year identifies editions rather than silently mixing wording from different translators.</p></div>`);
}
function sy27OpenBook(id){
 const b=SY27_BOOKS[id], saved=syLocalStorage.getItem("sy27-bookmark-"+id);
 openDrawer(`<div class="kicker">Library</div><h3>${b.title}</h3><p class="note">${b.sub}</p>
 ${saved?`<button class="btn secondary" onclick="sy27OpenSection('${id}',${Number(saved)})">Continue bookmarked section</button>`:""}
 ${b.sections.map((s,i)=>`<button class="sy27-book" onclick="sy27OpenSection('${id}',${i})"><span class="sy27-chip">${i+1}</span><h4>${s[0]}</h4><p>${s[1]}</p></button>`).join("")}
 <button class="btn secondary" onclick="sy27Library()">Back to Library</button>`);
}
function sy27OpenSection(id,i){
 const b=SY27_BOOKS[id],s=b.sections[i];if(!s)return;
 openDrawer(`<div class="kicker">${b.title}</div><h3>${s[0]}</h3><div class="sy27-reader"><p>${s[1]}</p></div>
 <div class="row"><button class="btn" onclick="sy27Bookmark('${id}',${i})">Bookmark</button><button class="btn secondary" onclick="sy27OpenBook('${id}')">Contents</button></div>
 <div class="holiday" style="margin-top:10px"><div class="kicker">Study note</div><p>This reader keeps commentary separate from the translated primary text so you can tell what the source says from what Sacred Year is explaining.</p></div>`);
}
function sy27Bookmark(id,i){syLocalStorage.setItem("sy27-bookmark-"+id,String(i));alert("Bookmark saved on this device.")}
function sy27Search(q){
 const box=document.getElementById("sy27Results");if(!box)return;
 q=(q||"").trim().toLowerCase();if(q.length<2){box.innerHTML="";return}
 let hits=[];
 for(const [id,b] of Object.entries(SY27_BOOKS))b.sections.forEach((s,i)=>{if((b.title+" "+s[0]+" "+s[1]).toLowerCase().includes(q))hits.push([id,i,b.title,s[0]])});
 box.innerHTML=hits.length?`<div class="kicker">Results</div>${hits.slice(0,12).map(h=>`<button class="sy27-result" onclick="sy27OpenSection('${h[0]}',${h[1]})"><b class="sy27-mark">${h[2]}</b> — ${h[3]}</button>`).join("")}`:`<p class="note">No study notes match that search yet.</p>`;
}
window.sy27Library=sy27Library;window.sy27OpenBook=sy27OpenBook;window.sy27OpenSection=sy27OpenSection;window.sy27Bookmark=sy27Bookmark;window.sy27Search=sy27Search;
setTimeout(()=>{for(const b of document.querySelectorAll("button,.section-card")){const t=(b.textContent||"").trim();if(/^library$/i.test(t)||/sacred texts|hávamál.*edda/i.test(t)){b.onclick=sy27Library}}},800);
