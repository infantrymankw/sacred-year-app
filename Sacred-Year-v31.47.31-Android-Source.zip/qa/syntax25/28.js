
(function(){
  const KEY="sy_notification_prefs";

  function readLocal(){
    try{
      return Object.assign({
        notify_holidays:true,
        notify_moon:true,
        notify_words:true,
        notify_rituals:false
      }, JSON.parse(syLocalStorage.getItem(KEY)||"{}"));
    }catch(e){
      return {notify_holidays:true,notify_moon:true,notify_words:true,notify_rituals:false};
    }
  }

  function renderPrefs(p){
    if(typeof openDrawer!=="function") return;
    openDrawer(`<div class="kicker">Notification Settings</div><h3>Choose what Sacred Year sends you</h3>
      <p class="note">These settings sync to your account. Background alerts can arrive even when Sacred Year is closed after browser notification permission is granted.</p>
      <label><input id="sy311NH" type="checkbox" ${p.notify_holidays?"checked":""} style="width:auto;margin-right:7px"> Sacred-day reminders</label>
      <label><input id="sy311NM" type="checkbox" ${p.notify_moon?"checked":""} style="width:auto;margin-right:7px"> New Moon & Full Moon reminders</label>
      <label><input id="sy311NW" type="checkbox" ${p.notify_words?"checked":""} style="width:auto;margin-right:7px"> Words from the Hall</label>
      <div class="holiday" style="margin-top:12px"><div class="kicker">Hall+ scheduled reminders</div><p>Ritual, study, event, moon, holiday, and custom reminders that you create in <b>Hall+ → Advanced Reminders</b> are sent according to the schedule you choose.</p></div>
      <div class="row" style="margin-top:14px">
        <button class="btn" onclick="sy311SaveNotificationSettings()">Save settings</button>
        <button class="btn secondary" onclick="syEnableNotifications()">Allow phone/browser alerts</button>
      </div>
      <p class="note" id="sy311NotifStatus" style="margin-top:10px"></p>`);
  }

  async function loadCloud(){
 const syAccountScope=window.sy25Scope();

    const syLocalStorage=window.syLocalStorage.forUser(window.syStorageUID?.());
    try{
      if(!window.sySupabase) return;
      const {data:{session}}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.auth.getSession())),syAccountScope);
      if(!session?.user) return;
      const {data}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("user_preferences")
        .select("notify_holidays,notify_moon,notify_words,notify_rituals,timezone")
        .eq("user_id",session.user.id).maybeSingle())),syAccountScope);
      if(!data) return;
      const local=Object.assign(readLocal(),data);
      syLocalStorage.setItem(KEY,JSON.stringify(local));
      ["NH","NM","NW"].forEach(k=>{
        const el=document.getElementById("sy311"+k);
        if(!el)return;
        const map={NH:"notify_holidays",NM:"notify_moon",NW:"notify_words"};
        el.checked=!!local[map[k]];
      });
    }catch(e){}
  }

  window.syOpenNotificationSettings=function(){
    renderPrefs(readLocal()); // opens instantly, no network wait
    loadCloud();
  };

  window.sy311SaveNotificationSettings=async function(){
 const syAccountScope=window.sy25Scope();

    const prefs={
      notify_holidays:!!document.getElementById("sy311NH")?.checked,
      notify_moon:!!document.getElementById("sy311NM")?.checked,
      notify_words:!!document.getElementById("sy311NW")?.checked,
      notify_rituals:false,
      timezone:(Intl.DateTimeFormat().resolvedOptions().timeZone||"UTC")
    };
    syLocalStorage.setItem(KEY,JSON.stringify(prefs));
    const status=document.getElementById("sy311NotifStatus");
    if(status)status.textContent="Saved on this device.";

    try{
      if(window.sySupabase){
        const {data:{session}}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.auth.getSession())),syAccountScope);
        if(session?.user){
          const {error}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("user_preferences").upsert({
            user_id:session.user.id,
            ...prefs,
            updated_at:new Date().toISOString()
          },{onConflict:"user_id"}))),syAccountScope);
          if(error) throw error;
          if(status)status.textContent="Saved and synced to your Sacred Year account.";
        }
      }
    }catch(e){
      if(status)status.textContent="Saved on this device. Account sync will retry later.";
    }
  };
})();
