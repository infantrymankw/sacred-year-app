
(function(){
  const getClient=()=>window.sySupabase||window.supabase;
  const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));

  // --- Hall+ main menu navigation ---
  // Preserve the existing Hall+ renderer, then add an explicit exit button.
  const sy327BaseHallPlus=window.syOpenHallPlus;
  if(sy327BaseHallPlus){
    window.syOpenHallPlus=async function(...args){
      const result=await sy327BaseHallPlus.apply(this,args);
      requestAnimationFrame(()=>{
        const sheet=document.getElementById("sheet");
        if(!sheet)return;
        sheet.dataset.sy327Screen="hallplus-main";
        if(!sheet.querySelector("#sy327BackSacredYear")){
          const b=document.createElement("button");
          b.type="button";
          b.id="sy327BackSacredYear";
          b.className="btn secondary";
          b.style.marginTop="14px";
          b.style.width="100%";
          b.textContent="Back to Sacred Year";
          b.addEventListener("click",()=>{
            sheet.dataset.sy327Screen="";
            closeDrawer();
          });
          sheet.appendChild(b);
        }
      });
      return result;
    };
  }

  // Backdrop navigation is based on the screen heading/kicker, not words that
  // happen to appear inside Hall+ cards (Event Studio, Divination, etc.).
  window.sy324Backdrop=function(){
    const sheet=document.getElementById("sheet");
    const kicker=(sheet?.querySelector(".kicker")?.textContent||"").trim().toLowerCase();
    const title=(sheet?.querySelector("h3")?.textContent||"").trim().toLowerCase();

    // Hall+ nested tools go back to Hall+.
    if(kicker.startsWith("hall+ ·") || kicker.startsWith("hall+ •")){
      window.syOpenHallPlus?.();
      return;
    }

    // Hall+ main itself exits to the underlying Sacred Year screen.
    if(sheet?.dataset?.sy327Screen==="hallplus-main" ||
       kicker==="hall+" ||
       title==="hall+"){
      sheet.dataset.sy327Screen="";
      closeDrawer();
      return;
    }

    // Deep moderation screens return to the Moderation Center.
    if(title==="open reports" ||
       title==="posts & replies" ||
       title==="event moderation" ||
       title==="user restrictions" ||
       title==="audit trail"){
      window.sy321ModerationHome?.();
      return;
    }

    // Creator child screens return to Creator Control Center.
    if(title==="manage published content" ||
       title==="edit published content" ||
       title==="words from the hall" ||
       title==="moderation center"){
      window.syOpenCreator?.();
      return;
    }

    closeDrawer();
  };

  // --- Words from the Hall publisher ---
  // Override the old inline onclick version with real listeners, which are
  // reliable on the Android browser/local-file path used during testing.
  window.sy321OpenPublisher=function(){
    openDrawer(`<div class="kicker">Private Creator Dashboard</div><h3>Words from the Hall</h3>
      <label>Title</label><input id="syPT" value="Words from the Hall"/>
      <label>Message</label><textarea id="syPM" rows="6"></textarea>
      <label>Label</label><select id="syPL">
        <option>AlanWolfsie Reflection</option>
        <option>Modern Practice</option>
        <option>Historical Note</option>
        <option>Announcement</option>
      </select>
      <label><input id="syPN" type="checkbox" checked style="width:auto;margin-right:7px">Queue notification</label>
      <div class="row" style="margin-top:14px">
        <button type="button" class="btn" id="sy327Publish">Publish</button>
        <button type="button" class="btn secondary" id="sy327CreatorBack">Back to Creator Dashboard</button>
      </div>
      <p class="note" id="sy327PublishStatus" style="margin-top:10px"></p>`);

    requestAnimationFrame(()=>{
      document.getElementById("sy327Publish")?.addEventListener("click",()=>window.sy327PublishWords());
      document.getElementById("sy327CreatorBack")?.addEventListener("click",()=>window.syOpenCreator?.());
    });
  };

  window.sy327PublishWords=async function(){
    const btn=document.getElementById("sy327Publish");
    const status=document.getElementById("sy327PublishStatus");
    if(btn?.disabled)return;

    try{
      const c=getClient();
      if(!c)throw new Error("Sacred Year could not connect to the database.");

      const {data:{session},error:sessionError}=await c.auth.getSession();
      if(sessionError)throw sessionError;
      if(!session?.user)throw new Error("Your sign-in session could not be found. Please sign in again.");

      const {data:profile,error:profileError}=await c.from("profiles")
        .select("role").eq("id",session.user.id).maybeSingle();
      if(profileError)throw profileError;
      if(profile?.role!=="creator")throw new Error("Creator access is not enabled for this account.");

      const title=(document.getElementById("syPT")?.value||"").trim()||"Words from the Hall";
      const message=(document.getElementById("syPM")?.value||"").trim();
      const label=document.getElementById("syPL")?.value||"AlanWolfsie Reflection";
      const sendNotification=!!document.getElementById("syPN")?.checked;
      if(!message)throw new Error("Write a message first.");

      if(btn){btn.disabled=true;btn.textContent="Publishing…";}
      if(status)status.textContent="Saving your message…";

      const row={
        author_id:session.user.id,
        title,
        message,
        label,
        status:"published",
        send_notification:sendNotification,
        published_at:new Date().toISOString()
      };
      const {data:post,error:postError}=await c.from("creator_posts").insert(row).select().single();
      if(postError)throw postError;

      let queueWarning="";
      if(sendNotification){
        try{await window.syPushSendCreatorPost(post.id);}catch(e){queueWarning=e?.message||"Push could not be sent.";}
      }

      try{ if(window.syLoadWord) await window.syLoadWord(); else if(typeof syLoadWord==="function") await syLoadWord(); }catch(e){}

      if(queueWarning){
        alert("Published to Sacred Year, but the push could not be sent: "+queueWarning);
      }else{
        alert(sendNotification
          ?"Published to Sacred Year. Creator push requested."
          :"Published to Sacred Year.");
      }
      window.syOpenCreator?.();
    }catch(e){
      const msg=e?.message||"The post could not be published.";
      if(status)status.textContent=msg;
      alert(msg);
    }finally{
      if(btn){btn.disabled=false;btn.textContent="Publish";}
    }
  };
})();
