
const SY_LIB={
 havamal:{title:"Hávamál",kicker:"Hávamál",source:"Henry Adams Bellows, The Poetic Edda (1923)",text:document.getElementById("havamalData")?.textContent.trim()||""},
 poetic:{title:"The Poetic Edda",kicker:"Poetic Edda",source:"Henry Adams Bellows translation (1923)",text:document.getElementById("poeticData")?.textContent.trim()||""},
 prose:{title:"The Prose Edda",kicker:"Prose Edda",source:"Rasmus B. Anderson edition",text:document.getElementById("proseData")?.textContent.trim()||""}
};
function syRefreshSavedCards(){
 const r=JSON.parse(syLocalStorage.getItem('sy_saved_rune')||'null'),b=JSON.parse(syLocalStorage.getItem('sy_reader_bookmark')||'null');
 const rt=document.getElementById('savedRuneText'),bt=document.getElementById('savedReadingText');
 if(rt)rt.textContent=r?r.filter(Boolean).join(' — '):'None saved.';
 if(bt)bt.textContent=b?(b.title||b.work)+' bookmark saved.':'No bookmark.';
}
let syLibBook="havamal";
const syReader=document.getElementById("reader");

function syLibBookData(){return SY_LIB[syLibBook]}

function syLibOpenBook(key,restore=true){
 if(!SY_LIB[key])return;
 syLibBook=key;
 document.querySelectorAll(".bookpick").forEach(b=>b.classList.remove("active"));
 document.getElementById("pick-"+key)?.classList.add("active");
 const b=SY_LIB[key];
 document.getElementById("readerKicker").textContent=b.kicker;
 document.getElementById("readerTitle").textContent=b.title;
 document.getElementById("readerSource").textContent=b.source;
 const s=document.getElementById("readerSearch");s.value="";s.placeholder="Search "+b.title+"…";
 syReader.textContent=b.text;
 syReader.scrollTop=0;
 if(restore)syLibRestore(key);
 syLibUpdateContinue();
}

function syLibSearch(){
 const q=document.getElementById("readerSearch").value.trim().toLowerCase(),full=syLibBookData().text;
 if(!q){syReader.textContent=full;return}
 const lines=full.split("\n"),hits=[];
 for(let i=0;i<lines.length;i++){
   if(lines[i].toLowerCase().includes(q))hits.push(lines.slice(Math.max(0,i-2),Math.min(lines.length,i+3)).join("\n"));
 }
 syReader.textContent=hits.length?hits.join("\n\n———\n\n"):"No matches found.";
}

function syLibTextSize(s){
 syReader.style.fontSize=s==="small"?"14px":s==="large"?"20px":"16px";
 syLocalStorage.setItem("sy_reader_size",s);
}

async function syLibBookmark(){
 const syAccountScope=window.sy25Scope();

 const b={work:syLibBook,title:syLibBookData().title,position:{scrollTop:syReader.scrollTop},saved_at:new Date().toISOString()};
 syLocalStorage.setItem("sy_reader_bookmark",JSON.stringify(b));
 try{
   if(window.sySupabase){
     const {data:{session}}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.auth.getSession())),syAccountScope);
     if(session?.user)await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("bookmarks").upsert({user_id:session.user.id,work:syLibBook,position:b.position,saved_at:b.saved_at},{onConflict:"user_id,work"}))),syAccountScope);
   }
 }catch(e){}
 syLibUpdateContinue();
 alert("Reading place saved.");
}

function syLibRestore(key){
 const b=JSON.parse(syLocalStorage.getItem("sy_reader_bookmark")||"null");
 if(b&&b.work===key)setTimeout(()=>syReader.scrollTop=b.position?.scrollTop||0,80);
}

function syLibUpdateContinue(){
 syRefreshSavedCards();
 const b=JSON.parse(syLocalStorage.getItem("sy_reader_bookmark")||"null");
 const t=document.getElementById("syLibContinueText");
 if(t)t.textContent=b?`${b.title||b.work} • saved ${syDisplayDate(b.saved_at)}`:"No saved reading place yet.";
}

function syLibContinue(){
 const b=JSON.parse(syLocalStorage.getItem("sy_reader_bookmark")||"null");
 if(!b){alert("No reading bookmark yet.");return}
 syLibOpenBook(b.work,true);
 closeDrawer?.();
}

function syLibCurrentSnippet(){
 const txt=syLibBookData().text;
 const ratio=syReader.scrollHeight>syReader.clientHeight?syReader.scrollTop/(syReader.scrollHeight-syReader.clientHeight):0;
 const idx=Math.max(0,Math.min(txt.length-1,Math.floor(ratio*txt.length)));
 const start=Math.max(0,txt.lastIndexOf("\n",Math.max(0,idx-300)));
 const end=Math.min(txt.length,txt.indexOf("\n",idx+350)>0?txt.indexOf("\n",idx+350):idx+350);
 return txt.slice(start,end).trim().slice(0,900);
}

function syLibFavoriteCurrent(){
 const snip=syLibCurrentSnippet();if(!snip)return;
 const a=JSON.parse(syLocalStorage.getItem("sy_library_favorites")||"[]");
 a.unshift({work:syLibBook,title:syLibBookData().title,text:snip,saved_at:new Date().toISOString()});
 syLocalStorage.setItem("sy_library_favorites",JSON.stringify(a.slice(0,150)));
 alert("Passage added to Favorites.");
}

function syLibOpenFavorites(){
 const a=JSON.parse(syLocalStorage.getItem("sy_library_favorites")||"[]");
 openDrawer(`<div class="kicker">Sacred Library</div><h3>Favorites</h3><div class="list">${a.map((x,i)=>`<div class="item"><div class="kicker">${x.title}</div><p>${x.text.replaceAll("<","&lt;").replaceAll(">","&gt;")}</p><div class="note">${new Date(x.saved_at).toLocaleString()}</div><button class="btn secondary" onclick="syLibRemoveSaved('favorites',${i},this)">Remove favorite</button></div>`).join("")||'<p class="note">No favorite passages yet.</p>'}</div>`);
}

function syLibNoteCurrent(){
 const snip=syLibCurrentSnippet();
 openDrawer(`<div class="kicker">Reading Note</div><h3>${syLibBookData().title}</h3><p class="note">${snip.slice(0,300).replaceAll("<","&lt;").replaceAll(">","&gt;")}</p><label>Your note</label><textarea id="syLibNoteText" rows="7" placeholder="What do you want to remember about this passage?"></textarea><button class="btn" onclick="syLibSaveNote()">Save note</button>`);
 window.__syLibPendingSnippet=snip;
}
function syLibSaveNote(){
 const note=document.getElementById("syLibNoteText").value.trim();if(!note)return;
 const a=JSON.parse(syLocalStorage.getItem("sy_library_notes")||"[]");
 a.unshift({work:syLibBook,title:syLibBookData().title,snippet:window.__syLibPendingSnippet||"",note,saved_at:new Date().toISOString()});
 syLocalStorage.setItem("sy_library_notes",JSON.stringify(a.slice(0,200)));
 closeDrawer();alert("Reading note saved.");
}
function syLibOpenNotes(){
 const a=JSON.parse(syLocalStorage.getItem("sy_library_notes")||"[]");
 openDrawer(`<div class="kicker">Sacred Library</div><h3>Reading Notes</h3><div class="list">${a.map((x,i)=>`<div class="item"><div class="kicker">${x.title}</div><p><b>Passage:</b> ${(x.snippet||"").slice(0,220).replaceAll("<","&lt;").replaceAll(">","&gt;")}</p><p>${x.note.replaceAll("<","&lt;").replaceAll(">","&gt;")}</p><div class="note">${new Date(x.saved_at).toLocaleString()}</div><button class="btn secondary" onclick="syLibRemoveSaved('notes',${i},this)">Remove note</button></div>`).join("")||'<p class="note">No notes yet.</p>'}</div>`);
}

async function syLibRemoveSaved(kind,index,button){
 const syAccountScope=window.sy25Scope();

 const syLocalStorage=window.syLocalStorage.forUser(window.syStorageUID?.());
 if(!['notes','favorites'].includes(kind))return;
 const key='sy_library_'+kind,a=JSON.parse(syLocalStorage.getItem(key)||'[]'),item=a[index];if(!item)return;
 button.disabled=true;
 try{
  const db=window.sySupabase;
  if(db){const {data:{session}}=await window.sy25Await((window.sy25Assert(syAccountScope), (db.auth.getSession())),syAccountScope);if(session?.user){
   const {error}=await window.sy25Await((window.sy25Assert(syAccountScope), (db.from('library_'+kind).delete().eq('user_id',session.user.id).eq('saved_at',item.saved_at))),syAccountScope);if(error)throw error;
  }}
  const current=JSON.parse(syLocalStorage.getItem(key)||'[]');
  syLocalStorage.setItem(key,JSON.stringify(current.filter(x=>!(x.saved_at===item.saved_at&&x.work===item.work))));
  (kind==='notes'?syLibOpenNotes:syLibOpenFavorites)();
 }catch(e){button.disabled=false;alert('Could not remove this saved item. Check your connection and try again.');}
}
function syLibHeadings(key){
 const text=SY_LIB[key].text,lines=text.split("\n"),out=[];
 const commonPoems=["VÖLUSPÁ","VOLUSPO","HÁVAMÁL","HOVAMOL","VAFTHRUTHNISMOL","GRIMNISMOL","SKIRNISMOL","HARBARTHSLJOTH","HYMISKVITHA","LOKASENNA","THRYMSKVITHA","ALVISSMOL","VOLUNDARKVITHA","HELREITH BRYNHILDAR","SIGRDRIFUMOL"];
 if(key==="poetic"){
   lines.forEach((ln,i)=>{const s=ln.trim();if(s.length>3&&s.length<45&&(s===s.toUpperCase())&&/[A-ZÁÉÍÓÚÝÞÐÖ]/.test(s))out.push({title:s,line:i})});
 }else if(key==="prose"){
   lines.forEach((ln,i)=>{const s=ln.trim();if((/^CHAPTER\s+/i.test(s)||/^I\.\s|^II\.\s|^III\.\s|^IV\.\s|^V\.\s/.test(s))&&s.length<90)out.push({title:s,line:i})});
 }else{
   for(let i=1;i<=164;i+=10)out.push({title:`Stanzas ${i}–${Math.min(i+9,164)}`,line:0,stanza:i});
 }
 // de-duplicate and cap
 const seen=new Set();return out.filter(x=>{if(seen.has(x.title))return false;seen.add(x.title);return true}).slice(0,80);
}

function syLibOpenContents(){
 const items=syLibHeadings(syLibBook);
 openDrawer(`<div class="kicker">${syLibBookData().title}</div><h3>Contents</h3><div class="list">${items.map((x,i)=>`<button class="lib-toc-btn" onclick="syLibJump(${i})"><b>${x.title}</b></button>`).join("")||'<p class="note">No section headings detected.</p>'}</div>`);
 window.__syLibToc=items;
}
function syLibJump(i){
 const x=window.__syLibToc?.[i];if(!x)return;
 closeDrawer();
 const text=syLibBookData().text;
 if(x.stanza){
   const patterns=[`\n${x.stanza}.`,`\n${x.stanza} `,`\n${x.stanza}\n`];
   let idx=-1;for(const q of patterns){idx=text.indexOf(q);if(idx>=0)break}
   if(idx<0)idx=0;
   syReader.textContent=text;
   setTimeout(()=>{syReader.scrollTop=(idx/text.length)*(syReader.scrollHeight-syReader.clientHeight)},50);
 }else{
   const lines=text.split("\n"),before=lines.slice(0,x.line).join("\n").length;
   syReader.textContent=text;
   setTimeout(()=>{syReader.scrollTop=(before/text.length)*(syReader.scrollHeight-syReader.clientHeight)},50);
 }
}

window.syLibOpenBook=syLibOpenBook;
window.syLibSearch=syLibSearch;
window.syLibTextSize=syLibTextSize;
window.syLibBookmark=syLibBookmark;
window.syLibContinue=syLibContinue;
window.syLibFavoriteCurrent=syLibFavoriteCurrent;
window.syLibOpenFavorites=syLibOpenFavorites;
window.syLibNoteCurrent=syLibNoteCurrent;
window.syLibSaveNote=syLibSaveNote;
window.syLibOpenNotes=syLibOpenNotes;
window.syLibOpenContents=syLibOpenContents;
window.syLibJump=syLibJump;

syLibOpenBook("havamal",false);
const sySavedSize=syLocalStorage.getItem("sy_reader_size");if(sySavedSize)syLibTextSize(sySavedSize);
syLibUpdateContinue();
