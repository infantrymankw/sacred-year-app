
window.sy319RsvpSet=new Set();

window.sy319LoadMyRsvps=async function(){
  try{
    const scope=window.sy25Scope();
    const sess=await sy19Session();
    window.sy25Assert(scope);
    if(!sess?.user){window.sy319RsvpSet=new Set();return}
    const {data,error}=await window.sySupabase
      .from("community_event_rsvps")
      .select("event_id,status")
      .eq("user_id",sess.user.id);
    if(error)throw error;
    window.sy25Assert(scope);
    window.sy319RsvpSet=new Set((data||[])
      .filter(r=>r.status==="interested"||r.status==="going")
      .map(r=>r.event_id));
  }catch(e){
    window.sy319RsvpSet=new Set();
  }
};

window.sy319RemoveRsvp=async function(eventId){
 const syAccountScope=window.sy25Scope();

  try{
    const sess=await window.sy25Await((window.sy25Assert(syAccountScope), (sy19Session())),syAccountScope);
    if(!sess?.user){closeDrawer();openAccount();return}
    const {error}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase
      .from("community_event_rsvps")
      .delete()
      .eq("event_id",eventId)
      .eq("user_id",sess.user.id))),syAccountScope);
    if(error)throw error;
    window.sy319RsvpSet.delete(eventId);
    alert("Removed from your interested events.");
    if(window.sy19LoadEvents) await window.sy25Await((window.sy25Assert(syAccountScope), (sy19LoadEvents())),syAccountScope);
  }catch(e){
    alert(e.message||"Could not remove this event from your interested events.");
  }
};

window.sy319ToggleRsvp=async function(eventId){
  if(window.sy319RsvpSet.has(eventId)){
    await sy319RemoveRsvp(eventId);
  }else{
    await sy19RSVP(eventId);
    window.sy319RsvpSet.add(eventId);
    if(window.sy19LoadEvents) await sy19LoadEvents();
  }
};
