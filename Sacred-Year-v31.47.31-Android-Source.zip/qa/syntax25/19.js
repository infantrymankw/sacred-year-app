
const SY25_RUNES=[
 {g:"ᚠ",n:"Fehu",sound:"f",hist:"Cattle / movable wealth.",poem:"Later rune poems associate this rune with wealth or cattle and the responsibilities or conflict wealth can bring.",modern:"Resources, exchange, stewardship, prosperity.",note:"The historical core is wealth/cattle. Modern meanings such as abundance or manifestation are later interpretive systems."},
 {g:"ᚢ",n:"Uruz",sound:"u",hist:"Aurochs / wild ox, though exact reconstruction is debated.",poem:"The Old English rune poem associates Ur with the aurochs; other later traditions complicate the picture.",modern:"Strength, vitality, endurance, raw potential.",note:"The aurochs interpretation is common but the rune-name history is not perfectly simple."},
 {g:"ᚦ",n:"Thurisaz",sound:"th",hist:"Þurs / giant-like hostile being; later traditions also use thorn imagery.",poem:"Old Norse/Icelandic traditions connect the rune with þurs; Old English with thorn.",modern:"Challenge, defense, force, boundaries.",note:"There is no single ancient oracle definition. 'Protection' is a modern interpretive extension."},
 {g:"ᚨ",n:"Ansuz",sound:"a",hist:"A god / divine being; later rune traditions also connect it with mouth/speech.",poem:"Old English Os is associated with the mouth/source of speech; the reconstructed Germanic name points toward a divine being.",modern:"Speech, inspiration, message, wisdom.",note:"Modern 'communication rune' language simplifies a more complex historical trail."},
 {g:"ᚱ",n:"Raidho",sound:"r",hist:"Ride / journey.",poem:"Rune-poem material strongly preserves travel, riding, and the difficulty or value of movement.",modern:"Journey, rhythm, right movement, travel.",note:"Travel is historically grounded; destiny/path language is modern interpretation."},
 {g:"ᚲ",n:"Kenaz",sound:"k",hist:"Meaning debated: torch in Old English tradition; ulcer in Scandinavian rune poems.",poem:"This rune vividly shows why later rune poems do not always preserve one identical meaning.",modern:"Knowledge, craft, illumination, controlled fire.",note:"The popular 'torch = enlightenment' reading is modern and should be labeled as such."},
 {g:"ᚷ",n:"Gebo",sound:"g",hist:"Gift.",poem:"The Old English rune poem presents gift-giving as honor and support between people.",modern:"Gift, reciprocity, exchange, relationship.",note:"Reciprocity is a reasonable modern reflection built from the historically attested idea of gift."},
 {g:"ᚹ",n:"Wunjo",sound:"w",hist:"Joy / pleasure.",poem:"Old English Wynn concerns joy and comfort for those who know little hardship.",modern:"Joy, fellowship, harmony, belonging.",note:"Historically grounded in joy, but modern emotional/spiritual keywords are interpretive."},
 {g:"ᚺ",n:"Hagalaz",sound:"h",hist:"Hail.",poem:"Later rune poems consistently use hail as dangerous, cold, destructive, and transient.",modern:"Disruption, change, uncontrollable force.",note:"Transformation is a modern lesson drawn from the natural image, not an ancient dictionary definition."},
 {g:"ᚾ",n:"Nauthiz",sound:"n",hist:"Need / constraint.",poem:"Rune poems emphasize hardship, necessity, constraint, and in some traditions the ability to learn from need.",modern:"Necessity, hardship, resilience, discipline.",note:"Resilience is a modern interpretive development from the older core of need."},
 {g:"ᛁ",n:"Isa",sound:"i",hist:"Ice.",poem:"Ice is described as cold, slippery, beautiful, and dangerous in later rune-poem traditions.",modern:"Stillness, delay, concentration, preservation.",note:"The historical image is ice; psychological meanings such as stagnation are modern."},
 {g:"ᛃ",n:"Jera",sound:"y / j",hist:"Year / harvest cycle.",poem:"Later evidence links the rune with year, harvest, good season, and reward from seasonal cycles.",modern:"Harvest, timing, cycles, earned results.",note:"This is one of the easier cases where modern interpretation remains close to the historical image."},
 {g:"ᛇ",n:"Eihwaz",sound:"ï / ei",hist:"Yew.",poem:"The Old English rune poem associates the yew with a hard, rooted, durable tree.",modern:"Endurance, resilience, continuity, transformation.",note:"Death/rebirth symbolism often attached to yew in modern rune books goes beyond the rune-poem text."},
 {g:"ᛈ",n:"Perthro",sound:"p",hist:"Historical meaning uncertain.",poem:"The Old English rune poem uses Peorð in a context that has been interpreted as gaming, lot-cup, or pleasure, but certainty is lacking.",modern:"Mystery, chance, hidden factors.",note:"This is one of the least secure rune meanings. Sacred Year treats certainty here as a red flag."},
 {g:"ᛉ",n:"Algiz",sound:"z / r",hist:"Name and meaning debated; later rune evidence is difficult to reconcile.",poem:"Old English Eolh appears associated with a sedge-like plant; reconstructed names and later sound changes complicate the picture.",modern:"Protection, boundary, sacred awareness.",note:"The common 'protection rune' meaning is modern and much more certain in modern practice than in the historical evidence."},
 {g:"ᛋ",n:"Sowilo",sound:"s",hist:"Sun.",poem:"Later rune poems strongly preserve the sun image as guiding, radiant, and beneficial.",modern:"Clarity, vitality, success, wholeness.",note:"The historical core is secure; abstract spiritual keywords remain modern interpretation."},
 {g:"ᛏ",n:"Tiwaz",sound:"t",hist:"The god Tīwaz / Týr.",poem:"Old English Tir invokes a star-like guiding image; linguistic evidence firmly connects the rune name with the Germanic god-name.",modern:"Duty, courage, justice, honorable sacrifice.",note:"The divine-name connection is strong. A full modern 'justice rune' doctrine is not directly preserved."},
 {g:"ᛒ",n:"Berkano",sound:"b",hist:"Birch.",poem:"Birch imagery is preserved in later rune traditions, though the exact details vary.",modern:"Growth, nurturing, renewal, beginnings.",note:"Modern motherhood/fertility associations are interpretive rather than a surviving standardized rune meaning."},
 {g:"ᛖ",n:"Ehwaz",sound:"e",hist:"Horse.",poem:"Old English Eh emphasizes the horse as a joy to nobles and useful in travel.",modern:"Trust, movement, partnership, cooperation.",note:"Partnership is a modern reflection grounded in the relationship between rider and horse."},
 {g:"ᛗ",n:"Mannaz",sound:"m",hist:"Human / person.",poem:"Later rune poems concern humanity, social bonds, mortality, and dependence on others.",modern:"Self, humanity, society, community.",note:"The historical word is straightforward; modern self-development language is interpretive."},
 {g:"ᛚ",n:"Laguz",sound:"l",hist:"Water / lake.",poem:"Later evidence links the rune to water, sea, or lake imagery and the danger or depth of water.",modern:"Flow, intuition, emotion, adaptability.",note:"Emotion and intuition are modern symbolic extensions of water imagery."},
 {g:"ᛜ",n:"Ingwaz",sound:"ng",hist:"Ing, a Germanic divine/heroic name.",poem:"Old English Ing describes a figure named Ing who was first seen among East-Danes and departed eastward.",modern:"Potential, fertility, gestation, completion.",note:"The connection to Ing is historical; detailed fertility symbolism is reconstructed through wider Germanic comparison."},
 {g:"ᛞ",n:"Dagaz",sound:"d",hist:"Day.",poem:"Old English Dæg is day, sent by the Lord and valued by all people.",modern:"Dawn, breakthrough, transition, clarity.",note:"Day is historically secure; 'breakthrough' is a modern symbolic reading."},
 {g:"ᛟ",n:"Othala",sound:"o",hist:"Inherited estate / ancestral property.",poem:"Old English Ēðel concerns homeland/property valued when a person may enjoy rights and prosperity there.",modern:"Heritage, home, inheritance, ancestry.",note:"The historical meaning centers strongly on inherited estate/property. Modern ancestry-only readings can blur that."}
];

function sy25RuneStudy(){
 openDrawer(`<div class="kicker">Rune Study</div><h3>Elder Futhark: Start with the Alphabet</h3>
 <p class="note">The Elder Futhark is an early Germanic runic alphabet of 24 characters, used roughly in the first millennium before Younger Futhark becomes dominant in Viking-Age Scandinavia.</p>
 <div class="sy25-alpha"><h4>Before divination</h4><p>Learn each rune as a letter first: its shape, sound value, reconstructed name, inscriptional use, and later rune-poem evidence. Modern spiritual meanings come afterward.</p></div>
 <div class="sy25-runegrid">${SY25_RUNES.map(r=>`<button class="sy25-rune" onclick="sy25OpenRune('${r.n}')"><div class="glyph">${r.g}</div><h4>${r.n}</h4><p>${r.hist}</p></button>`).join("")}</div>
 <div class="holiday" style="margin-top:12px"><div class="kicker">Historical caution</div><p>Our surviving rune poems are later than the Elder Futhark period. They are valuable evidence, but they are not a preserved Elder Futhark divination manual.</p></div>`);
}

function sy25OpenRune(name){
 const r=SY25_RUNES.find(x=>x.n===name);if(!r)return;
 openDrawer(`<div class="kicker">Rune Study</div><h3 style="font-size:42px">${r.g} ${r.n}</h3>
 <div><span class="sy25-tag">Sound: ${r.sound}</span><span class="sy25-tag">Elder Futhark</span></div>
 <div class="item" style="margin-top:10px"><h4>Historical core</h4><p>${r.hist}</p></div>
 <div class="item" style="margin-top:10px"><h4>Rune-poem evidence</h4><p>${r.poem}</p></div>
 <div class="item" style="margin-top:10px"><h4>Modern interpretation</h4><p>${r.modern}</p></div>
 <div class="holiday" style="margin-top:10px"><div class="kicker">Evidence note</div><p class="sy25-evidence">${r.note}</p></div>
 <div class="row"><button class="btn secondary" onclick="sy25RuneStudy()">Back to Rune Study</button><button class="btn secondary" onclick="syDrawRune()">Draw a rune</button></div>`);
}
window.sy25RuneStudy=sy25RuneStudy;window.sy25OpenRune=sy25OpenRune;

/* Upgrade Rune Circle doors to the study version, while preserving save/journal tools. */
setTimeout(()=>{
 const buttons=[...document.querySelectorAll("button,.section-card")];
 for(const b of buttons){
  const t=(b.textContent||"").trim();
  if(/^Rune Circle$/i.test(t)||/study the futhark/i.test(t)){
    b.onclick=sy25RuneStudy;
  }
 }
},700);
