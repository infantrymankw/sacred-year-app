
function sy29TodayPolish(){
 const today=document.getElementById("today"); if(!today||document.getElementById("sy29TodayHero"))return;
 const nav=today.querySelector(".section-nav");
 if(!nav)return;

 const hero=document.createElement("div");
 hero.id="sy29TodayHero"; hero.className="sy29-hero";
 hero.innerHTML=`<div class="kicker">Sacred Year • Today</div>
 <h3>A quiet place to learn and practice.</h3>
 <p>See what is coming in the sacred year, learn one thing, or take a few minutes for practice. You do not have to use every part of the app every day.</p>
 <div class="sy29-actions">
   <button class="sy29-action" onclick="sy23StartHere()"><div class="kicker">Learn</div><h4>Start Here</h4><p>Seven short lessons for beginners.</p></button>
   <button class="sy29-action" onclick="sy26HolidayStudy()"><div class="kicker">Calendar</div><h4>Sacred Year</h4><p>Holidays, evidence, and modern observance.</p></button>
   <button class="sy29-action" onclick="sy27Library()"><div class="kicker">Read</div><h4>Library</h4><p>Hávamál, Eddas, notes, search, bookmarks.</p></button>
   <button class="sy29-action" onclick="sy28RitualHall()"><div class="kicker">Practice</div><h4>Ritual Hall</h4><p>Simple offerings and everyday practice.</p></button>
 </div>`;
 nav.parentNode.insertBefore(hero,nav);

 /* Existing section cards remain available, but collapse secondary discovery
    so Today does not become a wall of buttons. */
 const wrap=document.createElement("details");
 wrap.className="sy29-more";
 wrap.innerHTML='<summary>Explore more of Sacred Year</summary>';
 nav.parentNode.insertBefore(wrap,nav);
 wrap.appendChild(nav);

 const note=document.createElement("div");
 note.className="holiday"; note.style.marginTop="12px";
 note.innerHTML='<div class="kicker">Design principle</div><p class="sy29-principle"><b>Simple enough to use every day. Deep enough to keep learning from.</b></p>';
 hero.parentNode.insertBefore(note,wrap.nextSibling);
}
setTimeout(sy29TodayPolish,1000);
window.sy29TodayPolish=sy29TodayPolish;
