
(function(){
  let sy323ReturnFn = null;
  let sy323Depth = 0;

  function remember(fn){ sy323ReturnFn = fn; }
  window.sy323RememberMenu = remember;

  // Hub openers explicitly register themselves as the preferred return destination.
  const wrapHub = (name)=>{
    const original = window[name];
    if(!original) return;
    window[name] = async function(...args){
      remember(()=>window[name](...args));
      return await original.apply(this,args);
    };
  };

  // These are the menu-like screens users expect to return to.
  setTimeout(()=>{
    ["syOpenCreator","sy321ModerationHome","sy322CreatorPosts","syOpenHallPlus","syHallPlusHome","syOpenPracticeTools","syOpenNotificationSettings"].forEach(wrapHub);
  },0);

  // Preserve the user's current hub when opening nested screens from creator tools.
  const nested = ["sy321Reports","sy321Posts","sy321Events","sy321Users","sy321Audit","sy321OpenPublisher","sy322EditCreatorPost"];
  setTimeout(()=>{
    nested.forEach(name=>{
      const original=window[name];
      if(!original) return;
      window[name]=async function(...args){
        sy323Depth++;
        return await original.apply(this,args);
      };
    });
  },0);

  // Expose a reusable Back button action.
  window.sy323BackToMenu=function(){
    if(sy323ReturnFn){
      try{ sy323ReturnFn(); return; }catch(e){}
    }
    try{ closeDrawer(); }catch(e){}
  };
})();
