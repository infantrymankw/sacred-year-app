
const SY_COMMUNITY_CHANNELS=[
 {id:"general",name:"General"},
 {id:"events",name:"Events"},
 {id:"rituals",name:"Rituals"},
 {id:"study",name:"Study"},
 {id:"local",name:"Local"}
];
let syCommunityChannel="general";
let syCommunityPosts=[];

async function syCommunitySession(){
 const syAccountScope=window.sy25Scope();

 try{
   if(!window.sySupabase)return null;
   const {data:{session}}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.auth.getSession())),syAccountScope);
   return session||null;
 }catch(e){return null}
}
function syCommunityEscape(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}

async function syCommunityLoad(){
 const syAccountScope=window.sy25Scope();

 syCommunityPosts=[];
 try{
   if(window.sySupabase){
     const {data,error}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase
       .from("community_post_feed")
       .select("id,user_id,channel,title,body,region,created_at,display_name")
       .eq("channel",syCommunityChannel)
       .order("created_at",{ascending:false})
       .limit(50))),syAccountScope);
     if(!error&&data)syCommunityPosts=data;
   }
 }catch(e){}
 syCommunityRender();
}

function syOpenCommunityHall(){
 openDrawer(`<div class="kicker">Community Hall</div><h3>Connect with other Pagans</h3>
 <p class="note">Use Community Hall for discussion, events, study, ritual questions, and local connection. Be respectful and do not share private information you would not want public.</p>
 <div class="community-tabs">${SY_COMMUNITY_CHANNELS.map(c=>`<button class="community-tab ${c.id===syCommunityChannel?"active":""}" onclick="syCommunitySetChannel('${c.id}')">${c.name}</button>`).join("")}</div>
 <div class="row"><button class="btn" onclick="syCommunityNewPost()">New post</button><button class="btn secondary" onclick="syCommunityLoad()">Refresh</button><button id="syModBtn" class="btn secondary" style="display:none" onclick="syCommunityModeration()">Moderation</button></div>
 <div id="syCommunityFeed"></div>`);
 syCommunityLoad();
}
window.syOpenCommunityHall=syOpenCommunityHall;

function syCommunitySetChannel(id){
 syCommunityChannel=id;
 syOpenCommunityHall();
}

async function syCommunityRender(){
 const syAccountScope=window.sy25Scope();

 const feed=document.getElementById("syCommunityFeed");if(!feed)return;
 let session=null,blockedIds=new Set();
 try{
   session=await window.sy25Await((window.sy25Assert(syAccountScope), (syCommunitySession())),syAccountScope);
   if(session?.user&&window.sySupabase){
     const {data}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("user_blocks").select("blocked_user_id").eq("blocker_id",session.user.id))),syAccountScope);
     (data||[]).forEach(x=>blockedIds.add(x.blocked_user_id));
   }
 }catch(e){}
 const visible=syCommunityPosts.filter(p=>!blockedIds.has(p.user_id));
 if(!visible.length){
   feed.innerHTML='<p class="community-empty">No posts in this channel yet. Be the first to start a conversation.</p>';return;
 }
 feed.innerHTML=visible.map(p=>{
   const mine=session?.user?.id===p.user_id;
   const name=syCommunityEscape(p.display_name||"Sacred Year member");
   const safeName=String(p.display_name||"Sacred Year member").replace(/\\/g,"\\\\").replace(/'/g,"\\'");
   return `<div class="community-post" data-sy-user-id="${p.user_id}">
   <div class="kicker">${syCommunityEscape(p.channel)}${p.region?" • "+syCommunityEscape(p.region):""}</div>
   <h4>${syCommunityEscape(p.title||"Community post")}</h4>
   <p>${syCommunityEscape(p.body)}</p>
   <div class="community-meta">By ${name} • ${syDisplayDate(p.created_at)}</div>
   <div class="community-actions">
     <button class="btn secondary" onclick="syCommunityOpenThread('${p.id}')">Replies</button>
     <button class="btn secondary" onclick="syCommunityReport('post','${p.id}')">Report post</button>
     ${mine?`<button class="btn secondary" onclick="syCommunityDeleteOwnPost('${p.id}')">Delete</button>`:
       `<button class="btn secondary" onclick="syCommunityReportUser('${p.user_id}','${safeName}')">Report user</button>
        <button class="btn secondary" onclick="syCommunityBlockUser('${p.user_id}','${safeName}')">Block user</button>`}
   </div>
 </div>`}).join("");
}

async function syCommunityNewPost(){
 const syAccountScope=window.sy25Scope();

 const session=await window.sy25Await((window.sy25Assert(syAccountScope), (syCommunitySession())),syAccountScope);
 if(!session?.user){closeDrawer();openAccount();return}
 openDrawer(`<div class="kicker">Community Hall</div><h3>New ${SY_COMMUNITY_CHANNELS.find(x=>x.id===syCommunityChannel)?.name||""} post</h3>
 <label>Title</label><input id="syCommunityTitle" maxlength="120" placeholder="What do you want to discuss?">
 <label>Message</label><textarea id="syCommunityBody" rows="7" maxlength="4000"></textarea>
 ${syCommunityChannel==="local"?'<label>Region</label><input id="syCommunityRegion" maxlength="100" placeholder="Example: Southern Indiana">':""}
 <button type="button" class="btn" id="syCommunityPostBtn">Post to Community Hall</button>
 <p class="note">Avoid posting home addresses, private phone numbers, or other sensitive personal information.</p>`);
 // Attach a real click listener instead of relying on an inline browser event object.
 requestAnimationFrame(()=>{
   const btn=document.getElementById("syCommunityPostBtn");
   if(btn){
     btn.addEventListener("click",async(e)=>{
       e.preventDefault();
       e.stopPropagation();
       await syCommunityPublish();
     },{once:false});
   }
 });
}
async function syCommunityPublish(){
 const syAccountScope=window.sy25Scope();

 const btn=document.getElementById("syCommunityPostBtn");
 if(btn?.disabled)return;
 if(btn){btn.disabled=true;btn.textContent="Connecting…";}
 const session=await window.sy25Await((window.sy25Assert(syAccountScope), (syCommunitySession())),syAccountScope);
 if(!session?.user){
   if(btn){btn.disabled=false;btn.textContent="Post to Community Hall";}
   alert("Your sign-in session could not be found. Please sign in again.");
   return;
 }
 const title=(document.getElementById("syCommunityTitle")?.value||"").trim();
 const body=(document.getElementById("syCommunityBody")?.value||"").trim();
 const region=(document.getElementById("syCommunityRegion")?.value||"").trim()||null;
 if(!body){alert("Write a message first.");return}
 try{
   if(btn)btn.textContent="Posting…";
   const {data,error}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("community_posts").insert({
     user_id:session.user.id,
     channel:syCommunityChannel,
     title:title||null,
     body,
     region
   }).select("id").single())),syAccountScope);
   if(error)throw error;
   if(!data?.id)throw new Error("The post was not saved.");
   alert("Posted to Community Hall.");
   syOpenCommunityHall();
 }catch(e){
   alert((e&&e.message)||"Community posting is not available yet.");
 }finally{
   const current=document.getElementById("syCommunityPostBtn");
   if(current){current.disabled=false;current.textContent="Post to Community Hall";}
 }
}

async function syCommunityOpenThread(postId){
 const syAccountScope=window.sy25Scope();

 let replies=[];
 try{
   const {data}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("community_reply_feed")
     .select("id,user_id,body,created_at,display_name")
     .eq("post_id",postId).order("created_at",{ascending:true}))),syAccountScope);
   replies=data||[];
 }catch(e){}
 openDrawer(`<div class="kicker">Community Thread</div><h3>Replies</h3>
 <div class="list">${replies.map(r=>`<div class="item"><p>${syCommunityEscape(r.body)}</p><div class="community-meta">${syCommunityEscape(r.display_name||"Member")} • ${syDisplayDate(r.created_at)}</div><button class="btn secondary" onclick="syCommunityReport('reply','${r.id}')">Report</button><button class="btn secondary syOwnReply-${r.user_id}" style="display:none" onclick="syCommunityDeleteOwnReply('${r.id}','${postId}')">Delete</button></div>`).join("")||'<p class="community-empty">No replies yet.</p>'}</div>
 <label>Your reply</label><textarea id="syCommunityReply" rows="5" maxlength="2000"></textarea>
 <button class="btn" onclick="syCommunityReply('${postId}')">Reply</button>`);
}
async function syCommunityReply(postId){
 const syAccountScope=window.sy25Scope();

 const session=await window.sy25Await((window.sy25Assert(syAccountScope), (syCommunitySession())),syAccountScope);if(!session?.user){closeDrawer();openAccount();return}
 const body=document.getElementById("syCommunityReply").value.trim();if(!body)return;
 try{
   const {error}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("community_replies").insert({post_id:postId,user_id:session.user.id,body}))),syAccountScope);
   if(error)throw error;syCommunityOpenThread(postId);
 }catch(e){alert(e.message||"Replies are not available yet.");}
}

async function syCommunityReport(kind,id){
 const syAccountScope=window.sy25Scope();

 const session=await window.sy25Await((window.sy25Assert(syAccountScope), (syCommunitySession())),syAccountScope);if(!session?.user){closeDrawer();openAccount();return}
 try{
   let target="Community content";
   if(kind==="post"){
     const post=syCommunityPosts.find(p=>p.id===id);
     if(post)target=post.title||("Post by "+(post.display_name||"member"));
   }
   if(window.sy314OpenReport){
     sy314OpenReport(kind==="post"?"Post":"Other",target);
     const form=document.getElementById("sy314Report");
     if(form){
       delete form.dataset.targetUserId;
       delete form.dataset.eventId;
       form.dataset.communityKind=kind;
       form.dataset.communityId=id;
       const details=document.getElementById("sy314Details");
       if(details)details.placeholder=kind==="post"
         ?"Describe what is wrong with this post and why Sacred Year should review it."
         :"Describe what is wrong with this content and why Sacred Year should review it.";
     }
     return;
   }
   throw new Error("Report form unavailable.");
 }catch(e){
   alert(e.message||"Reporting is not available right now.");
 }
}
async function syCommunityReportUser(userId,displayName){
 const syAccountScope=window.sy25Scope();

 const session=await window.sy25Await((window.sy25Assert(syAccountScope), (syCommunitySession())),syAccountScope);if(!session?.user){closeDrawer();openAccount();return}
 if(session.user.id===userId){alert("You cannot report your own account.");return}
 if(window.sy314OpenReport){
   sy314OpenReport("User",displayName||"Sacred Year member");
   const form=document.getElementById("sy314Report");
   if(form)form.dataset.targetUserId=userId;
   return;
 }
 alert("User reporting is unavailable. Please refresh and try again.");
}
async function syCommunityBlockUser(userId,displayName){
 const syAccountScope=window.sy25Scope();

 const session=await window.sy25Await((window.sy25Assert(syAccountScope), (syCommunitySession())),syAccountScope);if(!session?.user){closeDrawer();openAccount();return}
 if(session.user.id===userId){alert("You cannot block your own account.");return}
 const modal=document.getElementById("sy318Block");
 const nameEl=document.getElementById("sy318BlockName");
 const confirmBtn=document.getElementById("sy318ConfirmBlock");
 const cancelBtn=document.getElementById("sy318CancelBlock");
 if(!modal||!confirmBtn||!cancelBtn){alert("Block controls are unavailable. Please refresh and try again.");return}
 nameEl.textContent=displayName||"this member";
 modal.classList.add("open");

 const close=()=>modal.classList.remove("open");
 cancelBtn.onclick=close;
 confirmBtn.onclick=async()=>{
   confirmBtn.disabled=true;
   confirmBtn.textContent="Blocking…";
   try{
     const {error}=await window.sySupabase.from("user_blocks").upsert(
       {blocker_id:session.user.id,blocked_user_id:userId},
       {onConflict:"blocker_id,blocked_user_id",ignoreDuplicates:true}
     );
     if(error)throw error;
     close();
     alert((displayName||"This member")+" has been blocked.");
     await syCommunityLoad();
   }catch(e){
     alert(e.message||"Could not block this member.");
   }finally{
     confirmBtn.disabled=false;
     confirmBtn.textContent="Block member";
   }
 };
}
window.syCommunityReportUser=syCommunityReportUser;
window.syCommunityBlockUser=syCommunityBlockUser;
window.syCommunitySetChannel=syCommunitySetChannel;
window.syCommunityLoad=syCommunityLoad;
window.syCommunityNewPost=syCommunityNewPost;
window.syCommunityPublish=syCommunityPublish;
window.syCommunityOpenThread=syCommunityOpenThread;
window.syCommunityReply=syCommunityReply;

window.syCommunityReport=syCommunityReport;

async function syCommunityApplyPermissions(){
 const syAccountScope=window.sy25Scope();

 const s=await window.sy25Await((window.sy25Assert(syAccountScope), (syCommunitySession())),syAccountScope);
 if(!s?.user)return;
 document.querySelectorAll(".syOwnPost-"+CSS.escape(s.user.id)).forEach(x=>x.style.display="inline-flex");
 document.querySelectorAll(".syOwnReply-"+CSS.escape(s.user.id)).forEach(x=>x.style.display="inline-flex");
 try{
   const {data}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("profiles").select("role").eq("id",s.user.id).maybeSingle())),syAccountScope);
   const b=document.getElementById("syModBtn");
   if(b&&data?.role==="creator")b.style.display="inline-flex";
 }catch(e){}
}
async function syCommunityDeleteOwnPost(id){
 const syAccountScope=window.sy25Scope();

 if(!confirm("Delete this community post and its replies?"))return;
 const {error}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("community_posts").delete().eq("id",id))),syAccountScope);
 if(error){alert(error.message);return}
 syCommunityLoad();
}
async function syCommunityDeleteOwnReply(id,postId){
 const syAccountScope=window.sy25Scope();

 if(!confirm("Delete this reply?"))return;
 const {error}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("community_replies").delete().eq("id",id))),syAccountScope);
 if(error){alert(error.message);return}
 syCommunityOpenThread(postId);
}
async function syCommunityModeration(){
 const syAccountScope=window.sy25Scope();

 const session=await window.sy25Await((window.sy25Assert(syAccountScope), (syCommunitySession())),syAccountScope);if(!session?.user)return;
 let reports=[];
 try{
   const {data,error}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("community_reports").select("*").eq("status","open").order("created_at",{ascending:false}).limit(50))),syAccountScope);
   if(error)throw error;reports=data||[];
 }catch(e){alert(e.message);return}
 openDrawer(`<div class="kicker">Creator Moderation</div><h3>Open Community Reports</h3>
 <div class="list">${reports.map(r=>`<div class="item"><div class="kicker">${r.post_id?"Post report":"Reply report"}</div><p>${syCommunityEscape(r.reason)}</p><div class="community-meta">${syDisplayDate(r.created_at)}</div><div class="community-actions">${r.post_id?`<button class="btn secondary" onclick="syCommunityHideReported('post','${r.post_id}','${r.id}')">Hide post</button>`:`<button class="btn secondary" onclick="syCommunityHideReported('reply','${r.reply_id}','${r.id}')">Hide reply</button>`}<button class="btn secondary" onclick="syCommunityDismissReport('${r.id}')">Dismiss</button></div></div>`).join("")||'<p class="community-empty">No open reports.</p>'}</div>`);
}
async function syCommunityHideReported(kind,contentId,reportId){
 const syAccountScope=window.sy25Scope();

 const table=kind==="post"?"community_posts":"community_replies";
 const {error}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from(table).update({is_hidden:true}).eq("id",contentId))),syAccountScope);
 if(error){alert(error.message);return}
 await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("community_reports").update({status:"actioned"}).eq("id",reportId))),syAccountScope);
 syCommunityModeration();
}
async function syCommunityDismissReport(reportId){
 const syAccountScope=window.sy25Scope();

 const {error}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("community_reports").update({status:"dismissed"}).eq("id",reportId))),syAccountScope);
 if(error){alert(error.message);return}
 syCommunityModeration();
}
window.syCommunityApplyPermissions=syCommunityApplyPermissions;
window.syCommunityDeleteOwnPost=syCommunityDeleteOwnPost;
window.syCommunityDeleteOwnReply=syCommunityDeleteOwnReply;
window.syCommunityModeration=syCommunityModeration;
window.syCommunityHideReported=syCommunityHideReported;
window.syCommunityDismissReport=syCommunityDismissReport;

const syOldCommunityRender=syCommunityRender;
syCommunityRender=function(){syOldCommunityRender();setTimeout(syCommunityApplyPermissions,30)}
window.syCommunityRender=syCommunityRender;
