
window.SACRED_YEAR_CONFIG = {
  firebase: {
    apiKey: "AIzaSyDroTeBmwj5tUrdJjj2cFGSIGGxLdp_Mfw",
    authDomain: "sacred-year.firebaseapp.com",
    projectId: "sacred-year",
    storageBucket: "sacred-year.firebasestorage.app",
    messagingSenderId: "79563822400",
    appId: "1:79563822400:web:2bca44f44e322e0c14d6a5"
  },
  backend: "firebase"
};
