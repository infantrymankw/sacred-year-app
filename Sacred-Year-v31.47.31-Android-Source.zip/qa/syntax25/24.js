
/* v30 — route every major doorway to the newest implementation */
function sy30NormalizeText(s){return (s||"").replace(/\s+/g," ").trim().toLowerCase();}

function sy30RouteButton(btn){
 // Dynamic panels already bind their own actions; do not replace filters or form submits by their labels.
 if(btn.closest("#sheet, [role=dialog]"))return;
 const t=sy30NormalizeText(btn.textContent);
 if(!t)return;

 if((t==="library" || t.includes("sacred library") || t.includes("read • search • study")) && window.sy27Library){
   btn.onclick=sy27Library;
 }
 else if((t.includes("ritual hall") || t==="everyday practice") && window.sy28RitualHall){
   btn.onclick=sy28RitualHall;
 }
 else if((t.includes("gods & goddesses") || t.includes("gods and goddesses") || t==="the gods") && window.sy24GodsStudy){
   btn.onclick=sy24GodsStudy;
 }
 else if((t==="rune circle" || t.includes("study the futhark") || t==="runes") && window.sy25RuneStudy){
   btn.onclick=sy25RuneStudy;
 }
 else if((t.includes("sacred calendar") || t==="holidays" || t.includes("holidays & the sacred year")) && window.sy26HolidayStudy){
   btn.onclick=sy26HolidayStudy;
 }
 else if((t==="start here" || t.includes("new to norse paganism")) && window.sy23StartHere){
   btn.onclick=sy23StartHere;
 }
 else if((t.includes("community hall") || t==="community") && window.syOpenCommunityHall){
   btn.onclick=syOpenCommunityHall;
 }
 else if((t.includes("public events") || t==="events") && window.syOpenEvents){
   btn.onclick=syOpenEvents;
 }
 else if((t.includes("cosmology") || t.includes("nine worlds")) && window.syOpenHallSection){
   btn.onclick=()=>syOpenHallSection("worlds");
 }
 else if((t==="hall+" || t.includes("keep the hall burning")) && window.syOpenHallPlus){
   btn.onclick=syOpenHallPlus;
 }
}

function sy30DedupeContainer(container){
 const seen=new Set();
 [...container.children].forEach(el=>{
   if(!(el.matches?.("button,.section-card,.sy29-action,.bookpick")))return;
   const key=sy30NormalizeText(el.querySelector("h4,h3,b")?.textContent || el.textContent).slice(0,80);
   if(!key)return;
   if(seen.has(key))el.classList.add("v30-hidden");
   else seen.add(key);
 });
}

function sy30QualityPass(){
 document.querySelectorAll("button,.section-card,.sy29-action").forEach(sy30RouteButton);

 document.querySelectorAll(".section-nav,.sy29-actions,.library-books").forEach(sy30DedupeContainer);

 // Remove obvious legacy demo/setup notices that no longer belong in the mature UI.
 [...document.querySelectorAll("p,.note,.holiday,.card")].forEach(el=>{
   const t=sy30NormalizeText(el.textContent);
   if(t.includes("local demo mode") ||
      t.includes("add your supabase project url") ||
      t.includes("config.js to turn on real cloud accounts")){
      el.classList.add("v30-hidden");
   }
 });

 // Keep repeated old feature cards out of Today if the polished v29 doorway exists.
 const today=document.getElementById("today");
 if(today && document.getElementById("sy29TodayHero")){
   const more=today.querySelector(".sy29-more");
   if(more){
     const cards=[...more.querySelectorAll(".section-card")];
     const preferred=new Map();
     for(const c of cards){
       const text=sy30NormalizeText(c.querySelector("h4")?.textContent||c.textContent);
       const base=text.replace(/\b(study|circle|hall|sacred|the)\b/g,"").replace(/\s+/g," ").trim();
       if(preferred.has(base) && base.length>3)c.classList.add("v30-hidden");
       else preferred.set(base,c);
     }
   }
 }

 // Standardize bottom navigation readability.
 document.querySelectorAll("nav button,.bottom-nav button,.tabbar button").forEach(b=>{
   b.style.color = "";
 });

 syLocalStorage.setItem("sy_v30_quality_pass","1");
}
window.sy30QualityPass=sy30QualityPass;

setTimeout(sy30QualityPass,1200);

/* Re-run after opening drawers because many sections are dynamically rendered. */
const sy30OldOpenDrawer=window.openDrawer;
if(typeof sy30OldOpenDrawer==="function"){
 window.openDrawer=function(content){
   const r=sy30OldOpenDrawer(content);
   setTimeout(sy30QualityPass,60);
   return r;
 };
}
