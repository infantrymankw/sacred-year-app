
function syRefreshSavedCards(){
 const read=k=>{try{return JSON.parse(syLocalStorage.getItem(k)||'null')}catch(e){return null}};
 const r=read('sy_saved_rune'),b=read('sy_reader_bookmark');
 const rt=document.getElementById('savedRuneText'),bt=document.getElementById('savedReadingText');
 if(rt)rt.textContent=r?[r[0],r[1],r[2]].filter(Boolean).join(' — '):'None saved.';
 if(bt)bt.textContent=b?(b.title||b.work)+' bookmark saved.':'No bookmark.';
}
window.addEventListener('DOMContentLoaded',syRefreshSavedCards);
window.addEventListener('storage',syRefreshSavedCards);
document.addEventListener('click',()=>setTimeout(syRefreshSavedCards,0));
