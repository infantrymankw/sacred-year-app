
(function(){
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const uid=()=>window.syStorageUID?.()||null;
 const db=()=>window.sySupabase;
 let activity=[],activityUID=null,loading=null,lastError='',generation=0;
 const pendingPost=r=>r.status==='pending'||(r.is_hidden==null&&!r.status);
 window.sy25PendingPost=pendingPost;
 function paint(){
  let button=document.getElementById('sy25ActivityButton');
  if(!button){button=document.createElement('button');button.id='sy25ActivityButton';button.className='btn secondary';button.style.cssText='margin:8px 12px;min-height:44px';button.onclick=window.sy25Activity;document.querySelector('header')?.appendChild(button);if(!button.isConnected)document.body.prepend(button);}
  const total=activity.reduce((n,x)=>n+(x.count||1),0);
  button.hidden=!uid();button.textContent='Activity'+(total?' ('+total+')':'');
  button.setAttribute('aria-label',total+' pending items and unread questions');
  for(const id of ['sy324AudioCard','sy346CreatorAudio']){
   const card=document.getElementById(id);if(card){const p=card.querySelector('p');if(p)p.textContent=(activity.find(x=>x.kind==='audio')?.count||0)+' pending recordings · Review Hall+ submissions';card.onclick=()=>window.syOpenCreatorAudioManager();}
  }
  const grid=document.querySelector('#sheetContent .sy321-grid');
  if(grid&&document.getElementById('sy324AudioCard')&&!document.getElementById('sy25PostQueue')){
   const b=document.createElement('button');b.id='sy25PostQueue';b.className='sy321-card';b.onclick=window.sy25PendingPosts;grid.appendChild(b);
  }
  const post=document.getElementById('sy25PostQueue');if(post)post.innerHTML='<div class="kicker">Community</div><h4>Pending posts</h4><p>'+(activity.find(x=>x.kind==='posts')?.count||0)+' posts awaiting review</p>';
 }
 async function checked(q){const r=await q;if(r.error)throw r.error;return r.data||[];}
 window.sy25RefreshActivity=async function(){
 const syAccountScope=window.sy25Scope();

  const current=uid();if(!current||!db())return;
  if(loading)return loading;
  const token=generation,store=syLocalStorage.forUser(current);
  loading=(async()=>{
   try{
    const profile=await checked(db().from('profiles').select('role').eq('id',current));
    const items=[];
    if(profile[0]?.role==='creator'){
     const [recordings,posts]=await Promise.all([
      checked(db().from('audio_hall_recordings').select('id,upload_complete').eq('status','pending')),
      checked(db().from('community_posts').select('id,status,is_hidden'))
     ]);
     const ready=recordings.filter(r=>r.upload_complete!==false),pending=posts.filter(pendingPost);
     if(ready.length)items.push({kind:'audio',id:'pending-audio',count:ready.length,title:ready.length+' Hall+ recording'+(ready.length===1?'':'s')+' awaiting review'});
     if(pending.length)items.push({kind:'posts',id:'pending-posts',count:pending.length,title:pending.length+' Community post'+(pending.length===1?'':'s')+' awaiting review'});
    }
    const prefs=await checked(db().from('user_preferences').select('*').eq('user_id',current));
    // Account-wide activity: creator announcements, community replies, moderation outcomes,
    // and recording questions all share the same Activity surface. While the app is open Android also receives a native alert. Closed-app push is currently supported by the server for Creator posts only.
    const creatorPosts=await checked(db().from('creator_posts').select('id,title,message,label,published_at').eq('status','published'));
    const hallSeen=store.getItem('sy_last_seen_post')||'';
    for(const p of creatorPosts.filter(p=>!hallSeen||Date.parse(p.published_at)>Date.parse(hallSeen)).sort((a,b)=>Date.parse(b.published_at)-Date.parse(a.published_at)).slice(0,20))
      items.push({kind:'creator_post',id:p.id,title:p.title||'Words from the Hall',body:p.message||'',published_at:p.published_at});
    const myPosts=await checked(db().from('community_posts').select('id,title').eq('user_id',current));
    const replySeen=new Set(JSON.parse(store.getItem('community_reply_read_ids')||'[]'));
    for(const post of myPosts.slice(0,50)){
      const replies=await checked(db().from('community_replies').select('id,post_id,user_id,body,created_at').eq('post_id',post.id));
      for(const r of replies)if(r.user_id!==current&&!replySeen.has(r.id))items.push({kind:'community_reply',id:r.id,post:post.id,title:'New reply on '+(post.title||'your Community Hall post'),body:r.body||''});
    }
    const seen=new Set(prefs[0]?.audio_question_read_ids||JSON.parse(store.getItem('audio_question_read_ids')||'[]'));
    const own=await checked(db().from('audio_hall_recordings').select('*').eq('author_id',current));
    // Read only comments belonging to this account's published recordings.
    for(const recording of own.filter(r=>r.status==='published'&&r.notify_questions===true)){
     const comments=await checked(db().from('audio_hall_comments').select('*').eq('recording_id',recording.id).eq('status','visible'));
     for(const q of comments)if(q.is_question===true&&q.notify_owner!==false&&q.author_id!==current&&!seen.has(q.id))items.push({kind:'question',id:q.id,recording:recording.id,title:'Question on '+recording.title,body:q.body});
    }
    if(uid()!==current||token!==generation)return;
    activity=items;activityUID=current;lastError='';paint();
    const nativeSeen=new Set(JSON.parse(store.getItem('activity_native_seen')||'[]'));
    const alertItem=items.find(x=>['creator_post','community_reply','question'].includes(x.kind)&&!nativeSeen.has(x.kind+':'+x.id));
    if(alertItem&&typeof window.syNativeShowNotification==='function'){
      try{
        await window.syNativeShowNotification(alertItem.kind+':'+alertItem.id,alertItem.title,alertItem.body||'Open Sacred Year to view this activity.');
        nativeSeen.add(alertItem.kind+':'+alertItem.id);
        store.setItem('activity_native_seen',JSON.stringify([...nativeSeen].slice(-500)));
      }catch(e){console.warn('Android alert will retry after the notification bridge is ready.',e?.message||e);}
    }
    const list=document.getElementById('sy25ActivityList');if(list)renderActivity(list);
   }catch(e){if(uid()===current){lastError=e.message||String(e);const list=document.getElementById('sy25ActivityList');if(list)renderActivity(list);}}
  })();
  try{await window.sy25Await((window.sy25Assert(syAccountScope), (loading)),syAccountScope);}finally{loading=null;}
 };
 function renderActivity(list){
  list.innerHTML=(lastError?'<p role="status">Could not refresh activity: '+esc(lastError)+'</p>':'')+(activity.map((item,i)=>'<div class="release-card"><h4>'+esc(item.title)+'</h4>'+(item.body?'<p>'+esc(item.body)+'</p>':'')+'<button class="btn secondary" data-activity="'+i+'">Open</button></div>').join('')||'<p>No pending or unread activity.</p>');
  list.querySelectorAll('[data-activity]').forEach(b=>b.onclick=()=>openActivity(activity[Number(b.dataset.activity)]));
 }
 async function openActivity(item){
  if(!item||uid()!==activityUID)return;
  if(item.kind==='audio')return window.syOpenCreatorAudioManager();
  if(item.kind==='posts')return window.sy25PendingPosts();
  const current=uid(),store=syLocalStorage.forUser(current);
  if(item.kind==='creator_post'){store.setItem('sy_last_seen_post',item.published_at||new Date().toISOString());syLastSeen=item.published_at||new Date().toISOString();await window.sy25RefreshActivity();return window.syOpenNotifications();}
  if(item.kind==='community_reply'){const read=new Set(JSON.parse(store.getItem('community_reply_read_ids')||'[]'));read.add(item.id);store.setItem('community_reply_read_ids',JSON.stringify([...read].slice(-1000)));await window.sy25RefreshActivity();closeDrawer();showView('community');setTimeout(()=>window.syCommunityOpenThread?.(item.post),50);return;}
  await window.sy346OpenRecording(item.recording);
  if(uid()!==current)return;
  const target=document.getElementById('sy25-question-'+item.id);if(!target)return;
  target.scrollIntoView({block:'center',behavior:'smooth'});target.style.outline='2px solid var(--gold)';
  const prefs=await checked(db().from('user_preferences').select('*').eq('user_id',current));
  if(uid()!==current)return;
  const read=[...new Set([...(prefs[0]?.audio_question_read_ids||[]),item.id])].slice(-1000);
  const result=await db().from('user_preferences').upsert({user_id:current,audio_question_read_ids:read});
  if(result.error){alert('Question opened, but its read status could not sync.');return;}
  syLocalStorage.forUser(current).setItem('audio_question_read_ids',JSON.stringify(read));
  await window.sy25RefreshActivity();
 }
 window.sy25Activity=async()=>{
 const syAccountScope=window.sy25Scope();
openDrawer('<div class="kicker">Your account</div><h3>Activity</h3><p class="note">Announcements, Community Hall replies, pending moderation, and recording questions refresh while Sacred Year is open. Open an item to mark it read.</p><div id="sy25ActivityList"></div>');renderActivity(document.getElementById('sy25ActivityList'));await window.sy25Await((window.sy25Assert(syAccountScope), (window.sy25RefreshActivity())),syAccountScope);};
 window.sy25PendingPosts=async function(){
 const syAccountScope=window.sy25Scope();

  try{
   const current=uid(),profile=await window.sy25Await((window.sy25Assert(syAccountScope), (checked(db().from('profiles').select('role').eq('id',current)))),syAccountScope);if(profile[0]?.role!=='creator')throw new Error('Creator access is required.');
   const rows=(await window.sy25Await((window.sy25Assert(syAccountScope), (checked(db().from('community_posts').select('*')))),syAccountScope)).filter(pendingPost);
   if(uid()!==current)return;
   openDrawer('<div class="kicker">Creator moderation</div><h3>Pending Community posts ('+rows.length+')</h3><p>Older posts missing a visibility field remain here until reviewed. Their original text and dates are preserved.</p>'+rows.map((r,i)=>'<div class="release-card"><h4>'+esc(r.title||'Community post')+'</h4><p>'+esc(r.body)+'</p><p>'+esc(syDisplayDate(r.created_at))+'</p><button class="btn" data-approve="'+i+'">Approve and show publicly</button><button class="btn secondary" data-reject="'+i+'">Reject</button></div>').join(''));
   for(const [attr,status] of [['data-approve','published'],['data-reject','rejected']])document.querySelectorAll('['+attr+']').forEach(button=>button.onclick=async()=>{
    button.disabled=true;const r=rows[Number(button.getAttribute(attr))];
    const result=await db().from('community_posts').update({is_hidden:status!=='published',status,moderated_at:new Date().toISOString()}).eq('id',r.id);
    if(result.error){button.disabled=false;alert(result.error.message);return;}await window.sy25PendingPosts();await window.sy25RefreshActivity();
   });
  }catch(e){alert(e.message||String(e));}
 };
 // Back keeps actual DOM nodes and their event handlers; no stale HTML reconstruction.
 const views=[],drawers=[];
 let restoring=false;
 const open=window.openDrawer,close=window.closeDrawer,view=window.showView;
 window.openDrawer=function(html){
  const content=document.getElementById('sheetContent'),drawer=document.getElementById('drawer');
  if(!restoring&&drawer?.classList.contains('open')&&content?.childNodes.length){
   const fragment=document.createDocumentFragment();while(content.firstChild)fragment.appendChild(content.firstChild);
   drawers.push({fragment,scroll:document.getElementById('sheet').scrollTop,uid:uid()});if(drawers.length>25)drawers.shift();
  }
  return open.apply(this,arguments);
 };
 window.closeDrawer=function(){drawers.length=0;return close.apply(this,arguments);};
 window.showView=function(id){const old=document.querySelector('.view.active')?.id;if(!restoring&&old&&old!==id)views.push(old);return view.apply(this,arguments);};
 window.sy25Back=function(){
  if(document.getElementById('syBrandDialog')?.classList.contains('open')){document.getElementById('syBrandDialogOk')?.click();return true;}
  const manager=document.getElementById('syCreatorAudioManager');if(manager&&!manager.hidden){window.syCloseCreatorAudioManager();return true;}
  for(const [id,fn] of [['sy315Delete','sy315CloseDelete'],['sy313','sy313Close']])if(document.getElementById(id)?.classList.contains('open')){window[fn]?.();return true;}
  if(document.getElementById('drawer')?.classList.contains('open')){
   const edit=document.querySelector('#sheetContent input:not([type=checkbox]),#sheetContent textarea');
   if(edit&&(edit.value!==edit.defaultValue)&&!confirm('Leave this screen? Unsaved changes will be lost.'))return true;
   document.querySelectorAll('#sheetContent audio').forEach(a=>a.pause());
   const previous=drawers.pop();
   if(previous&&previous.uid===uid()){const content=document.getElementById('sheetContent');content.replaceChildren(previous.fragment);document.getElementById('sheet').scrollTop=previous.scroll;}
   else window.closeDrawer();return true;
  }
  const prior=views.pop();if(prior){restoring=true;try{window.showView(prior);}finally{restoring=false;}return true;}
  return false;
 };
 function nativeBack(){const app=window.Capacitor?.Plugins?.App;if(window.Capacitor?.isNativePlatform?.()&&app)app.addListener('backButton',({canGoBack})=>{if(window.sy25Back())return;if(canGoBack)history.back();else app.minimizeApp();});}
 let attached=false;
 function attach(){
  if(attached||!db())return;attached=true;
  db().auth.onAuthStateChange(()=>{
   generation++;window.sy25ResetRecording?.();window.sy319RsvpSet=new Set();if(typeof syLastSeen!=='undefined')syLastSeen=syLocalStorage.getItem('sy_last_seen_post')||'';activity=[];activityUID=null;lastError='';drawers.length=0;views.length=0;
   window.closeDrawer();window.syCloseCreatorAudioManager?.();window.sy313Close?.();window.sy315CloseDelete?.();
   document.getElementById('sheetContent')?.replaceChildren();
   document.getElementById('syCreatorAudioList')?.replaceChildren();
   window.syRefreshSavedCards?.();if(typeof updateContinueReading==='function')updateContinueReading();
   paint();setTimeout(()=>window.sy25RefreshActivity(),500);
  });
 }
 window.addEventListener('DOMContentLoaded',()=>{nativeBack();attach();paint();});
 window.addEventListener('sy-native-notifications-ready',()=>window.sy25RefreshActivity());
 const attachTimer=setInterval(()=>{attach();if(attached)clearInterval(attachTimer);},500);
 setInterval(()=>{if(!document.hidden)window.sy25RefreshActivity();},30000);
 document.addEventListener('visibilitychange',()=>{if(!document.hidden)window.sy25RefreshActivity();});
 document.addEventListener('click',()=>setTimeout(paint,100));
})();

