
const SY_SYNODIC=29.530588853;
const SY_LUNAR_EPOCH=Date.UTC(2000,0,6,18,14,0); // reference new moon, UTC
const SY_DAY=86400000;
const SY_PHASES=[
 {name:"New Moon",glyph:"🌑",at:0,practice:"A modern time for stillness, planning, beginning a journal entry, or setting a modest intention for the coming cycle."},
 {name:"Waxing Crescent",glyph:"🌒",at:.125,practice:"A modern time for beginning work: choose one action that supports an intention rather than relying on the Moon itself to produce an outcome."},
 {name:"First Quarter",glyph:"🌓",at:.25,practice:"A modern checkpoint for courage and action. Review what you began and decide what requires effort or correction."},
 {name:"Waxing Gibbous",glyph:"🌔",at:.375,practice:"A modern time for refinement. Strengthen work already underway, prepare offerings or study, and finish what can be finished."},
 {name:"Full Moon",glyph:"🌕",at:.5,practice:"A modern devotional opportunity for gratitude, gathering, reflection, or an outdoor observance where safe and appropriate."},
 {name:"Waning Gibbous",glyph:"🌖",at:.625,practice:"A modern time for gratitude and sharing. Record what you learned and consider what can be given back to household, community, or land."},
 {name:"Last Quarter",glyph:"🌗",at:.75,practice:"A modern time for review and release. Correct habits, clean ritual or household space, and decide what no longer deserves your effort."},
 {name:"Waning Crescent",glyph:"🌘",at:.875,practice:"A modern time for rest, ancestor remembrance, quiet study, and preparing for the next cycle."}
];
function syMoonData(now=new Date()){
 let days=(now.getTime()-SY_LUNAR_EPOCH)/SY_DAY;
 let age=((days%SY_SYNODIC)+SY_SYNODIC)%SY_SYNODIC;
 let f=age/SY_SYNODIC;
 let illum=(1-Math.cos(2*Math.PI*f))/2;
 let idx=Math.floor((f+1/16)*8)%8;
 return {age,f,illum,phase:SY_PHASES[idx]};
}
function syNextMoonFraction(target,now=new Date()){
 const m=syMoonData(now);
 let delta=(target-m.f+1)%1;
 if(delta<0.0005) delta=1;
 return new Date(now.getTime()+delta*SY_SYNODIC*SY_DAY);
}
function syMoonCountdown(d){
 const ms=d-new Date(), days=Math.floor(ms/SY_DAY), hours=Math.floor((ms%SY_DAY)/3600000);
 return days>0?`${days} days, ${hours} hours away`:`${Math.max(0,hours)} hours away`;
}
function syRenderMoon(){
 const m=syMoonData(), n=syNextMoonFraction(0), f=syNextMoonFraction(.5);
 document.getElementById("moonPhaseTitle").textContent=m.phase.name;
 document.getElementById("moonGlyph").textContent=m.phase.glyph;
 document.getElementById("moonSummary").textContent=`${Math.round(m.illum*100)}% illuminated • approximately day ${m.age.toFixed(1)} of the lunar cycle`;
 document.getElementById("moonIllumination").textContent=`${Math.round(m.illum*100)}%`;
 document.getElementById("moonAge").textContent=`${m.age.toFixed(1)} days`;
 document.getElementById("nextNewMoon").textContent=n.toLocaleDateString(undefined,{month:"short",day:"numeric"});
 document.getElementById("nextFullMoon").textContent=f.toLocaleDateString(undefined,{month:"short",day:"numeric"});
 document.getElementById("nextNewCountdown").textContent=syMoonCountdown(n);
 document.getElementById("nextFullCountdown").textContent=syMoonCountdown(f);
 document.getElementById("moonPractice").innerHTML=`<div class="kicker">Modern practice</div><h4>${m.phase.glyph} ${m.phase.name}</h4><p>${m.phase.practice}</p><button class="btn secondary" onclick="syMoonJournal('${m.phase.name}')">Reflect on this phase</button>`;
 document.getElementById("moonPhaseWheel").innerHTML=SY_PHASES.map(x=>`<div class="section-card" style="${x.name===m.phase.name?'outline:1px solid var(--gold)':''}"><div style="font-size:30px">${x.glyph}</div><h4>${x.name}</h4><p>${Math.round(x.at*SY_SYNODIC)} day point</p></div>`).join("");
}
function syMoonJournal(phase){
 openDrawer(`<div class="kicker">Moon Reflection</div><h3>${phase}</h3><p class="note">This is a personal journal prompt, not a historical divination claim.</p><label>What are you noticing in your life or practice right now?</label><textarea id="syMoonNote" rows="7" placeholder="Write your reflection…"></textarea><button class="btn" onclick="sySaveMoonNote('${phase}')">Save reflection</button>`);
}
function sySaveMoonNote(phase){
 const note=document.getElementById("syMoonNote").value.trim();if(!note)return;
 const a=JSON.parse(syLocalStorage.getItem("sy_moon_journal")||"[]");
 a.unshift({phase,note,saved_at:new Date().toISOString()});
 syLocalStorage.setItem("sy_moon_journal",JSON.stringify(a.slice(0,100)));
 closeDrawer();alert("Moon reflection saved on this device.");
}
async function syMoonReminderSettings(){
 if(typeof syOpenNotificationSettings==="function")return syOpenNotificationSettings();
 if(typeof syDirectPrefs==="function")return syDirectPrefs();
 openDrawer(`<div class="kicker">Moon Reminders</div><h3>Notification settings</h3><p>Sign in to your Sacred Year account to sync moon reminder preferences.</p><button class="btn" onclick="closeDrawer();openAccount()">Open account</button>`);
}
window.syMoonReminderSettings=syMoonReminderSettings;
window.syMoonJournal=syMoonJournal;
window.sySaveMoonNote=sySaveMoonNote;
syRenderMoon();
setInterval(syRenderMoon,3600000);
