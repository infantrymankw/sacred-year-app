
const SY_HOLIDAYS=[
 {name:"Autumn Equinox / Harvest Reflection","month":9,"day":22,"season":2,"label":"Astronomy / modern pagan observance","kind":"modern","summary":"The September equinox begins astronomical autumn in the Northern Hemisphere and spring in the Southern Hemisphere. Day and night are approximately, not exactly, equal. A harvest reflection here is a modern practice. Some modern pagans call this observance Mabon; that festival name is a modern application of the name of a figure in Welsh mythology, not an attested ancient pan-Celtic or Norse equinox festival.","practice":"Give thanks for what has ripened, share food, review the year’s work, and prepare for the changing light.","ritual":["Notice local seasonal changes.","Name what you have learned or gathered this year.","Share food or help someone in your community.","Choose what to carry forward and what to set aside."],"source":"U.S. Naval Observatory astronomical seasons; modern pagan autumn-equinox practice. Mabon as an equinox festival name is modern.","whyDate":"The September equinox varies by year and time zone; it is not fixed to September 21. The calendar shows the event in your device’s local time zone. Seasonal labels here use the Northern Hemisphere; seasons reverse in the south."},
 {name:"Dísablót / Disting / Imbolc",month:2,day:14,label:"Norse / Germanic and Gaelic seasonal traditions",kind:"attested",summary:"Dísablót honors the dísir in Scandinavian tradition; its historical timing varied. Gaelic Imbolc, associated with the beginning of spring and later St Brigid’s Day, falls on February 1. This shared seasonal entry offers space for protection, renewal and remembrance without equating the rites.",practice:"Honor female ancestors and protective powers with a modest household offering.",ritual:["Prepare a clean place and light a candle.","Name female ancestors or the dísir you wish to honor.","Offer bread, dairy, fruit, or a drink.","Speak gratitude and close respectfully."],source:"Old Norse saga and medieval Scandinavian evidence; exact dating varied. Gaelic seasonal context: National Museum of Ireland, The Year in Ireland.",whyDate:"Imbolc: February 1. Dísablót / Disting: February 14 is this app’s modern placement; historical timing varied."},
 {name:"Sigrblót",month:4,day:15,label:"Historically attested",kind:"attested",summary:"A spring sacrifice associated in saga literature with victory and the opening of the active season.",practice:"Focus on courage, right action, and work you are beginning.",ritual:["State the work or challenge before you.","Honor the powers you associate with courage and victory.","Give a modest offering.","Make one realistic commitment for the season."],source:"Ynglinga saga and related Old Norse material; fixed modern date is approximate.",whyDate:"Sigrblót is associated with the beginning of summer in Old Norse seasonal reckoning. April 15 is an approximate modern placement, not a universally attested historical date."},
 {name:"Spring Equinox / Eostre / Ostara","month":3,"day":20,"season":0,"label":"Astronomy / Anglo-Saxon evidence / modern practice","kind":"modern","summary":"The March equinox begins astronomical spring in the Northern Hemisphere (autumn in the Southern Hemisphere). Many modern pagans celebrate it as Ostara. Bede records an Anglo-Saxon month named for Ēostre, corresponding roughly to April, but gives no fixed equinox festival date or detailed rite. Grouping them here is a modern seasonal choice, not evidence of one universal ancient festival.","practice":"Notice new growth, greet the dawn, plant something suitable for your climate, or reflect on renewal.","ritual":["Spend a few moments outdoors noticing the season.","Light a candle for renewal if meaningful to you.","Name something you want to nurture.","Choose one practical act of care for the coming season."],"source":"Bede, De temporum ratione, chapter 15; astronomical timing: U.S. Naval Observatory. Equinox-based Ostara rites are modern.","whyDate":"The equinox is an astronomical instant that changes with the year; its calendar date depends on your time zone. Ēostre’s month in Bede is not proof of a March equinox festival. The date here follows the astronomical event for modern planning."},
 {name:"Walpurgisnacht / Beltane (Bealtaine)",month:4,day:30,label:"Norse / Germanic and Gaelic seasonal traditions",kind:"modern",summary:"Walpurgisnacht belongs to later Central and Northern European spring folklore on April 30. Gaelic Bealtaine welcomes summer on May 1, with traditions of protection for households and livestock. This combined entry celebrates the seasonal threshold while keeping both backgrounds clear.",practice:"Use it as a regional folklore study or spring protection/renewal observance.",ritual:["Light a safe candle or outdoor fire where lawful.","Clean and bless the household in your own words.","Remember local land and seasonal traditions.","Close with food, music, or family gathering."],source:"Later Germanic and European folklore; not one universal pre-Christian rite. Gaelic seasonal context: National Museum of Ireland, The Year in Ireland.",whyDate:"Walpurgisnacht: April 30 night. Beltane / Bealtaine: May 1, often beginning on its eve."},
 {name:"Summer Solstice / Midsummer","month":6,"day":21,"season":1,"label":"Astronomy / regional traditions / modern practice","kind":"recon","summary":"The June solstice brings the Northern Hemisphere’s longest day and begins astronomical summer; it is the winter solstice in the Southern Hemisphere. Nordic and other European Midsummer traditions have varied dates and histories. A universal Viking-age solstice blót identical to modern practice is not established by the surviving evidence.","practice":"Gather outdoors, share seasonal food, honor the land, and celebrate summer light in ways appropriate to your climate.","ritual":["Spend time outdoors safely.","Thank the land and the people who sustain your household.","Offer seasonal food or drink if meaningful.","Share a meal and choose an act of care for the land."],"source":"Regional Scandinavian Midsummer customs; U.S. Naval Observatory astronomical seasons. Later customs are not automatically unchanged pre-Christian rites.","whyDate":"This entry follows the year’s June solstice in your device time zone. Regional Midsummer customs may fall on nearby dates, including celebrations connected with St John’s Day, rather than the precise astronomical instant."},
 {name:"First Harvest / Freyfaxi / Lughnasadh (Lúnasa)",month:8,day:1,label:"Norse / Germanic and Gaelic seasonal traditions",kind:"modern",summary:"Freyfaxi is a modern Heathen first-harvest observance drawing on Freyr and harvest themes. Gaelic Lughnasadh / Lúnasa marks the harvest season on August 1. Both are included here as distinct traditions of seasonal gratitude, gathering and sharing food.",practice:"Give thanks for what is beginning to ripen and offer first fruits or bread.",ritual:["Set out bread, grain, fruit, or honey.","Thank the land and those whose work sustains you.","If you honor Freyr, address him respectfully.","Share the remaining food rather than wasting it."],source:"Freyfaxi as a fixed holiday is modern; harvest and Freyr associations draw on historical material. Gaelic seasonal context: National Museum of Ireland, The Year in Ireland.",whyDate:"August 1: Gaelic Lughnasadh / Lúnasa and this app’s modern Freyfaxi marker. The shared date does not make them the same historical festival."},
 {name:"Winter Nights / Vetrnætr / Samhain",month:10,day:15,label:"Norse / Germanic and Gaelic seasonal traditions",kind:"recon",summary:"Vetrnætr marks winter’s opening in Old Norse tradition. Samhain marks winter’s beginning in Gaelic tradition, observed from October 31 into November 1. Both invite seasonal preparation and remembrance; they are distinct traditions grouped here for study.",practice:"Prepare the household for the dark season and remember ancestors.",ritual:["Tidy the home and prepare a meal.","Light a candle for the beginning of winter.","Remember ancestors by name.","Discuss what your household wants to preserve through winter."],source:"Vetrnætr is attested; modern unified ritual forms are reconstructed. Gaelic seasonal context: National Museum of Ireland, The Year in Ireland.",whyDate:"Vetrnætr: October 15 is this app’s approximate modern marker. Samhain: October 31–November 1. These are separate dates within one seasonal entry."},
 {name:"Álfablót",month:11,day:7,label:"Historically attested",kind:"attested",summary:"A private autumn rite associated with the álfar in Scandinavian sources.",practice:"Keep it household-centered and acknowledge that the surviving evidence is limited.",ritual:["Prepare a quiet household space.","Offer food or drink modestly.","Honor the álfar or local sacred powers as you understand them.","Close without forcing signs or supernatural interpretations."],source:"Referenced in skaldic/saga material; details are sparse.",whyDate:"The surviving evidence places Álfablót in the autumn/winter seasonal context but does not preserve one universal Gregorian date. November 7 is Sacred Year’s practical modern placement."},
 {name:"Wild Hunt Season",month:12,day:1,label:"Folklore / modern observance",kind:"modern",summary:"Winter folklore surrounding spectral processions, storms, the dead, and Woden/Odin in some regional traditions.",practice:"Study your regional lore, remember the dead, and practice winter hospitality.",ritual:["Dim the room and light one candle.","Read or reflect on Wild Hunt folklore.","Remember the dead and difficult journeys of those before you.","Offer bread, oats, apple, or drink safely.","Ask for wisdom and safe passage through the dark season."],source:"Regional medieval and later folklore; leaders and details vary substantially.",whyDate:"There is no single historical start date for a universal Wild Hunt season. December 1 is used here as a modern marker for the winter folklore cycle."},
 {name:"Winter Solstice / Yule / Jól","month":12,"day":21,"season":3,"label":"Astronomy / attested Yule / modern placement","kind":"attested","summary":"The December solstice is the Northern Hemisphere’s shortest day and begins astronomical winter; it is the summer solstice in the Southern Hemisphere. Jól is an attested Scandinavian midwinter feast associated with drinking, hospitality and sacred observance. Its historical timing followed older calendars and changed over time. Observing Yule at the exact solstice is a modern choice, not a universal ancient date.","practice":"Feast, offer hospitality, remember loved ones, and reflect on the returning light where this matches your season.","ritual":["Clean the hearth or gathering space.","Light a safe candle or fire if meaningful.","Honor gods, ancestors or household bonds according to your tradition.","Share food, a memory and a hope for the coming year.","Close with thanks."],"source":"Haraldskvæði; Hákonar saga góða and related Old Norse evidence for Jól; U.S. Naval Observatory for the solstice.","whyDate":"The calendar now follows the actual December solstice date for this combined modern entry. Historical Jól cannot be reduced to December 20, December 21 or one universally fixed solstice celebration."},
 {name:"Mōdraniht / Mothers' Night",month:12,day:24,label:"Historically attested name",kind:"attested",summary:"Bede records Mōdraniht, 'Mothers' Night,' among the pre-Christian Anglo-Saxons at the opening of their year.",practice:"Honor mothers, female ancestors, and family continuity.",ritual:["Set out a candle and family photograph or heirloom.","Name mothers and female ancestors you honor.","Offer food, flowers, or drink.","Share family memories and gratitude."],source:"Bede, De temporum ratione; ritual details are not preserved, so modern forms are reconstructed.",whyDate:"Bede says Mōdraniht was observed on the night the Anglo-Saxons began their year, corresponding to Christmas Eve in his calendar description. Sacred Year therefore uses December 24."}
];


// Meeus, Astronomical Algorithms, ch.27 (numerical tables 27.B/C).
// 2026 instants use USNO UTC values; other years use a planning approximation.
function sySeasonInstant(year,index){
 if(year===2026)return new Date(['2026-03-20T14:46:00Z','2026-06-21T08:24:00Z','2026-09-23T00:05:00Z','2026-12-21T20:50:00Z'][index]);
 const coefficients=[[2451623.80984,365242.37404,.05169,-.00411,-.00057],[2451716.56767,365241.62603,.00325,.00888,-.00030],[2451810.21715,365242.01767,-.11575,.00337,.00078],[2451900.05952,365242.74049,-.06223,-.00823,.00032]];
 const terms=[[485,324.96,1934.136],[203,337.23,32964.467],[199,342.08,20.186],[182,27.85,445267.112],[156,73.14,45036.886],[136,171.52,22518.443],[77,222.54,65928.934],[74,296.72,3034.906],[70,243.58,9037.513],[58,119.81,33718.147],[52,297.17,150.678],[50,21.02,2281.226],[45,247.54,29929.562],[44,325.15,31555.956],[29,60.93,4443.417],[18,155.12,67555.328],[17,288.79,4562.452],[16,198.04,62894.029],[14,199.76,31436.921],[12,95.39,14577.848],[12,287.11,31931.756],[12,320.81,34777.259],[9,227.73,1222.114],[8,15.45,16859.074]];
 const y=(year-2000)/1000,j0=coefficients[index].reduce((sum,c,i)=>sum+c*y**i,0),t=(j0-2451545)/36525,rad=Math.PI/180,w=(35999.373*t-2.47)*rad;
 const sum=terms.reduce((s,[a,b,c])=>s+a*Math.cos((b+c*t)*rad),0),jde=j0+.00001*sum/(1+.0334*Math.cos(w)+.0007*Math.cos(2*w));
 const u=year-2000,deltaT=year<2050?62.92+.32217*u+.005589*u*u:-20+32*((year-1820)/100)**2-.5628*(2150-year);
 return new Date((jde-2440587.5)*86400000-deltaT*1000);
}

function syCalendarDates(h){
 const dates=[{month:h.month,day:h.day}];
 if(h.name.includes('Samhain'))dates.push({month:10,day:31});
 if(h.name.includes('Imbolc'))dates.push({month:2,day:1});
 if(h.name.includes('Bealtaine'))dates.push({month:5,day:1});
 return dates;
}
function syNextDate(h){
 const now=new Date(),y=now.getFullYear(),today=new Date(y,now.getMonth(),now.getDate());
 if(Number.isInteger(h.season)){const event=sySeasonInstant(y,h.season);return event<today?sySeasonInstant(y+1,h.season):event;}
 return syCalendarDates(h).map(x=>{let d=new Date(y,x.month-1,x.day,9);if(d<today)d=new Date(y+1,x.month-1,x.day,9);return d}).sort((a,b)=>a-b)[0];
}
function syCalendarDateLabel(h){
 if(Number.isInteger(h.season)){const d=syNextDate(h);return (d.getUTCFullYear()===2026?"Astronomical event":"Approximate astronomical event")+" • "+d.toLocaleTimeString(undefined,{hour:"numeric",minute:"2-digit",timeZoneName:"short"})+" • Northern Hemisphere seasonal names";}
 if(h.name.includes('Samhain'))return 'Vetrnætr: October 15 (modern marker) • Samhain: October 31–November 1';
 if(h.name.includes('Imbolc'))return 'Imbolc: February 1 • Dísablót / Disting: February 14 (modern marker)';
 if(h.name.includes('Bealtaine'))return 'Walpurgisnacht: April 30 • Bealtaine: May 1';
 return '';
}

function syDays(d){const n=new Date();return Math.round((Date.UTC(d.getFullYear(),d.getMonth(),d.getDate())-Date.UTC(n.getFullYear(),n.getMonth(),n.getDate()))/86400000)}
function syHolidayTag(k){return k==="attested"?"attested":k==="recon"?"recon":"modern"}
function syRenderCalendar(){
 const full=document.getElementById("holidayListFull"),up=document.getElementById("holidayCountdowns");
 if(!full||!up)return;

 const sorted=[...SY_HOLIDAYS].sort((a,b)=>syNextDate(a)-syNextDate(b));

 // The next three observances appear only in Coming Up.
 const comingUp=sorted.slice(0,3);

 // The main Sacred Year list begins with the next observance after those three.
 // This prevents the same holidays from appearing twice on the screen.
 const sacredYear=sorted.slice(3);

 const card=h=>`<div class="holiday"><div class="kicker">${h.label}</div><h4>${h.name}</h4><div class="date">${syCalendarDateLabel(h)?syCalendarDateLabel(h)+"<br>Next: ":""}${syNextDate(h).toLocaleDateString(undefined,{month:"long",day:"numeric"})} • ${Math.max(0,syDays(syNextDate(h)))} days</div><p>${h.summary}</p><div class="tags"><span class="status ${syHolidayTag(h.kind)}">${h.label}</span></div><p><b>Practice:</b> ${h.practice}</p><button class="btn secondary" onclick="syOpenHoliday('${h.name.replaceAll("'","\\'")}')">Open guide</button><button class="btn secondary" style="margin-left:7px" onclick="syWhyDate('${h.name.replaceAll("'","\\'")}')">Why this date?</button><div class="mini-source">${h.source}</div></div>`;

 up.innerHTML=comingUp.map(card).join("");
 full.innerHTML=sacredYear.map(card).join("");
}
function syWhyDate(name){
 const h=SY_HOLIDAYS.find(x=>x.name===name);if(!h)return;
 openDrawer(`<div class="kicker">Calendar Notes</div><h3>Why ${h.name} is shown on this date</h3><p>${h.whyDate||"This is a practical modern calendar placement; historical timing may have varied."}</p><div class="item"><h4>Evidence label</h4><p>${h.label}</p></div><p class="note">${h.source}</p><button class="btn" onclick="sy323BackToMenu()">Close</button>`);
}
window.syWhyDate=syWhyDate;

function syOpenHoliday(name){
 const h=SY_HOLIDAYS.find(x=>x.name===name);if(!h)return;
 openDrawer(`<div class="kicker">${h.label}</div><h3>${h.name}</h3><p>${h.summary}</p><h4>Suggested modern household rite</h4><ol class="steps">${h.ritual.map(s=>`<li>${s}</li>`).join("")}</ol><p class="note">${h.source}</p><button class="btn" onclick="sy323BackToMenu()">Close</button>`);
}

const SY_HALL={
 gods:{title:"The Gods",body:`<div class="list">
 <div class="item"><h4>Týr / Tiw</h4><p>Law, oaths, courage, justice, and sacrifice. Tiwaz association is linguistically strong, while modern devotional practices vary.</p></div>
 <div class="item"><h4>Thor / Þórr / Donar</h4><p>Thunder, protection, consecration, strength, and the defense of gods and humans.</p></div>
 <div class="item"><h4>Odin / Óðinn / Wōden</h4><p>Wisdom, poetry, war, death, ecstasy, runes, and kingship. Regional traditions differ.</p></div>
 <div class="item"><h4>Frigg</h4><p>Foreknowledge, household authority, kinship, and queenship in surviving Norse material.</p></div>
 <div class="item"><h4>Freyja</h4><p>Love, desire, wealth, seiðr, death, and the slain; closely tied to the Vanir.</p></div>
 <div class="item"><h4>Freyr</h4><p>Peace, prosperity, fertility, good seasons, kingship, and abundance.</p></div>
 <div class="item"><h4>Njörðr</h4><p>Sea, wealth, ships, fishing, and prosperity.</p></div>
 <div class="item"><h4>Skaði</h4><p>Mountains, winter, skiing, hunting, and independence.</p></div></div>`},
 worlds:{title:"Cosmology & the Nine Worlds",body:`<p>The sources repeatedly speak of <b>nine worlds</b>, but they never hand us one neat canonical list. Sacred Year therefore uses a clearly labeled modern study reconstruction built from places actually named in the Eddic and prose traditions.</p><p class="note">Tap a realm to open its study page.</p><div class="section-nav">${["asgard","midgard","jotunheim","vanaheim","alfheim","svartalfheim","muspelheim","niflheim","hel"].map(id=>{const r=SY_REALMS[id];return `<button class="section-card realm-card" onclick="syOpenRealm('${id}')"><div class="realm-symbol">${r.icon}</div><h4>${r.name}</h4><p>${r.short}</p></button>`}).join("")}</div><div class="holiday" style="margin-top:12px"><div class="kicker">Evidence note</div><p>Names such as “Helheim” and some popular nine-world diagrams are modern conveniences. Sacred Year uses <b>Hel</b> where the Old Norse sources do, and treats Svartálfaheimr/Niðavellir cautiously because the source relationship between those names is debated.</p></div>`},
 wildhunt:{title:"The Wild Hunt",body:`<p>The Wild Hunt is a family of regional European winter traditions rather than one standardized ancient Norse myth. Woden/Odin leads the host in some Germanic traditions, while other regions name different leaders.</p><div class="item"><h4>Modern respectful observance</h4><p>Study regional folklore, remember the dead, practice winter hospitality, and avoid presenting later folklore as a single Viking-age doctrine.</p></div>`},
 ancestors:{title:"Ancestors",body:`<p>Ancestor remembrance fits strongly within broader Germanic evidence for kinship, burial, memorial customs, and cultic attention to the dead. Exact household rites vary.</p><div class="item"><h4>Simple household practice</h4><p>Keep photographs or heirlooms, speak names, share food in remembrance, care for graves when possible, and tell family stories.</p></div>`},
 rituals:{title:"Ritual Hall",body:`<div class="list"><div class="item"><h4>Blót</h4><p>A sacrificial/offerings rite. Modern practice commonly uses food or drink rather than attempting to reproduce every historical form.</p></div><div class="item"><h4>Sumbel</h4><p>A modern Heathen ceremonial drinking/toasting practice inspired by Germanic feast and oath traditions.</p></div><div class="item"><h4>Household Offering</h4><p>A simple modern format: prepare space, address the being(s) honored, give an offering, speak gratitude or request, and close clearly.</p></div></div>`},
 sources:{title:"Sources & Evidence",body:`<div class="list"><div class="item"><h4>Poetic Edda</h4><p>Primary poetic source for many Norse myths and Hávamál.</p></div><div class="item"><h4>Prose Edda</h4><p>Snorri Sturluson's major prose source for Norse myth and poetics.</p></div><div class="item"><h4>Bede</h4><p>Important for Anglo-Saxon month names including Eosturmonath and Mōdraniht.</p></div><div class="item"><h4>Tacitus, Germania</h4><p>Roman-era outsider account useful with caution.</p></div><div class="item"><h4>Sagas & archaeology</h4><p>Essential supporting evidence, but dates, genre, and later Christian-era composition must be considered.</p></div></div>`}
};
function syOpenHallSection(k){const s=SY_HALL[k];if(!s)return;openDrawer(`<div class="kicker">The Hall</div><h3>${s.title}</h3>${s.body}<button class="btn" onclick="sy323BackToMenu()">Close</button>`)}
window.syOpenHallSection=syOpenHallSection;

let syLastSeen=syLocalStorage.getItem("sy_last_seen_post")||"";
async function syFetchPosts(){
 const syAccountScope=window.sy25Scope();

 try{
   if(window.sySupabase){
     const {data}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("creator_posts").select("id,title,message,label,published_at").eq("status","published").order("published_at",{ascending:false}).limit(20))),syAccountScope);
     return data||[];
   }
 }catch(e){}
 return [];
}
async function syUpdateNotifications(){
 const syAccountScope=window.sy25Scope();

 const posts=await window.sy25Await((window.sy25Assert(syAccountScope), (syFetchPosts())),syAccountScope);
 const countEl=document.getElementById("notifCount");
 if(!posts.length){if(countEl)countEl.style.display="none";return}
 const unread=syLastSeen?posts.filter(p=>new Date(p.published_at)>new Date(syLastSeen)).length:posts.length;
 if(countEl){countEl.textContent=String(unread);countEl.style.display=unread?"block":"none";}
 if(unread&&typeof Notification!=="undefined"&&Notification.permission==="granted"&&document.visibilityState==="visible"){
   const p=posts[0]; new Notification(p.title||"Words from the Hall",{body:p.message});
 }
}
async function syOpenNotifications(){
 const syAccountScope=window.sy25Scope();

 const posts=await window.sy25Await((window.sy25Assert(syAccountScope), (syFetchPosts())),syAccountScope);
 openDrawer(`<div class="kicker">Notifications</div><h3>From the Hall</h3>
 <div class="row"><button class="btn secondary" onclick="syEnableNotifications()">Enable phone alerts</button></div>
 <div class="note-list">${posts.map((p,i)=>`<div class="note-card ${i===0?"unread":""}"><div class="kicker">${p.label||"Words from the Hall"}</div><h4>${p.title||"Words from the Hall"}</h4><p>${p.message}</p><div class="note">${syDisplayDate(p.published_at)}</div></div>`).join("")||'<p class="note">No notifications yet.</p>'}</div>
 <p class="note">Sacred Year can use phone/browser notifications on supported devices. For the most reliable phone experience, install Sacred Year to your home screen and allow notifications.</p>`);
 if(posts[0]){syLastSeen=posts[0].published_at;syLocalStorage.setItem("sy_last_seen_post",syLastSeen);const c=document.getElementById("notifCount");if(c)c.style.display="none";}
}
async function syEnableNotifications(){if(window.Capacitor?.isNativePlatform?.()){if(window.syNativeEnableNotifications)return window.syNativeEnableNotifications();alert('Android notifications are still loading. Close and reopen Sacred Year, then try again.');return;}
 if(!("Notification" in window)){alert("This browser does not support web notifications.");return}
 const p=await Notification.requestPermission();
 alert(p==="granted"?"Notifications are enabled on this device.":"Notification permission was not granted.");
}
window.syOpenNotifications=syOpenNotifications;
window.syEnableNotifications=syEnableNotifications;

syRenderCalendar();
setInterval(syUpdateNotifications,60000);
setTimeout(syUpdateNotifications,1500);
