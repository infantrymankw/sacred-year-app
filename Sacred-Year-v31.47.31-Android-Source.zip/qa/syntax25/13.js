
async function syV16Session(){
 try{
   if(!window.sySupabase)return null;
   const {data:{session}}=await window.sySupabase.auth.getSession();
   return session||null;
 }catch(e){return null}
}
function syV16Id(prefix){
 return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2,9)}`;
}
function syEnsureLocalIds(key,syLocalStorage=window.syLocalStorage){
 const arr=JSON.parse(syLocalStorage.getItem(key)||"[]");
 let changed=false;
 for(const x of arr){if(!x._local_id){x._local_id=syV16Id(key);changed=true}}
 if(changed)syLocalStorage.setItem(key,JSON.stringify(arr));
 return arr;
}
async function sySyncAllPersonalData(){
 const syAccountScope=window.sy25Scope();

 const syLocalStorage=window.syLocalStorage.forUser(window.syStorageUID?.());
 const session=await window.sy25Await((window.sy25Assert(syAccountScope), (syV16Session())),syAccountScope);
 if(!session?.user)return {ok:false,message:"Sign in to sync."};
 const uid=session.user.id;
 const db=window.sySupabase;
 try{
   if(syLocalStorage.getItem("sy_v16_initial_sync_done_"+uid)!=="1"){
     const runes=syEnsureLocalIds("sy_rune_journal",syLocalStorage);
     for(const x of runes){
       const {data:existing}=await window.sy25Await((window.sy25Assert(syAccountScope), (db.from("rune_journal_entries").select("id").eq("user_id",uid).eq("rune",x.rune).eq("created_at",x.created_at).limit(1))),syAccountScope);
       if(!existing?.length)await window.sy25Await((window.sy25Assert(syAccountScope), (db.from("rune_journal_entries").insert({user_id:uid,rune:x.rune,rune_symbol:x.symbol,question:x.question||null,note:x.note||null,created_at:x.created_at}))),syAccountScope);
     }
     const moons=syEnsureLocalIds("sy_moon_journal",syLocalStorage);
     for(const x of moons){
       const {data:existing}=await window.sy25Await((window.sy25Assert(syAccountScope), (db.from("moon_journal_entries").select("id").eq("user_id",uid).eq("phase",x.phase).eq("created_at",x.saved_at).limit(1))),syAccountScope);
       if(!existing?.length)await window.sy25Await((window.sy25Assert(syAccountScope), (db.from("moon_journal_entries").insert({user_id:uid,phase:x.phase,note:x.note,created_at:x.saved_at}))),syAccountScope);
     }
     const favs=syEnsureLocalIds("sy_library_favorites",syLocalStorage);
     for(const x of favs){
       const {data:existing}=await window.sy25Await((window.sy25Assert(syAccountScope), (db.from("library_favorites").select("id").eq("user_id",uid).eq("saved_at",x.saved_at).limit(1))),syAccountScope);
       if(!existing?.length)await window.sy25Await((window.sy25Assert(syAccountScope), (db.from("library_favorites").insert({user_id:uid,work:x.work,title:x.title||null,passage:x.text,saved_at:x.saved_at}))),syAccountScope);
     }
     const notes=syEnsureLocalIds("sy_library_notes",syLocalStorage);
     for(const x of notes){
       const {data:existing}=await window.sy25Await((window.sy25Assert(syAccountScope), (db.from("library_notes").select("id").eq("user_id",uid).eq("saved_at",x.saved_at).limit(1))),syAccountScope);
       if(!existing?.length)await window.sy25Await((window.sy25Assert(syAccountScope), (db.from("library_notes").insert({user_id:uid,work:x.work,title:x.title||null,snippet:x.snippet||null,note:x.note,saved_at:x.saved_at}))),syAccountScope);
     }
     const rituals=JSON.parse(syLocalStorage.getItem("sy_saved_rituals")||"[]");
     for(const id of rituals)await window.sy25Await((window.sy25Assert(syAccountScope), (db.from("saved_rituals").upsert({user_id:uid,ritual_id:id},{onConflict:"user_id,ritual_id"}))),syAccountScope);
     syLocalStorage.setItem("sy_v16_initial_sync_done_"+uid,"1");
   }

   const {data:rj}=await window.sy25Await((window.sy25Assert(syAccountScope), (db.from("rune_journal_entries").select("*").eq("user_id",uid).order("created_at",{ascending:false}).limit(250))),syAccountScope);
   if(Array.isArray(rj))syLocalStorage.setItem("sy_rune_journal",JSON.stringify(rj.map(x=>({rune:x.rune,symbol:x.rune_symbol,question:x.question||"",note:x.note||"",created_at:x.created_at}))));

   const {data:mj}=await window.sy25Await((window.sy25Assert(syAccountScope), (db.from("moon_journal_entries").select("*").eq("user_id",uid).order("created_at",{ascending:false}).limit(100))),syAccountScope);
   if(Array.isArray(mj))syLocalStorage.setItem("sy_moon_journal",JSON.stringify(mj.map(x=>({phase:x.phase,note:x.note,saved_at:x.created_at}))));

   const {data:lf}=await window.sy25Await((window.sy25Assert(syAccountScope), (db.from("library_favorites").select("*").eq("user_id",uid).order("saved_at",{ascending:false}).limit(150))),syAccountScope);
   if(Array.isArray(lf))syLocalStorage.setItem("sy_library_favorites",JSON.stringify(lf.map(x=>({work:x.work,title:x.title,text:x.passage,saved_at:x.saved_at}))));

   const {data:ln}=await window.sy25Await((window.sy25Assert(syAccountScope), (db.from("library_notes").select("*").eq("user_id",uid).order("saved_at",{ascending:false}).limit(200))),syAccountScope);
   if(Array.isArray(ln))syLocalStorage.setItem("sy_library_notes",JSON.stringify(ln.map(x=>({work:x.work,title:x.title,snippet:x.snippet,note:x.note,saved_at:x.saved_at}))));

   const {data:sr}=await window.sy25Await((window.sy25Assert(syAccountScope), (db.from("saved_rituals").select("ritual_id").eq("user_id",uid))),syAccountScope);
   if(sr)syLocalStorage.setItem("sy_saved_rituals",JSON.stringify(sr.map(x=>x.ritual_id)));

   syLocalStorage.setItem("sy_last_cloud_sync",new Date().toISOString());
   return {ok:true,message:"Cloud sync complete."};
 }catch(e){return {ok:false,message:e.message||"Sync failed."}}
}
window.sySyncAllPersonalData=sySyncAllPersonalData;

async function sySyncNowUI(){
 const r=await sySyncAllPersonalData();
 alert(r.message);
}

async function syForgotPassword(){
 if(!window.sySupabase){alert("Open the hosted Sacred Year app to reset your password.");return}
 const email=prompt("Enter the email address for your Sacred Year account:");
 if(!email)return;
 const {error}=await window.sySupabase.auth.resetPasswordForEmail(email,{redirectTo:location.origin+location.pathname});
 if(error){alert(error.message);return}
 alert("Password reset email sent. Open the link in that email on this device.");
}
window.syForgotPassword=syForgotPassword;

function syOpenPasswordRecovery(){
 openDrawer(`<div class="kicker">Password Recovery</div><h3>Choose a new password</h3><p class="note">Enter a new password for your Sacred Year account.</p><label>New password</label><input id="syNewPassword" type="password" autocomplete="new-password" placeholder="At least 8 characters"><label style="margin-top:10px;display:block">Confirm new password</label><input id="syConfirmPassword" type="password" autocomplete="new-password" placeholder="Enter it again"><button class="btn" style="margin-top:12px" onclick="sySetRecoveredPassword()">Update password</button>`);
}
window.syOpenPasswordRecovery=syOpenPasswordRecovery;

async function sySetRecoveredPassword(){
 const pw=document.getElementById("syNewPassword")?.value||"";
 const confirmPw=document.getElementById("syConfirmPassword")?.value||"";
 if(pw.length<8){alert("Use at least 8 characters.");return}
 if(pw!==confirmPw){alert("The passwords do not match.");return}
 if(!window.sySupabase){alert("Password recovery is not ready. Please reopen the newest reset link.");return}
 const {error}=await window.sySupabase.auth.updateUser({password:pw});
 if(error){alert(error.message);return}
 try{sessionStorage.removeItem("sy_password_recovery_pending")}catch(_){}
 closeDrawer();
 setTimeout(()=>syRefresh().catch(()=>{}),0);
 alert("Password updated. You can use your new password the next time you sign in.");
}
window.sySetRecoveredPassword=sySetRecoveredPassword;

function syPrivacyCenter(){
 openDrawer(`<div class="kicker">Privacy & Data</div><h3>Your Sacred Year data</h3>
 <div class="release-card"><h4>Cloud sync</h4><p>Bookmarks, saved rune, preferences, journals, reading favorites/notes, and saved rituals can sync to your signed-in account.</p><button class="btn secondary" onclick="sySyncNowUI()">Sync now</button></div>
 <div class="release-card"><h4>Local data</h4><p>Some information is cached on this device so the app remains useful between sessions.</p><button class="btn secondary" onclick="syClearLocalCache()">Clear local cache</button></div>
 <div class="release-card"><h4>Password</h4><p>Request a secure password-reset link by email.</p><button class="btn secondary" onclick="syForgotPassword()">Reset password</button></div>
 <div class="release-card danger-zone"><h4>Delete account</h4><p>This permanently removes your Sacred Year account and eligible synced data when the deletion service is available.</p><button class="btn danger" onclick="sy315OpenDelete()">Delete my account</button></div>`);
}
window.syPrivacyCenter=syPrivacyCenter;

function syClearLocalCache(){
 if(!confirm("Clear Sacred Year journals, favorites, saved rituals, bookmarks, and saved rune from this device? Cloud copies are not deleted."))return;
 ["sy_rune_journal","sy_moon_journal","sy_library_favorites","sy_library_notes","sy_saved_rituals","sy_reader_bookmark","sy_saved_rune"].forEach(k=>syLocalStorage.removeItem(k));
 closeDrawer();alert("Local Sacred Year cache cleared.");
}
window.syClearLocalCache=syClearLocalCache;

async function syConfirmDeleteAccount(){
 if(!confirm("Permanently delete your Sacred Year account and synced data? This cannot be undone."))return;
 const typed=prompt('Type DELETE to confirm permanent account deletion:');
 if(typed!=="DELETE"){alert("Account deletion cancelled.");return}
 try{
   if(!window.sySupabase)throw new Error("Open the hosted app to delete your account.");
   const {data,error}=await window.sySupabase.functions.invoke("delete-account",{body:{}});
   if(error)throw error;
   await window.sySupabase.auth.signOut();
   ["sy_rune_journal","sy_moon_journal","sy_library_favorites","sy_library_notes","sy_saved_rituals","sy_reader_bookmark","sy_saved_rune"].forEach(k=>syLocalStorage.removeItem(k));
   closeDrawer();alert("Your Sacred Year account has been deleted.");
   location.reload();
 }catch(e){alert(e.message||"Account deletion failed.")}
}
window.syConfirmDeleteAccount=syConfirmDeleteAccount;

function syHallPlus(){
 openDrawer(`<div class="kicker">Hall+</div><h3>Support Sacred Year</h3>
 <div class="release-card"><h4>Free</h4><p>Calendar, Moon, Rune study, Gods, Ritual Hall, Sacred Library, Words from the Hall, and core account features.</p></div>
 <div class="release-card"><h4>Hall+ — planned</h4><p>Deeper journal tools, advanced personalization, premium study collections, and additional seasonal material.</p><p class="note">Billing is not active yet. Apple/Google purchase verification will be connected before this button becomes a real subscription purchase.</p></div>`);
}
window.syHallPlus=syHallPlus;

function syReleaseSettings(){
 const last=syLocalStorage.getItem("sy_last_cloud_sync");
 openDrawer(`<div class="kicker">Settings</div><h3>Sacred Year</h3>
 <div class="account-grid">
   <button class="account-card" onclick="syPrivacyCenter()"><h4>Privacy & Data</h4><p>Password, sync, local cache, account deletion</p></button>
   <button class="account-card" onclick="sySyncNowUI()"><h4>Cloud Sync</h4><p>${last?"Last: "+syDisplayDate(last):"Not synced yet"}</p></button>
   <button class="account-card" onclick="syHallPlus()"><h4>Hall+</h4><p>Subscription preview</p></button>
   <button class="account-card" onclick="syOpenNotifications()"><h4>Notifications</h4><p>Hall messages and browser alert settings</p></button>
 </div>`);
}
window.syReleaseSettings=syReleaseSettings;

// Enhance existing account drawer by providing a dedicated settings entry from the header/account experience.
const oldV15Account=window.openAccount;
window.openAccount=async function(){
 if(typeof oldV15Account==="function"){
   await oldV15Account();
   setTimeout(()=>{
     const sheet=document.getElementById("sheet");
     if(sheet && !document.getElementById("syV16SettingsBtn") && sheet.textContent.includes("Account")){
       const b=document.createElement("button");
       b.id="syV16SettingsBtn";b.className="btn secondary";b.style.marginTop="10px";b.textContent="Settings & Privacy";
       b.onclick=syReleaseSettings;sheet.appendChild(b);
     }
   },50);
 }
};

// Cloud-write hooks for newly created data.
const oldSaveRuneJournal=window.sySaveRuneJournal;
window.sySaveRuneJournal=async function(name){
 if(oldSaveRuneJournal)oldSaveRuneJournal(name);
 setTimeout(async()=>{syLocalStorage.removeItem("sy_v16_initial_sync_done_"+((await syV16Session())?.user?.id||""));await sySyncAllPersonalData()},150);
};
const oldSaveMoonNote=window.sySaveMoonNote;
window.sySaveMoonNote=async function(phase){
 if(oldSaveMoonNote)oldSaveMoonNote(phase);
 setTimeout(async()=>{syLocalStorage.removeItem("sy_v16_initial_sync_done_"+((await syV16Session())?.user?.id||""));await sySyncAllPersonalData()},150);
};
const oldFavorite=window.syLibFavoriteCurrent;
window.syLibFavoriteCurrent=async function(){
 if(oldFavorite)oldFavorite();
 setTimeout(async()=>{syLocalStorage.removeItem("sy_v16_initial_sync_done_"+((await syV16Session())?.user?.id||""));await sySyncAllPersonalData()},150);
};
const oldSaveLibNote=window.syLibSaveNote;
window.syLibSaveNote=async function(){
 if(oldSaveLibNote)oldSaveLibNote();
 setTimeout(async()=>{syLocalStorage.removeItem("sy_v16_initial_sync_done_"+((await syV16Session())?.user?.id||""));await sySyncAllPersonalData()},150);
};
const oldSaveRitual=window.sySaveRitual;
window.sySaveRitual=async function(id){
 if(oldSaveRitual)oldSaveRitual(id);
 setTimeout(async()=>{syLocalStorage.removeItem("sy_v16_initial_sync_done_"+((await syV16Session())?.user?.id||""));await sySyncAllPersonalData()},150);
};

// v31.13 recovery UI: handle both the live PASSWORD_RECOVERY event and callbacks
// retained for older recovery links that may have already created a signed-in recovery session.
(function syInstallRecoveryHandler(){
 const install=()=>{
   if(!window.sySupabase)return false;
   window.sySupabase.auth.onAuthStateChange(async(event,session)=>{
     if(event==="PASSWORD_RECOVERY"){
       try{sessionStorage.setItem("sy_password_recovery_pending","1")}catch(_){}
       setTimeout(syOpenPasswordRecovery,0);
     }
     if(event==="SIGNED_IN")setTimeout(sySyncAllPersonalData,300);
   });
   window.sySupabase.auth.getSession().then(({data})=>{
     let pending=false;
     try{pending=sessionStorage.getItem("sy_password_recovery_pending")==="1"}catch(_){}
     if(pending && data?.session?.user)setTimeout(syOpenPasswordRecovery,50);
     if(data?.session?.user)setTimeout(sySyncAllPersonalData,700);
   }).catch(()=>{});
   return true;
 };
 if(install())return;
 let tries=0;
 const timer=setInterval(()=>{if(install()||++tries>40)clearInterval(timer)},100);
})();
