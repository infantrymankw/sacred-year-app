
(function(){
  async function routePushLink(){
    try{
      const q=new URLSearchParams(location.search);
      const target=q.get("open");
      if(!target)return;
      if(target==="moon"){showView("moon");}
      else if(target==="calendar"){showView("calendar");}
      else if(target==="notifications"){window.syOpenNotifications?.();}
      else if(target==="reminders"){
        if(window.sy307Reminders) await window.sy307Reminders();
        else window.syOpenHallPlus?.();
      }
      // Remove the one-time routing parameter so refresh doesn't reopen a drawer.
      const clean=location.pathname+location.hash;
      history.replaceState({},document.title,clean);
    }catch(e){console.warn("Sacred Year notification route",e);}
  }
  window.addEventListener("load",()=>setTimeout(routePushLink,900));
})();
