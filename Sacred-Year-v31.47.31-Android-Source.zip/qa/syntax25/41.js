
(function(){
  const esc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));

  // Final creator dashboard override. This runs after older dashboard scripts so
  // they cannot replace the version that includes Manage Published Content.
  window.syOpenCreator = async function(){
    try{
      const c=window.sySupabase||window.supabase;
      const {data:{session}}=await c.auth.getSession();
      if(!session?.user){openAccount();return}
      const {data:profile}=await c.from("profiles").select("role").eq("id",session.user.id).maybeSingle();
      if(profile?.role!=="creator"){alert("Creator access is not enabled for this account.");return}

      const [cr,mr,er,pe]=await Promise.all([
        c.from("community_reports").select("id",{count:"exact",head:true}).eq("status","open"),
        c.from("moderation_reports").select("id",{count:"exact",head:true}).in("status",["submitted","open"]),
        c.from("community_event_reports").select("id",{count:"exact",head:true}).eq("status","open"),
        c.from("community_events").select("id",{count:"exact",head:true}).eq("status","pending")
      ]);
      const reports=(cr.count||0)+(mr.count||0)+(er.count||0);
      const pending=pe.count||0;

      openDrawer(`<div class="kicker">Private Creator Dashboard</div><h3>Creator Control Center</h3>
        <p class="note">Publish Sacred Year content and manage the Community Hall from one place.</p>
        <div class="sy321-grid">
          <button type="button" class="sy321-card" id="sy325Publish"><div class="kicker">Publish</div><h4>Words from the Hall</h4><p>Create a new reflection, historical note, practice post, or announcement.</p></button>
          <button type="button" class="sy321-card" id="sy325Manage"><div class="kicker">Content</div><h4>Manage Published Content</h4><p>Edit or remove Words from the Hall posts you have already published.</p></button>
          <button type="button" class="sy321-card" id="sy325Moderation"><div class="kicker">Moderation</div><h4>Moderation Center</h4><p>${reports} open report${reports===1?"":"s"} • ${pending} pending event${pending===1?"":"s"}</p></button>
        </div>
        <button type="button" class="btn secondary" id="sy325Account">Back to account</button>`);

      requestAnimationFrame(()=>{
        document.getElementById("sy325Publish")?.addEventListener("click",()=>window.sy321OpenPublisher?.());
        document.getElementById("sy325Manage")?.addEventListener("click",()=>window.sy325ManagePublishedContent());
        document.getElementById("sy325Moderation")?.addEventListener("click",()=>window.sy321ModerationHome?.());
        document.getElementById("sy325Account")?.addEventListener("click",()=>openAccount());
      });
    }catch(e){alert(e?.message||"Creator dashboard could not be opened.");}
  };

  // Independent content manager; does not depend on the older sy322 wrapper.
  window.sy325ManagePublishedContent = async function(){
    try{
      const c=window.sySupabase||window.supabase;
      const {data:{session}}=await c.auth.getSession();
      if(!session?.user){openAccount();return}
      const {data:profile}=await c.from("profiles").select("role").eq("id",session.user.id).maybeSingle();
      if(profile?.role!=="creator"){alert("Creator access is not enabled for this account.");return}
      const {data,error}=await c.from("creator_posts").select("*").order("published_at",{ascending:false}).limit(100);
      if(error)throw error;

      openDrawer(`<div class="kicker">Creator Content</div><h3>Manage Published Content</h3>
        <p class="note">Edit or remove your published Words from the Hall content.</p>
        <div class="sy321-list">${(data||[]).map(p=>`<div class="sy321-item">
          <div class="kicker">${esc(p.label||"Words from the Hall")} • ${esc(p.status||"published")}</div>
          <h4>${esc(p.title||"Words from the Hall")}</h4>
          <p>${esc(p.message||"")}</p>
          <div class="sy321-meta">${p.published_at?syDisplayDate(p.published_at):""}</div>
          <div class="sy321-actions">
            <button type="button" class="btn secondary" data-edit="${p.id}">Edit</button>
            <button type="button" class="btn secondary sy321-danger" data-delete="${p.id}">Delete</button>
          </div>
        </div>`).join("")||'<p class="sy321-empty">No published creator content yet.</p>'}</div>
        <button type="button" class="btn secondary" id="sy325CreatorBack" style="margin-top:14px">Back to Creator Dashboard</button>`);

      requestAnimationFrame(()=>{
        document.getElementById("sy325CreatorBack")?.addEventListener("click",()=>window.syOpenCreator());
        document.querySelectorAll("[data-edit]").forEach(b=>b.addEventListener("click",()=>window.sy322EditCreatorPost?.(b.dataset.edit)));
        document.querySelectorAll("[data-delete]").forEach(b=>b.addEventListener("click",()=>window.sy322DeleteCreatorPost?.(b.dataset.delete)));
      });
    }catch(e){alert(e?.message||"Published content could not be loaded.");}
  };

  // Case-insensitive backdrop routing. The previous build compared against
  // title-case strings while the actual sheet text is rendered in uppercase.
  window.sy324Backdrop = function(){
    const t=(document.getElementById("sheet")?.innerText||"").toLowerCase();

    if(t.includes("advanced journal") ||
       t.includes("advanced reminders") ||
       t.includes("guided study") ||
       t.includes("event studio") ||
       t.includes("divination")){
      window.syOpenHallPlus?.();
      return;
    }

    if(t.includes("open reports") ||
       t.includes("posts & replies") ||
       t.includes("event moderation") ||
       t.includes("user restrictions") ||
       t.includes("audit trail")){
      window.sy321ModerationHome?.();
      return;
    }

    if(t.includes("manage published content") ||
       t.includes("edit published content") ||
       t.includes("words from the hall") ||
       t.includes("moderation center")){
      window.syOpenCreator?.();
      return;
    }

    closeDrawer();
  };
})();
