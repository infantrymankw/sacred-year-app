
(function(){
 if(!window.Capacitor?.isNativePlatform?.())return;
 const blocked=/sy307(?:Checkout|Donate|ManageBilling|StartBilling)|sySupportDonate|invokeBilling|manageBilling/;
 function hideBilling(){document.querySelectorAll('button').forEach(b=>{if(blocked.test((b.getAttribute('onclick')||'')+' '+b.id)){b.hidden=true;b.style.setProperty("display","none","important");}});}
 document.addEventListener('click',e=>{const b=e.target.closest('button');if(b&&blocked.test((b.getAttribute('onclick')||'')+' '+b.id)){e.preventDefault();e.stopImmediatePropagation();}},true);
 document.addEventListener('DOMContentLoaded',()=>{hideBilling();new MutationObserver(hideBilling).observe(document.body,{childList:true,subtree:true});});
})();
