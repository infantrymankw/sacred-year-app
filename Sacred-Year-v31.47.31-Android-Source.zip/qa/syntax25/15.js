
/* Sacred Year v19 — Hall+ + Public Events */
const SY19_EVENT_FILTERS=["all","official","verified","trusted","community"];
let sy19EventFilter="all";
let sy19Events=[];

function sy19Esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}
async function sy19Session(){try{if(!window.sySupabase)return null;const {data:{session}}=await window.sySupabase.auth.getSession();return session}catch(e){return null}}

async function syOpenHallPlus(){
 const ent=typeof syGetEntitlements==="function"?await syGetEntitlements():{hall_plus:false,supporter:false};
 openDrawer(`<div class="kicker">Hall+</div><h3>Keep the Hall Burning</h3>
 <p class="note">Sacred Year's core religious learning stays free. Hall+ is for deeper personal tools and convenience—not putting the old texts or basic practice behind a paywall.</p>
 <div class="notice ${ent.hall_plus?"good":"warn"}"><b>${ent.hall_plus?"Hall+ active":"Free plan"}</b><br>${ent.hall_plus?"Your account has Hall+ access.":"Hall+ purchasing is not connected yet."}${ent.supporter?"<br><b>Supporter:</b> voluntary support is active on this account.":""}</div>
 <div class="sy19-plus-grid">
   <div class="sy19-plan"><div class="kicker">Free</div><h4>Sacred Year</h4><ul>
    <li>Sacred Calendar & Moon</li><li>Hávamál, Poetic Edda & Prose Edda reader</li><li>Rune study & core journal</li><li>Gods, rituals & Wild Hunt</li><li>Community Hall & public events</li><li>Words from the Hall</li>
   </ul></div>
   <div class="sy19-plan"><div class="kicker">Hall+ ${ent.hall_plus?"active":"planned"}</div><h4>Deeper Practice</h4><ul>
    <li>Advanced journal organization & search</li><li>Richer cross-device cloud backup</li><li>Personal Sacred Year annual Yearbook</li><li>Advanced reminder schedules</li><li>Expanded study collections & guided seasonal deep-dives</li><li>Circle/organizer tools for groups</li>
   </ul><button class="btn" onclick="sy19PlusComingSoon()">${ent.hall_plus?"Hall+ active":"Hall+ coming soon"}</button></div>
 </div>
 <div class="sy19-support"><div class="kicker">Voluntary support</div><h4>Support Sacred Year</h4>
 <p>Help keep the core app and religious texts available to people who cannot afford subscriptions or books. Support is separate from Hall+ access.</p>
 <button class="btn secondary" onclick="sy19SupportComingSoon()">${ent.supporter?"Supporter active":"Support options coming soon"}</button>
 <p class="note">Store-compliant purchasing will be activated only after Apple/Google billing is connected.</p></div>`);
}
function sy19PlusComingSoon(){alert("Hall+ purchasing is intentionally disabled until verified Apple/Google billing is connected.")}
function sy19SupportComingSoon(){alert("Voluntary support purchasing will be activated with store-compliant billing before release.")}
window.syOpenHallPlus=syOpenHallPlus;

function sy19OrganizerBadge(type){
 const t=(type||"community").toLowerCase();
 const labels={official:"Sacred Year Official",verified:"Verified Organization",trusted:"Trusted Organizer",community:"Community Organizer"};
 return `<span class="sy19-badge sy19-${t}">${labels[t]||labels.community}</span>`;
}
function syOpenEvents(){
 openDrawer(`<div class="kicker">Community Hall</div><h3>Community Events</h3>
 <p class="sy19-safe">Sacred Year events are for public gathering places only. Do not post home addresses or private residences.</p>
 <div class="sy19-filterbar">${SY19_EVENT_FILTERS.map(x=>`<button class="sy19-filter ${x===sy19EventFilter?"active":""}" onclick="sy19SetEventFilter('${x}')">${x==="all"?"All":x[0].toUpperCase()+x.slice(1)}</button>`).join("")}</div>
 <div class="row"><button class="btn" onclick="sy19NewEvent()">Submit an Event</button><button class="btn secondary" onclick="sy19LoadEvents()">Refresh</button></div>
 <div id="sy19EventFeed"></div>`);
 sy19LoadEvents();
}
window.syOpenEvents=syOpenEvents;

function sy19SetEventFilter(x){sy19EventFilter=x;syOpenEvents()}

async function sy19LoadEvents(){
 const syAccountScope=window.sy25Scope();

 sy19Events=[];
 try{
  if(window.sySupabase){
   // Query only approval in Firestore, then filter/sort upcoming events locally.
   // The previous status + starts_at compound query can require a composite index; when
   // that index is absent Firestore rejects it and the old UI silently showed an empty feed.
   let q=window.sySupabase.from("community_events_public").select("*").eq("status","approved").limit(200);
   const {data,error}=await window.sy25Await((window.sy25Assert(syAccountScope), (q)),syAccountScope);
   if(error)throw error;
   const now=Date.now();
   sy19Events=(data||[]).filter(e=>{
     const at=Date.parse(e.starts_at);
     if(!Number.isFinite(at)||at<now)return false;
     return sy19EventFilter==="all"||String(e.organizer_type||"community").toLowerCase()===sy19EventFilter;
   }).sort((a,b)=>Date.parse(a.starts_at)-Date.parse(b.starts_at)).slice(0,100);
  }
 }catch(e){}
 if(window.sy319LoadMyRsvps)await window.sy25Await((window.sy25Assert(syAccountScope), (sy319LoadMyRsvps())),syAccountScope);
 sy19RenderEvents();
}
function sy19RenderEvents(){
 const el=document.getElementById("sy19EventFeed");if(!el)return;
 if(!sy19Events.length){el.innerHTML='<p class="community-empty">No approved upcoming events in this filter yet.</p>';return}
 el.innerHTML=sy19Events.map(e=>`<div class="sy19-event">
  ${sy19OrganizerBadge(e.organizer_type)}
  <h4>${sy19Esc(e.title)}</h4>
  <div class="sy19-event-meta">${syDisplayDate(e.starts_at)}</div>
  ${e.location_unlocked
    ? `<div class="sy19-event-meta">${sy19Esc(e.city)}, ${sy19Esc(e.region)}${e.country?" • "+sy19Esc(e.country):""}</div>
       <p><b>${sy19Esc(e.venue_name)}</b>${e.venue_public_info?`<br>${sy19Esc(e.venue_public_info)}`:""}<br>${sy19Esc(e.description||"")}</p>
       <div class="community-actions"><button class="btn secondary" onclick="sy319ToggleRsvp('${e.id}')">${window.sy319RsvpSet&&window.sy319RsvpSet.has(e.id)?"Remove interest":"I'm interested"}</button><button class="btn secondary" onclick="syCommunityReport?sy19ReportEvent('${e.id}'):void 0">Report</button></div>`
    : `<p><b>Location hidden</b><br>Confirm that you are 18 or older to view this event's location.</p>
       <p>${sy19Esc(e.description||"")}</p>
       <div class="community-actions"><button class="btn secondary" onclick="sy19UnlockEventLocation()">Confirm 18+ & view location</button><button class="btn secondary" onclick="syCommunityReport?sy19ReportEvent('${e.id}'):void 0">Report</button></div>`
  }
 </div>`).join("");
}
function sy19LooksResidential(text){
 const s=(text||"").trim().toLowerCase();
 const street=/\b\d{1,6}\s+[a-z0-9.' -]{2,50}\s+(street|st|road|rd|avenue|ave|drive|dr|lane|ln|court|ct|boulevard|blvd|way|circle|cir|terrace|trl|trail)\b/i;
 const privateWords=/\b(my house|my home|private residence|apartment|apt\.?|unit\s+\d+|home address|residence)\b/i;
 const publicVenue=/\b(park|library|community center|civic center|recreation center|rec center|museum|hotel|convention center|conference center|festival|fairground|fairgrounds|bookstore|university|college|campus|cafe|café|coffee|restaurant|brewery|church|temple|hall|theater|theatre|arena|stadium|plaza|square|market)\b/i;
 return privateWords.test(s)||(street.test(s)&&!publicVenue.test(s));
}
function sy19NewEvent(){
 sy19Session().then(s=>{
  if(!s?.user){closeDrawer();openAccount();return}
  openDrawer(`<div class="kicker">Submit an Event</div><h3>Public places only</h3>
   <p class="sy19-safe">Choose a public venue such as a park, library, community center, café, festival grounds, rented hall, or established place of worship. Do not enter a home address.</p>
   <label>Event title</label><input id="sy19ETitle" maxlength="120">
   <label>Date & time</label><input id="sy19EWhen" type="datetime-local">
   <label>Country</label><input id="sy19ECountry" maxlength="80" value="United States">
   <label>State / region</label><input id="sy19ERegion" maxlength="100">
   <label>City</label><input id="sy19ECity" maxlength="100">
   <label>Public venue name</label><input id="sy19EVenue" maxlength="140" placeholder="Example: Central Library or Riverside Park">
   <label>Public venue information</label><input id="sy19EVenueInfo" maxlength="200" placeholder="Optional: public entrance, pavilion, meeting room">
   <label>Description</label><textarea id="sy19EDesc" rows="6" maxlength="3000"></textarea>
   <button class="btn" onclick="sy19SubmitEvent()">Submit for review</button>
   <p class="note">New community organizers are reviewed before publication. Verified organizations and trusted organizers can qualify for faster approval.</p>`);
 })
}
async function sy19SubmitEvent(){
 const syAccountScope=window.sy25Scope();

 const s=await window.sy25Await((window.sy25Assert(syAccountScope), (sy19Session())),syAccountScope);if(!s?.user)return;
 const title=document.getElementById("sy19ETitle").value.trim(),when=document.getElementById("sy19EWhen").value;
 const country=document.getElementById("sy19ECountry").value.trim(),region=document.getElementById("sy19ERegion").value.trim(),city=document.getElementById("sy19ECity").value.trim();
 const venue=document.getElementById("sy19EVenue").value.trim(),info=document.getElementById("sy19EVenueInfo").value.trim(),desc=document.getElementById("sy19EDesc").value.trim();
 if(!title||!when||!region||!city||!venue){alert("Please complete the title, date/time, state/region, city, and public venue.");return}
 if(sy19LooksResidential(venue+" "+info+" "+desc)){alert("This looks like it may contain a residential/private address. Sacred Year events must use public meeting places. Please remove the private address and name the public venue instead.");return}
 const eventData={title,description:desc||null,starts_at:new Date(when).toISOString(),country:country||null,region,city,venue_name:venue,venue_public_info:info||null};
 try{
   if(window.sy316SubmitEvent){
     await window.sy25Await((window.sy25Assert(syAccountScope), (window.sy316SubmitEvent(eventData))),syAccountScope);
   }else{
     throw new Error("Event safety acknowledgment is unavailable. Please refresh and try again.");
   }
   alert("Event submitted for review.");
   syOpenEvents();
 }catch(e){if(e&&e.message)console.warn(e.message)}
}
async function sy19RSVP(id){
 const syAccountScope=window.sy25Scope();

 const s=await window.sy25Await((window.sy25Assert(syAccountScope), (sy19Session())),syAccountScope);if(!s?.user){closeDrawer();openAccount();return}
 try{
   const at=new Date().toISOString();
   const {error}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("community_event_rsvps").upsert(
     {event_id:id,user_id:s.user.id,status:"interested",age_18_attested_at:at},
     {onConflict:"event_id,user_id"}
   ))),syAccountScope);
   if(error)throw error;
   if(window.sy314RecordConsent)await window.sy25Await((window.sy25Assert(syAccountScope), (sy314RecordConsent("event_attendee","2026-08-17"))),syAccountScope);
   alert("Event saved to your interested events.");
 }catch(e){alert(e.message||"Could not save this event.")}
}
async function sy19ReportEvent(id){
 const syAccountScope=window.sy25Scope();

 const s=await window.sy25Await((window.sy25Assert(syAccountScope), (sy19Session())),syAccountScope);if(!s?.user){closeDrawer();openAccount();return}
 try{
   const {data:eventRow}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("community_events_public").select("title").eq("id",id).maybeSingle())),syAccountScope);
   const target=eventRow?.title||("Event "+id);
   if(window.sy314OpenReport){
     sy314OpenReport("Event",target);
     const form=document.getElementById("sy314Report");
     if(form){
       form.dataset.eventId=id;
       const details=document.getElementById("sy314Details");
       if(details)details.placeholder="Describe what is wrong with this event, location, organizer, or listing.";
     }
     return;
   }
   throw new Error("Report form unavailable.");
 }catch(e){alert(e.message||"Event reporting is not available right now.")}
}
window.sy19NewEvent=sy19NewEvent;window.sy19SubmitEvent=sy19SubmitEvent;window.sy19RSVP=sy19RSVP;window.sy19ReportEvent=sy19ReportEvent;

async function sy19EventModeration(){
 const syAccountScope=window.sy25Scope();

 let rows=[];try{const {data,error}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("community_events").select("*").eq("status","pending").order("created_at",{ascending:true}).limit(50))),syAccountScope);if(error)throw error;rows=data||[]}catch(e){alert(e.message);return}
 openDrawer(`<div class="kicker">Creator Moderation</div><h3>Pending Events</h3><div class="list">${rows.map(e=>`<div class="item"><div class="kicker">${sy19OrganizerBadge(e.organizer_type)}</div><h4>${sy19Esc(e.title)}</h4><p>${syDisplayDate(e.starts_at)} • ${sy19Esc(e.city)}, ${sy19Esc(e.region)}<br><b>${sy19Esc(e.venue_name)}</b></p><div class="row"><button class="btn" onclick="sy19ApproveEvent('${e.id}')">Approve</button><button class="btn secondary" onclick="sy19RejectEvent('${e.id}')">Reject</button></div></div>`).join("")||'<p class="community-empty">No events waiting for approval.</p>'}</div>`);
}
async function sy19ApproveEvent(id){
 const syAccountScope=window.sy25Scope();
const {error}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("community_events").update({status:"approved"}).eq("id",id))),syAccountScope);if(error){alert(error.message);return}sy19EventModeration()}
async function sy19RejectEvent(id){
 const syAccountScope=window.sy25Scope();
const {error}=await window.sy25Await((window.sy25Assert(syAccountScope), (window.sySupabase.from("community_events").update({status:"rejected"}).eq("id",id))),syAccountScope);if(error){alert(error.message);return}sy19EventModeration()}
window.sy19EventModeration=sy19EventModeration;window.sy19ApproveEvent=sy19ApproveEvent;window.sy19RejectEvent=sy19RejectEvent;

/* Add Event door to Community Hall and Hall+ / Events shortcuts to Today after render */
const sy19OldCommunity=window.syOpenCommunityHall;
if(sy19OldCommunity)window.syOpenCommunityHall=function(){
 sy19OldCommunity();
 setTimeout(()=>{
  const sheet=document.getElementById("sheet");if(!sheet)return;
  const tabs=sheet.querySelector(".community-tabs");
  if(tabs&&!document.getElementById("sy19EventsDoor")){
   const b=document.createElement("button");b.id="sy19EventsDoor";b.className="community-tab";b.textContent="Public Events";b.onclick=syOpenEvents;tabs.appendChild(b);
  }
 },30);
};
setTimeout(()=>{
 const q=document.querySelector("#today .section-nav");
 if(q&&!document.getElementById("sy19TodayEvents")){
  const e=document.createElement("button");e.id="sy19TodayEvents";e.className="section-card";e.onclick=syOpenEvents;e.innerHTML='<div style="font-size:28px">📍</div><h4>Public Events</h4><p>Find approved gatherings at public venues.</p>';q.appendChild(e);
  const h=document.createElement("button");h.id="sy19TodayPlus";h.className="section-card";h.onclick=syOpenHallPlus;h.innerHTML='<div style="font-size:28px">🔥</div><h4>Hall+</h4><p>Deeper practice tools and voluntary support.</p>';q.appendChild(h);
 }
},800);
