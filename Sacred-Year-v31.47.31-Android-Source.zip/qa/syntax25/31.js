
(function(){
 const REPORT_KEY="sy_moderation_reports_v1", BLOCK_KEY="sy_blocked_users_v1", CONSENT_KEY="sy_legal_consents_v1";
 function arr(k){try{return JSON.parse(syLocalStorage.getItem(k)||"[]")}catch(e){return[]}}
 function save(k,v){syLocalStorage.setItem(k,JSON.stringify(v))}
 window.sy314OpenReport=function(type,target){
   const form=document.getElementById("sy314Report");
   if(form){delete form.dataset.eventId;delete form.dataset.targetUserId;delete form.dataset.communityKind;delete form.dataset.communityId;}
   document.getElementById("sy314Type").value=type||"User";
   document.getElementById("sy314Target").value=target||"";
   const details=document.getElementById("sy314Details");
   details.value="";
   details.placeholder="Describe what happened and why you are reporting it.";
   form.classList.add("open");
 };
 window.sy314CloseReport=function(){const f=document.getElementById("sy314Report");if(f){delete f.dataset.targetUserId;delete f.dataset.communityKind;delete f.dataset.communityId;f.classList.remove("open")}};
 window.sy314SubmitReport=async function(){
   const report={id:"r_"+Date.now(),type:document.getElementById("sy314Type").value,target:document.getElementById("sy314Target").value.trim(),details:document.getElementById("sy314Details").value.trim(),status:"submitted",created_at:new Date().toISOString()};
   if(!report.target||!report.details){alert("Please identify what you are reporting and describe what happened.");return}
   const reports=arr(REPORT_KEY);reports.push(report);save(REPORT_KEY,reports);
   try{
     if(window.sySupabase){
       const {data:{session}}=await window.sySupabase.auth.getSession();
       if(session?.user){
         const eventId=document.getElementById("sy314Report")?.dataset?.eventId||"";
         if(report.type==="Event"&&eventId){
           const {error:eventError}=await window.sySupabase.from("community_event_reports").insert({event_id:eventId,reporter_id:session.user.id,reason:report.details});
           if(eventError)throw eventError;
         }else{
           const {error}=await window.sySupabase.from("moderation_reports").insert({reporter_id:session.user.id,report_type:report.type,target_label:report.target,details:report.details,status:"submitted"});
           if(error)throw error;
         }
       }
     }
   }catch(e){
     alert((e&&e.message)||"The report could not be submitted.");
     return;
   }
   const form=document.getElementById("sy314Report");if(form)delete form.dataset.eventId;
   sy314CloseReport();
   alert("Report submitted. Sacred Year will review the concern.");
 };
 window.sy314BlockUser=function(label){
   const name=(label||prompt("Enter the user name or identifier you want to block:")||"").trim();
   if(!name)return;
   let blocked=arr(BLOCK_KEY);if(!blocked.includes(name))blocked.push(name);save(BLOCK_KEY,blocked);
   document.querySelectorAll("[data-sy-user]").forEach(el=>{if(el.getAttribute("data-sy-user")===name)el.style.display="none"});
   alert(name+" has been blocked on this device.");
 };
 window.sy314IsBlocked=function(name){return arr(BLOCK_KEY).includes(name)};
 window.sy314RecordConsent=function(kind,version){
   const cs=arr(CONSENT_KEY);cs.push({kind:kind,version:version||"2026-08-17",accepted_at:new Date().toISOString()});save(CONSENT_KEY,cs);
 };
 window.sy314RequestAccountDeletionBackup=function(){
   const subject=encodeURIComponent("Sacred Year Account Deletion Request");
   const body=encodeURIComponent("I am requesting deletion of my Sacred Year account and eligible associated personal data. Please contact me to verify this request.");
   location.href="mailto:Sacredyear1@gmail.com?subject="+subject+"&body="+body;
 };
 window.sy314SafetyButtons=function(target,type){
   return `<div class="sy314-safety-actions"><button class="btn secondary" onclick="sy314OpenReport('${type||"User"}','${String(target||"").replace(/'/g,"&#39;")}')">Report ${type||"User"}</button>${(type||"User")==="User"?`<button class="btn secondary" onclick="sy314BlockUser('${String(target||"").replace(/'/g,"&#39;")}')">Block User</button>`:""}</div>`;
 };
})();
