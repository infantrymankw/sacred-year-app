
const SY_GODS=[
 {name:"Týr",alt:"Tiw • Tīw • Proto-Germanic *Tīwaz",group:"Æsir",icon:"ᛏ",
 roles:"Law, oaths, battle, courage, binding and sacrifice.",
 sources:"Poetic Edda (especially Hymiskviða and Lokasenna); Prose Edda (Gylfaginning); linguistic evidence in the weekday Tuesday and the reconstructed divine name *Tīwaz.",
 myths:"Best known for placing his hand in Fenrir’s mouth as the gods bind the wolf. Fenrir bites it off when the binding proves unbreakable.",
 symbols:"The Tiwaz rune is linguistically connected with his name. The lost hand is his clearest mythic marker.",
 modern:"Modern devotees often emphasize courage, justice, keeping one’s word, responsibility, and accepting the cost of honorable action.",
 caution:"Modern claims that Týr governed a single universal Germanic legal system go beyond the surviving evidence."},
 {name:"Thor",alt:"Þórr • Donar • Thunor",group:"Æsir",icon:"🔨",
 roles:"Thunder, protection, strength, consecration, defense of gods and humans.",
 sources:"Extensively attested in the Poetic Edda and Prose Edda; skaldic poetry, place-names, archaeology, and historical accounts also attest widespread cult.",
 myths:"Battles jötnar, fishes for Jörmungandr, retrieves Mjölnir in Þrymskviða, and is destined to kill the World Serpent at Ragnarök before dying from its venom.",
 symbols:"Mjölnir; goats and the goat-drawn chariot; thunder. Archaeological hammer pendants are especially important material evidence.",
 modern:"Protection of home and family, strength used responsibly, hallowing, courage, and gratitude are common modern devotional themes.",
 caution:"Modern lists sometimes assign Thor many rigid 'domains.' The sources portray a complex deity rather than a game-style portfolio."},
 {name:"Odin",alt:"Óðinn • Woden • Wotan",group:"Æsir",icon:"🐦‍⬛",
 roles:"Wisdom, poetry, war, death, ecstasy, magic, runes and rulership.",
 sources:"Poetic Edda, Prose Edda, skaldic poetry, sagas, place-names, archaeology, and Continental/Anglo-Saxon evidence.",
 myths:"Sacrifices himself to himself in Hávamál’s rune episode, gives an eye for wisdom in later prose tradition, seeks knowledge from the dead, and gathers slain warriors associated with Valhöll.",
 symbols:"Spear Gungnir, ravens Huginn and Muninn, wolves Geri and Freki, the eight-legged horse Sleipnir, and the one-eyed image in later tradition.",
 modern:"Study, poetry, disciplined pursuit of knowledge, rune study, remembrance of the dead, and careful reflection on sacrifice.",
 caution:"Odin varies significantly across source genres and periods; not every later folkloric Woden/Wotan trait can simply be projected into Viking-Age Scandinavia."},
 {name:"Frigg",alt:"Frigg • Frig",group:"Ásynjur",icon:"🗝️",
 roles:"Foreknowledge, marriage, household authority, motherhood and queenship in surviving Norse tradition.",
 sources:"Poetic Edda including Lokasenna and Völuspá; Prose Edda; Germanic linguistic evidence connects her name to the weekday Friday tradition alongside complicated Freyja/Frigg developments.",
 myths:"Mother of Baldr in Norse myth. She seeks oaths from beings and things not to harm him, but mistletoe is omitted and Baldr is killed.",
 symbols:"No single securely attested ancient emblem comparable to Mjölnir. Keys, spindle imagery, or household symbols are useful modern choices but should be labeled modern/reconstructed.",
 modern:"Household care, marriage, family responsibility, foresight, grief, and protection of kin.",
 caution:"Frigg and Freyja share some similarities but should not simply be declared the same goddess as an established fact."},
 {name:"Freyja",alt:"Freyja",group:"Vanir",icon:"🐈",
 roles:"Love, desire, wealth, seiðr, battle/death associations and high status among the goddesses.",
 sources:"Poetic Edda, Prose Edda and skaldic kennings. Grímnismál associates her with Fólkvangr and a share of the slain.",
 myths:"Possesses Brísingamen in later source tradition; lends a feather garment in Eddic stories; searches for her absent husband Óðr and weeps precious tears in Snorri’s account.",
 symbols:"Brísingamen, cats/chariot, falcon or feather garment, boar Hildisvíni in Hyndluljóð.",
 modern:"Love, self-worth, beauty, seiðr study, grief, courage, sexuality, wealth and independence are common modern themes.",
 caution:"Some popular internet claims about Freyja are modern synthesis. Sacred Year separates source-attested traits from devotional interpretation."},
 {name:"Freyr",alt:"Freyr • Yngvi-Freyr • Ing connections",group:"Vanir",icon:"🐗",
 roles:"Peace, prosperity, good seasons, fertility, rain/sunshine and sacral kingship associations.",
 sources:"Poetic Edda, especially Skírnismál and Lokasenna; Prose Edda; Ynglinga saga; place-name and cult evidence.",
 myths:"Falls in love with Gerðr after seeing her from Hliðskjálf and sends Skírnir to woo her. Gives up his sword, contributing to his vulnerability at Ragnarök.",
 symbols:"Boar Gullinbursti, ship Skíðblaðnir, fertility imagery; association with Ing/Yngvi requires careful regional/contextual treatment.",
 modern:"Harvest gratitude, peace, prosperity, land care, fertility, generosity and good seasons.",
 caution:"Modern Freyfaxi celebrations are not proof of one fixed ancient festival calendar."},
 {name:"Njörðr",alt:"Njörðr",group:"Vanir",icon:"⛵",
 roles:"Sea travel, ships, fishing, wealth and prosperity.",
 sources:"Poetic Edda, Prose Edda and Ynglinga saga. Lokasenna remembers his hostage exchange between Vanir and Æsir.",
 myths:"Marries Skaði after she chooses a husband by looking only at the gods’ feet. Their incompatible homes—sea-side Nóatún and mountain Þrymheimr—make the marriage difficult.",
 symbols:"Ships, sea, harbors and maritime wealth.",
 modern:"Safe travel, livelihood, fishing, trade, prosperity and gratitude for the sea.",
 caution:"Njörðr is not simply a generic 'ocean god'; Ægir and Rán occupy different maritime roles in the literary tradition."},
 {name:"Skaði",alt:"Skaði • Skadi",group:"Jötunn / divine figure",icon:"🏔️",
 roles:"Mountains, skiing, hunting, winter and fierce independence.",
 sources:"Poetic Edda and Prose Edda, including material about her father Þjazi and marriage to Njörðr.",
 myths:"Comes armed to the gods seeking compensation for Þjazi’s death and receives a husband-choice settlement. Her preference for the mountains clashes with Njörðr’s sea home.",
 symbols:"Skis, bow, mountains, winter hunting.",
 modern:"Winter endurance, independence, wilderness, hunting ethics, mountains and resilience.",
 caution:"Calling Skaði simply an Æsir goddess can erase the jötunn ancestry that is central to her surviving story."},
 {name:"Heimdallr",alt:"Heimdallr",group:"Æsir",icon:"📯",
 roles:"Watchman of the gods, boundary guardian and Ragnarök herald.",
 sources:"Poetic Edda including Völuspá and Rígsþula traditions; Prose Edda.",
 myths:"Guards Bifröst and will sound Gjallarhorn at Ragnarök. Snorri gives extraordinary senses and describes him as born of nine mothers.",
 symbols:"Gjallarhorn, Bifröst, watchfulness.",
 modern:"Vigilance, boundaries, guardianship and responsible watchfulness.",
 caution:"The identification of Heimdallr with Rígr is traditional scholarly interpretation but Rígsþula itself names Rígr."},
 {name:"Hel",alt:"Hel",group:"Jötunn-descended divine being",icon:"🕯️",
 roles:"Ruler of the realm Hel and receiver of many of the dead who do not die in battle.",
 sources:"Poetic Edda and Prose Edda, especially Baldr material and Snorri’s account of Loki’s children.",
 myths:"Baldr comes to her realm after his death. She agrees he may return if all things weep for him; the condition is not fulfilled.",
 symbols:"The realm Hel itself is primary. Modern half-black/half-flesh imagery derives especially from Snorri’s description.",
 modern:"Death, remembrance, grief, acceptance and honoring the dead.",
 caution:"Hel is not the Norse equivalent of a Christian devil, and her realm should not automatically be equated with Christian Hell."},
 {name:"Baldr",alt:"Baldr • Balder",group:"Æsir",icon:"☀️",
 roles:"Beloved divine figure associated in the sources with beauty, goodness and the central myth of death and return after Ragnarök.",
 sources:"Poetic Edda and Prose Edda; Saxo preserves a substantially different Balder tradition.",
 myths:"Killed by Höðr with mistletoe through Loki’s orchestration in Snorri’s version. After Ragnarök, Völuspá foretells Baldr and Höðr returning.",
 symbols:"Mistletoe is the strongest narrative symbol; solar imagery is popular but should not be treated as a securely attested ancient emblem.",
 modern:"Hope, grief, reconciliation, beauty, renewal and remembrance.",
 caution:"Calling Baldr straightforwardly a 'sun god' or 'resurrection god' is an interpretation, not a simple statement of the surviving sources."},
 {name:"Ullr",alt:"Ullr • Wuldor (possible cognate)",group:"Æsir",icon:"🏹",
 roles:"Archery, skiing and oath-related associations.",
 sources:"Poetic Edda, Prose Edda, place-name evidence; the Old English name Wuldor is sometimes discussed comparatively.",
 myths:"Few narrative myths survive, despite strong place-name evidence suggesting Ullr once had substantial cultic importance.",
 symbols:"Bow, skis, shield; oath-ring association appears in Atlakviða.",
 modern:"Archery, winter travel, skill, oaths and disciplined outdoor practice.",
 caution:"The lack of surviving stories does not necessarily imply historical insignificance."}
,
 {name:"Loki",alt:"Loki • Loptr",group:"MYTHOLOGICALLY PROMINENT",icon:"🔥",
 roles:"Trickery, transformation, boundary-crossing, conflict, cleverness, and disruptive change in the literary tradition.",
 sources:"Poetic Edda including Lokasenna and Þrymskviða; Prose Edda; skaldic references. Literary importance is extensive, while direct evidence for widespread historical cult is comparatively limited.",
 myths:"Lokasenna states a blood-brother relationship with Odin. Loki fathers Fenrir, Jörmungandr, and Hel with Angrboða and becomes the mother of Sleipnir after taking mare form. Snorri makes him central to Baldr’s death.",
 symbols:"No single securely attested cult symbol comparable to Mjölnir. Fire is a popular modern association, not a securely established ancient emblem.",
 modern:"Adaptability, confronting hypocrisy, navigating change, wit, and reflecting on the consequences of disruptive action.",
 caution:"Loki is extremely important in surviving mythology, but evidence for an organized historical cult is much thinner than for Thor, Odin, or Freyr."},
 {name:"Ēostre / Ostara",alt:"Ēostre • Ostara",group:"LIMITED ATTESTATION / RECONSTRUCTED",icon:"🌅",
 roles:"Spring and seasonal renewal are common modern associations; surviving historical evidence is limited.",
 sources:"Bede’s De temporum ratione records a goddess Ēostre and Eosturmonath. Jacob Grimm later proposed the German form Ostara by linguistic reconstruction.",
 myths:"No surviving myth cycle comparable to Thor or Odin is preserved. Detailed modern stories and practices largely come from reconstruction, later folklore, and modern Paganism.",
 symbols:"Dawn, spring flowers, eggs, hares, and rabbits are common modern imagery; they should not all be presented as securely attested ancient cult symbols.",
 modern:"Spring renewal, dawn observances, household cleansing, planting, fertility, and seasonal transition.",
 caution:"Ēostre has limited historical attestation through Bede; the richly detailed Ostara tradition familiar today is substantially reconstructed or modern."},
 {name:"Nerthus",alt:"Nerthus • Terra Mater",group:"CONTINENTAL GERMANIC",icon:"🌿",
 roles:"Earth, fertility, peace, sacred procession, land, and communal renewal.",
 sources:"Tacitus, Germania chapter 40, describes Nerthus as Terra Mater ('Mother Earth') and reports shared worship among several Germanic peoples.",
 myths:"Tacitus describes a sacred grove, a veiled wagon drawn by cattle, a ceremonial procession during which weapons are put away, and ritual washing of the goddess, wagon, and coverings in a secluded lake.",
 symbols:"Sacred wagon, cattle, grove, water, earth, and fertile land.",
 modern:"Land stewardship, seasonal fertility, peace, gratitude to the earth, procession, and respectful offerings to land and waters.",
 caution:"Tacitus was a Roman outsider. His account is invaluable evidence but should not be treated as a complete native Germanic theology."}
];

function syGodCard(g){
 return `<button class="section-card god-card-v122" onclick="syOpenGod('${g.name.replaceAll("'","\\'")}')"><div class="god-icon">${g.icon}</div><div class="god-name">${g.name}</div><div class="god-alt">${g.alt}</div><div class="kicker god-group">${g.group}</div></button>`;
}
function syOpenGodsHall(){
 openDrawer(`<div class="kicker">Gods & Powers</div><h3>The Germanic/Norse Gods</h3>
 <p class="note">Names, myths and cults varied by time and region. Sacred Year distinguishes source evidence from modern devotional practice.</p>
 <div class="section-nav">${SY_GODS.map(syGodCard).join("")}</div>`);
}
function syOpenGod(name){
 const g=SY_GODS.find(x=>x.name===name);if(!g)return;
 openDrawer(`<div class="kicker">${g.group}</div><h3>${g.icon} ${g.name}</h3><p class="note">${g.alt}</p>
 <div class="item"><h4>Historical associations</h4><p>${g.roles}</p></div>
 <div class="item" style="margin-top:10px"><h4>Major surviving stories</h4><p>${g.myths}</p></div>
 <div class="item" style="margin-top:10px"><h4>Symbols & imagery</h4><p>${g.symbols}</p></div>
 <div class="item" style="margin-top:10px"><h4>Primary source trail</h4><p>${g.sources}</p></div>
 <div class="item" style="margin-top:10px"><h4>Modern devotional ideas</h4><p>${g.modern}</p></div>
 <div class="holiday" style="margin-top:10px"><div class="kicker">Evidence note</div><p>${g.caution}</p></div>
 <button class="btn secondary" onclick="syOpenGodsHall()">Back to Gods</button>`);
}
window.syOpenGodsHall=syOpenGodsHall;
window.syOpenGod=syOpenGod;
