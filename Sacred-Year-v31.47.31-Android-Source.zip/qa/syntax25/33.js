
(function(){
 async function ss(){if(!window.sySupabase)throw Error("Account service unavailable");const {data:{session}}=await sySupabase.auth.getSession();if(!session)throw Error("Please sign in first.");return session}
 async function uid(label){let q=(label||"").trim();if(/^[0-9a-f-]{36}$/i.test(q))return q;const {data,error}=await sySupabase.from("profiles").select("id,display_name").ilike("display_name",q).limit(2);if(error)throw error;if(!data?.length)return null;if(data.length>1)throw Error("More than one user has that name.");return data[0].id}
 window.sy314SubmitReport=async function(){let type=sy314Type.value,target=sy314Target.value.trim(),details=sy314Details.value.trim();if(!target||!details){alert("Please identify what you are reporting and describe what happened.");return}try{const form=document.getElementById("sy314Report");let x=await ss(),tu=form?.dataset?.targetUserId||null,te=null,ck=form?.dataset?.communityKind||null,cid=form?.dataset?.communityId||null;if(ck&&cid){const row={reporter_id:x.user.id,reason:details.trim()};if(ck==="post")row.post_id=cid;else row.reply_id=cid;const {error}=await window.sySupabase.from("community_reports").insert(row);if(error)throw error;delete form.dataset.communityKind;delete form.dataset.communityId;sy314CloseReport();alert("Report submitted. Sacred Year will review the concern.");return}if(!tu&&["User","Harassment","Fraud or scam"].includes(type)){try{tu=await uid(target)}catch(e){}}if(type==="Event"&&/^[0-9a-f-]{36}$/i.test(target))te=target;let {error}=await sySupabase.from("moderation_reports").insert({reporter_id:x.user.id,report_type:type,target_label:target,target_user_id:tu,target_event_id:te,details,status:"submitted"});if(error)throw error;sy314CloseReport();alert("Report submitted to Sacred Year moderation.")}catch(e){alert(e.message||"Could not submit report.")}};
 window.sy314BlockUser=async function(label,id){
 if(id){
   const name=(label||"this member").trim();
   if(window.syCommunityBlockUser){await syCommunityBlockUser(id,name);return}
 }
 const modal=document.getElementById("sy320BlockFind");
 const input=document.getElementById("sy320BlockName");
 const go=document.getElementById("sy320FindBlock");
 const cancel=document.getElementById("sy320CancelBlockFind");
 if(!modal||!input||!go||!cancel){alert("Block controls are unavailable. Please refresh and try again.");return}
 input.value=(label||"").trim();
 modal.classList.add("open");
 setTimeout(()=>input.focus(),50);
 const close=()=>modal.classList.remove("open");
 cancel.onclick=close;
 go.onclick=async()=>{
   const name=input.value.trim();
   if(!name){alert("Enter the member's display name.");return}
   go.disabled=true;go.textContent="Finding…";
   try{
     let x=await ss(),blocked=await uid(name);
     if(!blocked)throw Error("We couldn't find that user.");
     if(blocked===x.user.id)throw Error("You can't block your own account.");
     close();
     if(window.syCommunityBlockUser){
       await syCommunityBlockUser(blocked,name);
     }else{
       let {error}=await sySupabase.from("user_blocks").upsert(
         {blocker_id:x.user.id,blocked_user_id:blocked},
         {onConflict:"blocker_id,blocked_user_id",ignoreDuplicates:true}
       );
       if(error)throw error;
       alert(name+" has been blocked.");
     }
   }catch(e){alert(e.message||"Could not find that member.");}
   finally{go.disabled=false;go.textContent="Continue";}
 };
};
 window.sy314RecordConsent=async function(kind,version){
 const syAccountScope=window.sy25Scope();
let at=new Date().toISOString(),v=version||"2026-08-17";try{let x=await window.sy25Await((window.sy25Assert(syAccountScope), (ss())),syAccountScope);await window.sy25Await((window.sy25Assert(syAccountScope), (sySupabase.from("legal_consents").upsert({user_id:x.user.id,consent_type:kind,version:v,accepted_at:at},{onConflict:"user_id,consent_type"}))),syAccountScope)}catch(e){}};
 window.sy315RecordLegalAcceptance=async function(){
 const syAccountScope=window.sy25Scope();
let at=new Date().toISOString();try{let x=await window.sy25Await((window.sy25Assert(syAccountScope), (ss())),syAccountScope);for(let kind of ["terms","privacy"]){let {error}=await window.sy25Await((window.sy25Assert(syAccountScope), (sySupabase.from("legal_consents").upsert({user_id:x.user.id,consent_type:kind,version:"2026-08-17",accepted_at:at},{onConflict:"user_id,consent_type"}))),syAccountScope);if(error)throw error}}catch(e){}};
 window.sy316Rsvp=async function(eventId,status){
 const syAccountScope=window.sy25Scope();
let x=await window.sy25Await((window.sy25Assert(syAccountScope), (ss())),syAccountScope);return new Promise((resolve,reject)=>sy313AttendeeAgreement(async()=>{try{let at=new Date().toISOString();let {error}=await sySupabase.from("community_event_rsvps").upsert({event_id:eventId,user_id:x.user.id,status:status||"going",age_18_attested_at:at},{onConflict:"event_id,user_id"});if(error)throw error;await sy314RecordConsent("event_attendee","2026-08-17");resolve(true)}catch(e){alert(e.message||"Could not RSVP.");reject(e)}}))};
 window.sy316SubmitEvent=async function(eventData){
 const syAccountScope=window.sy25Scope();
let x=await window.sy25Await((window.sy25Assert(syAccountScope), (ss())),syAccountScope);return new Promise((resolve,reject)=>sy313OrganizerAgreement(async()=>{try{let at=new Date().toISOString(),payload=Object.assign({},eventData,{creator_id:x.user.id,status:"pending",organizer_type:"community",age_18_attested_at:at});let {data,error}=await sySupabase.from("community_events").insert(payload).select("id").single();if(error)throw error;await sy314RecordConsent("event_organizer","2026-08-17");resolve(data)}catch(e){alert(e.message||"Could not submit event.");reject(e)}}))};
})();
