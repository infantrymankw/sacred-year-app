
const SY28_RITUALS={
 daily:{
  name:"Five-Minute Daily Practice",level:"Modern devotional practice",
  why:"A simple way to build consistency without pretending there was one ancient daily liturgy.",
  steps:["Pause somewhere quiet.","Name one thing you are grateful for.","Address a god, ancestor, land spirit, or simply your own values if that fits your practice.","Offer water, bread, grain, or another modest item if desired.","State one intention for your conduct today.","Close clearly with thanks."],
  history:"No standardized daily Norse pagan prayer book survives. This format is intentionally modern and minimalist.",
  caution:"You do not have to perform ritual every day to be a serious practitioner."
 },
 blot:{
  name:"Blót",level:"Historically rooted / modern reconstruction",
  why:"A structured offering rite inspired by historical sacrificial practice.",
  steps:["Clean the space and decide who or what you are honoring.","State your purpose plainly.","Address the deity, ancestors, or land powers respectfully.","Present a modest offering such as food, drink, flowers, or incense.","Pause for reflection.","Close with thanks and dispose of the offering responsibly."],
  history:"Historical blót could involve communal feasting, animal sacrifice, and other offerings. Modern household blót commonly uses symbolic or food/drink offerings instead.",
  caution:"This is a modern safe household form, not a claim to reproduce one universal Viking-age rite."
 },
 ancestor:{
  name:"Ancestor Remembrance",level:"Historically rooted / modern household rite",
  why:"A simple way to remember family, kin, and those whose lives shaped yours.",
  steps:["Place a photograph, name, heirloom, or other reminder.","Light a candle if safe.","Say the person's name.","Tell one true memory or lesson.","Offer food or drink if meaningful.","Close by saying they are remembered."],
  history:"Kinship, burial, memorial practices, and care for the dead were deeply important in Germanic societies, but one standardized domestic ancestor liturgy does not survive.",
  caution:"Candles, photographs, and modern memorial scripts are modern tools."
 },
 hearth:{
  name:"Hearth & Home Practice",level:"Modern reconstruction with historical inspiration",
  why:"Centers the household as a place of responsibility, hospitality, and protection.",
  steps:["Clean the home or a small ritual area.","Light a candle or hearth-safe flame if desired.","Name the values you want your household to embody.","Offer thanks for shelter, food, and those who share the space.","If you honor Thor, Frigg, ancestors, or household powers, address them respectfully.","Close at the doorway or hearth."],
  history:"Historical Germanic religion was deeply embedded in household and community life, but a single preserved 'hearth ritual' does not survive.",
  caution:"The point is household responsibility and hospitality, not pretending every modern candle ritual is ancient."
 },
 land:{
  name:"Land / Local Spirit Offering",level:"Historically inspired / modern practice",
  why:"Encourages gratitude and stewardship toward the place where you live.",
  steps:["Learn something about the local land and ecology.","Choose a wildlife-safe offering such as water or native flowers.","State gratitude for the place.","Give the offering without leaving trash or harmful food.","Commit to one act of stewardship such as litter cleanup or planting native species.","Close with thanks."],
  history:"Landvættir and place-linked beings appear in Old Norse material, while local spirit traditions vary greatly across time and region.",
  caution:"Do not leave alcohol, salt, plastic, processed foods, or anything harmful to wildlife."
 },
 sumbel:{
  name:"Sumbel",level:"Historically inspired / modern Heathen form",
  why:"A group practice of toasting, remembrance, and meaningful speech.",
  steps:["Agree that everyone may pass and no one is pressured to drink alcohol.","First round: honor gods or sacred powers.","Second round: honor ancestors or admired people.","Third round: speak gratitude, a boast, a hope, or a carefully considered commitment.","Treat serious oaths as serious.","Close with fellowship."],
  history:"Germanic literature preserves feasting, drinking, boasting, remembrance, and oath-making. The standardized modern three-round sumbel is a reconstruction.",
  caution:"Water, juice, tea, or any non-alcoholic drink works perfectly well."
 },
 offering:{
  name:"Simple Offering",level:"Modern beginner practice",
  why:"A low-pressure way for beginners to practice without elaborate ritual.",
  steps:["Choose a modest offering.","State who or what it is for.","Say why you are giving it.","Leave or dispose of it responsibly.","Close with thanks."],
  history:"Offering and sacrifice are strongly attested in Germanic religion, but modern household offering formats are simplified reconstructions.",
  caution:"Do not give more than you can afford, and do not use offerings as a way to bargain with certainty for supernatural outcomes."
 },
 seasonal:{
  name:"Seasonal Rite",level:"Modern framework using attested seasonal themes",
  why:"Lets the calendar shape practice without pretending every date has a surviving script.",
  steps:["Name the season or observance.","Read the app's historical note for that holiday.","Choose one historically grounded theme: harvest, winter preparation, remembrance, good seasons, victory, or hospitality.","Make a modest offering or share a meal.","Reflect on what the season asks of you.","Close with thanks."],
  history:"Seasonal sacrifice and feasting are well attested, but exact rituals and dates often vary or are poorly preserved.",
  caution:"Use Sacred Year's evidence labels so reconstruction stays transparent."
 }
};

function sy28RitualHall(){
 const ids=["daily","offering","blot","ancestor","hearth","land","sumbel","seasonal"];
 openDrawer(`<div class="kicker">Ritual Hall</div><h3>Everyday Practice</h3>
 <p class="note">Start simple. You do not need expensive tools, a perfect altar, or elaborate scripts. Sacred Year separates historical evidence from modern devotional forms so you always know which is which.</p>
 <div class="sy28-grid">${ids.map(id=>{const r=SY28_RITUALS[id];return `<button class="sy28-card" onclick="sy28OpenRitual('${id}')"><span class="sy28-level">${r.level}</span><h4>${r.name}</h4><p>${r.why}</p></button>`}).join("")}</div>
 <div class="holiday" style="margin-top:12px"><div class="kicker">Beginner rule</div><p><b>Consistency matters more than complexity.</b> A glass of water and sincere thanks can be more meaningful than buying a pile of ritual objects.</p></div>`);
}
function sy28OpenRitual(id){
 const r=SY28_RITUALS[id];if(!r)return;
 openDrawer(`<div class="kicker">Ritual Hall</div><h3>${r.name}</h3><span class="sy28-level">${r.level}</span>
 <div class="item" style="margin-top:10px"><h4>Why use it?</h4><p>${r.why}</p></div>
 <div class="item" style="margin-top:10px"><h4>Step by step</h4>${r.steps.map((s,i)=>`<div class="sy28-step"><h4>${i+1}. ${s}</h4></div>`).join("")}</div>
 <div class="item" style="margin-top:10px"><h4>Historical context</h4><p>${r.history}</p></div>
 <div class="holiday" style="margin-top:10px"><div class="kicker">Practice note</div><p class="sy28-note">${r.caution}</p></div>
 <div class="row"><button class="btn secondary" onclick="sy28RitualHall()">Back to Ritual Hall</button></div>`);
}
function sy28SaveRitual(id){
 const arr=JSON.parse(syLocalStorage.getItem("sy28_saved_rituals")||"[]");
 if(!arr.includes(id))arr.push(id);
 syLocalStorage.setItem("sy28_saved_rituals",JSON.stringify(arr));
 alert("Ritual saved.");
}
window.sy28RitualHall=sy28RitualHall;window.sy28OpenRitual=sy28OpenRitual;window.sy28SaveRitual=sy28SaveRitual;
setTimeout(()=>{
 for(const b of document.querySelectorAll("button,.section-card")){
   const t=(b.textContent||"").trim();
   if(/ritual hall|everyday practice/i.test(t)){b.onclick=sy28RitualHall;}
 }
},800);
