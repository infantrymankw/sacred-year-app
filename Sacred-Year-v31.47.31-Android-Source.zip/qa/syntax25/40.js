
(function(){
  function sheetText(){
    return (document.getElementById("sheet")?.innerText||"").trim();
  }

  window.sy324Backdrop=function(){
    const t=sheetText();

    // Hall+ nested tools return to the Hall+ tools menu.
    if(t.includes("Hall+ • Voices of the Hall") || t.includes("Back to Hall+") || t.includes("Hall+ · Advanced Journal") ||
       t.includes("Hall+ · Advanced Reminders") ||
       t.includes("Hall+ · Guided Study") ||
       t.includes("Hall+ · Event Studio") ||
       t.includes("Hall+ · Divination")){
      window.syOpenHallPlus?.();
      return;
    }

    // Deep creator moderation screens return to Moderation Center.
    if(t.includes("Open Reports") ||
       t.includes("Posts & Replies") ||
       t.includes("Event Moderation") ||
       t.includes("User Restrictions") ||
       t.includes("Audit Trail")){
      window.sy321ModerationHome?.();
      return;
    }

    // Creator content/editor/publisher and the Moderation Center return to Creator Control Center.
    if(t.includes("Manage Published Content") ||
       t.includes("Edit Published Content") ||
       t.includes("Words from the Hall") ||
       t.includes("Moderation Center")){
      window.syOpenCreator?.();
      return;
    }

    // Hall+ menu, Creator Control Center, Account, and ordinary sheets close normally.
    closeDrawer();
  };

  // Add explicit Back-to-Hall+ buttons to Hall+ nested tools after they render.
  const hallFns=["sy307Journal","sy307Reminders","sy307Study","sy307Events","sy307Divination"];
  hallFns.forEach(name=>{
    const original=window[name];
    if(!original)return;
    window[name]=async function(...args){
      const result=await original.apply(this,args);
      requestAnimationFrame(()=>{
        const sheet=document.getElementById("sheet");
        if(!sheet || sheet.querySelector(".sy324-hall-back"))return;
        const b=document.createElement("button");
        b.className="btn secondary sy324-hall-back";
        b.style.marginTop="14px";
        // v31.47.13: keep the final Hall+ return control fully above the fixed bottom navigation.
        b.style.marginBottom="calc(88px + env(safe-area-inset-bottom, 0px))";
        b.textContent="Back to Hall+";
        b.onclick=()=>window.syOpenHallPlus?.();
        sheet.appendChild(b);
      });
      return result;
    };
  });
})();
