
(function(){
const VAPID_PUBLIC_KEY='BH0NOSwO1XWgg1_jf2xeamMKDpFGcyx2WXHAWAq8kxQOKD4T7QyAhQAAV4jaLMN3Mv0SW1jEsjWwgxEGBIWLY4E';
function b64urlToUint8(s){const pad='='.repeat((4-s.length%4)%4),b=(s+pad).replace(/-/g,'+').replace(/_/g,'/'),raw=atob(b);return Uint8Array.from([...raw].map(c=>c.charCodeAt(0)))}
async function syRegisterPush(){
 if(window.Capacitor?.isNativePlatform?.())return false;
 if(!('serviceWorker'in navigator)||!('PushManager'in window)||!('Notification'in window)) throw new Error('Background notifications are not supported by this browser.');
 if(Notification.permission!=='granted') throw new Error('Notification permission is not granted.');
 const sb=window.sySupabase;if(!sb) throw new Error('Sacred Year is still loading. Try again in a moment.');
 const {data:{session}}=await sb.auth.getSession();if(!session?.user) throw new Error('Sign in first so this device can receive your reminders.');
 const reg=await navigator.serviceWorker.ready;
 let sub=await reg.pushManager.getSubscription();
 if(!sub) sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:b64urlToUint8(VAPID_PUBLIC_KEY)});
 const j=sub.toJSON();
 const {error}=await sb.rpc('claim_sacred_year_push_subscription',{
   p_endpoint:j.endpoint,
   p_p256dh:j.keys?.p256dh,
   p_auth:j.keys?.auth,
   p_user_agent:navigator.userAgent
 });
 if(error) throw error;
 return true;
}
async function enable(){
 if(window.Capacitor?.isNativePlatform?.()){if(window.syNativeEnableNotifications)return window.syNativeEnableNotifications();alert('Android notifications are still loading. Close and reopen Sacred Year, then try again.');return;}
 try{if(!('Notification'in window)){alert('This browser does not support notifications.');return}let p=Notification.permission;if(p!=='granted')p=await Notification.requestPermission();if(p!=='granted'){alert('Notification permission was not granted.');return}await syRegisterPush();alert('Background reminders are enabled on this device. Sacred Year can now send scheduled alerts even when the app is closed.');}catch(e){console.error(e);alert(e?.message||'Could not enable background reminders on this device.');}
}
window.syEnableNotifications=enable;window.sy307RequestNotifications=enable;window.syRegisterPush=syRegisterPush;
window.addEventListener('load',()=>setTimeout(()=>{if(typeof Notification!=='undefined'&&Notification.permission==='granted')syRegisterPush().catch(()=>{});},2500));
})();
