
function syTodayRefresh(){
 try{
   if(typeof SY_HOLIDAYS!=="undefined"){
     const sorted=[...SY_HOLIDAYS].sort((a,b)=>syNextDate(a)-syNextDate(b));
     const h=sorted[0];
     if(h){
       const n=document.getElementById("todayNextHoliday"),d=document.getElementById("todayNextHolidayDate");
       if(n)n.textContent=h.name;
       if(d)d.textContent=`${syCalendarDateLabel(h)?syCalendarDateLabel(h)+" • Next: ":""}${syNextDate(h).toLocaleDateString(undefined,{month:"long",day:"numeric"})} • ${Math.max(0,syDays(syNextDate(h)))} days`;
     }
   }
   if(typeof syMoonData==="function"){
     const m=syMoonData();
     const p=document.getElementById("todayMoonPhase"),i=document.getElementById("todayMoonIllumination");
     if(p)p.textContent=`${m.phase.glyph} ${m.phase.name}`;
     if(i)i.textContent=`${Math.round(m.illum*100)}% illuminated`;
   }
 }catch(e){}
}
setTimeout(syTodayRefresh,500);
setInterval(syTodayRefresh,3600000);

async function syOpenAccountV15(){
 let user=null,profile=null;
 try{
   if(window.sySupabase){
     const {data:{session}}=await window.sySupabase.auth.getSession();
     user=session?.user||null;
     if(user){
       const {data}=await window.sySupabase.from("profiles").select("display_name,role").eq("id",user.id).maybeSingle();
       profile=data||null;
     }
   }
 }catch(e){}

 if(!user){
   if(typeof window.syOpenAccount==="function") return window.syOpenAccount();
   if(typeof window.cloudAccount==="function") return window.cloudAccount();
   return openDrawer(`<div class="kicker">Sacred Year Account</div><h3>Account temporarily unavailable</h3><p class="note">The live account service did not initialize. Refresh the hosted app and try again.</p>`);
 }

 const creator=profile?.role==="creator";
 openDrawer(`<div class="kicker">${creator?"Creator Account":"My Account"}</div>
   <h3>${syEsc?syEsc(profile?.display_name||user.email):(profile?.display_name||user.email)}</h3>
   <div class="profile-chip">${creator?"Creator":"Member"}</div>
   <div class="account-grid" style="margin-top:14px">
     <button class="account-card" onclick="${creator?"syOpenCreator()":"syOpenPreferences()"}"><h4>${creator?"Creator Dashboard":"Practice Settings"}</h4><p>${creator?"Publish Words from the Hall":"Tradition and notification preferences"}</p></button>
     <button class="account-card" onclick="syOpenPreferences()"><h4>Preferences</h4><p>Holidays, moon, rituals, and Hall messages</p></button>
     <button class="account-card" onclick="showView('library');closeDrawer()"><h4>Reading</h4><p>Bookmarks, notes, and favorites</p></button>
     <button class="account-card" onclick="showView('runes');closeDrawer()"><h4>Rune Practice</h4><p>Saved rune and journal</p></button>
   </div>
   <div class="holiday" style="margin-top:12px">
     <div class="kicker">Account status</div>
     <p>Cloud sync is active for supported account features in the hosted version.</p>
   </div>
   <button class="btn danger" style="margin-top:10px" onclick="cloudSignOut?cloudSignOut():sySignOut?sySignOut():syDirectLogout()">Sign out</button>`);
}
window.openAccount=syOpenAccountV15;

async function syOpenNotificationsV15(){
 const syAccountScope=window.sy25Scope();

 let posts=[];
 try{if(typeof syFetchPosts==="function")posts=await window.sy25Await((window.sy25Assert(syAccountScope), (syFetchPosts())),syAccountScope)}catch(e){}
 const settingsText=typeof Notification!=="undefined"?`Browser notification permission: <b>${Notification.permission}</b>`:"Browser notifications unavailable";
 openDrawer(`<div class="kicker">Notification Center</div><h3>From the Hall</h3>
   <div class="holiday"><p>${settingsText}</p>
   <button class="btn secondary" onclick="syEnableNotifications()">Enable browser alerts</button>
   <button class="btn secondary" onclick="syOpenNotificationSettings()">Notification settings</button></div>
   <div class="note-list" style="margin-top:12px">${posts.map(p=>`<div class="note-card"><div class="kicker">${p.label||"Words from the Hall"}</div><h4>${p.title||"Words from the Hall"}</h4><p>${p.message}</p><div class="note">${syDisplayDate(p.published_at)}</div></div>`).join("")||'<p class="note">No messages yet.</p>'}</div>
   <p class="note">Browser notification permission can be enabled here. Creator posts can request push delivery through the Sacred Year service. Community replies and recording questions remain in Activity when the app syncs.</p>`);
}
window.syOpenNotifications=syOpenNotificationsV15;
