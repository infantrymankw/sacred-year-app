
(function(){
const e=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
window.sy322CreatorPosts=async function(){
  await syGetSession();
  if(syProfile?.role!=="creator"){alert("Creator access is not enabled for this account.");return}
  const {data,error}=await supabase.from("creator_posts").select("*").order("published_at",{ascending:false}).limit(100);
  if(error){alert(error.message);return}
  openDrawer(`<div class="kicker">Creator Content</div><h3>Manage Published Content</h3>
  <p class="note">Edit or remove your published Words from the Hall content.</p>
  <div class="sy321-list">${(data||[]).map(p=>`<div class="sy321-item">
    <div class="kicker">${e(p.label||"Words from the Hall")} • ${e(p.status||"published")}</div>
    <h4>${e(p.title||"Words from the Hall")}</h4>
    <p>${e(p.message||"")}</p>
    <div class="sy321-meta">${p.published_at?syDisplayDate(p.published_at):""}</div>
    <div class="sy321-actions">
      <button class="btn secondary" onclick="sy322EditCreatorPost('${p.id}')">Edit</button>
      <button class="btn secondary sy321-danger" onclick="sy322DeleteCreatorPost('${p.id}')">Delete</button>
    </div>
  </div>`).join("")||'<p class="sy321-empty">No published creator content yet.</p>'}</div>
  <button class="btn secondary" style="margin-top:14px" onclick="syOpenCreator()">Back to Creator Dashboard</button>`);
};
window.sy322EditCreatorPost=async function(id){
  const {data:p,error}=await supabase.from("creator_posts").select("*").eq("id",id).single();
  if(error){alert(error.message);return}
  openDrawer(`<div class="kicker">Creator Content</div><h3>Edit Published Content</h3>
    <label>Title</label><input id="sy322Title" value="${e(p.title||"")}">
    <label>Message</label><textarea id="sy322Message" rows="8">${e(p.message||"")}</textarea>
    <label>Label</label><select id="sy322Label">
      ${["AlanWolfsie Reflection","Modern Practice","Historical Note","Announcement"].map(x=>`<option ${x===p.label?"selected":""}>${x}</option>`).join("")}
    </select>
    <button class="btn" style="margin-top:14px" onclick="sy322SaveCreatorPost('${id}')">Save changes</button>
    <button class="btn secondary" style="margin-top:10px" onclick="sy322CreatorPosts()">Cancel</button>`);
};
window.sy322SaveCreatorPost=async function(id){
  const title=document.getElementById("sy322Title").value.trim();
  const message=document.getElementById("sy322Message").value.trim();
  const label=document.getElementById("sy322Label").value;
  if(!message){alert("Message cannot be empty.");return}
  const {error}=await supabase.from("creator_posts").update({title:title||"Words from the Hall",message,label}).eq("id",id);
  if(error){alert(error.message);return}
  alert("Published content updated.");
  await syLoadWord?.();
  sy322CreatorPosts();
};
window.sy322DeleteCreatorPost=async function(id){
  if(!confirm("Delete this published Sacred Year post? This cannot be undone."))return;
  const {error}=await supabase.from("creator_posts").delete().eq("id",id);
  if(error){alert(error.message);return}
  alert("Published content removed.");
  await syLoadWord?.();
  sy322CreatorPosts();
};
})();
