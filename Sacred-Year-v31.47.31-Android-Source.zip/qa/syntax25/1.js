
// v31.47.15: preserve password-recovery intent for legacy recovery links.
(function(){
  try{
    const raw=(location.search||"")+"&"+(location.hash||"");
    if(/(?:^|[?#&])type=recovery(?:&|$)/i.test(raw)) sessionStorage.setItem("sy_password_recovery_pending","1");
  }catch(_){}
})();
