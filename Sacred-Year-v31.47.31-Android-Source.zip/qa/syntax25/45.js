
(function(){
  const c=()=>window.sySupabase||window.supabase;

  window.syOpenNotifications=async function(){
 const syAccountScope=window.sy25Scope();

    let posts=[];
    try{ if(typeof syFetchPosts==="function") posts=await window.sy25Await((window.sy25Assert(syAccountScope), (syFetchPosts())),syAccountScope); }catch(e){}
    const permission=typeof Notification!=="undefined"?Notification.permission:"unavailable";
    openDrawer(`<div class="kicker">Notification Center</div><h3>From the Hall</h3>
      <div class="holiday">
        <p>Browser notification permission: <b>${permission}</b></p>
        <div class="row">
          <button type="button" class="btn secondary" id="sy329EnableAlerts">Enable browser alerts</button>
          <button type="button" class="btn secondary" id="sy329NotifSettings">Notification settings</button>
        </div>
      </div>
      <div class="note-list" style="margin-top:12px">${posts.map(p=>`<div class="note-card"><div class="kicker">${p.label||"Words from the Hall"}</div><h4>${p.title||"Words from the Hall"}</h4><p>${p.message}</p><div class="note">${syDisplayDate(p.published_at)}</div></div>`).join("")||'<p class="note">No messages yet.</p>'}</div>
      <p class="note">Browser notification permission can be enabled here. Creator posts can request push delivery through the Sacred Year service. Community replies and recording questions remain in Activity when the app syncs.</p>
      <button type="button" class="btn secondary" id="sy329BackHome" style="margin-top:14px;width:100%">Back to Sacred Year</button>`);
    requestAnimationFrame(()=>{
      document.getElementById("sy329EnableAlerts")?.addEventListener("click",()=>window.syEnableNotifications?.());
      document.getElementById("sy329NotifSettings")?.addEventListener("click",()=>window.syOpenNotificationSettings?.());
      document.getElementById("sy329BackHome")?.addEventListener("click",()=>closeDrawer());
    });
    if(posts[0]){
      try{
        syLastSeen=posts[0].published_at;
        syLocalStorage.setItem("sy_last_seen_post",syLastSeen);
        const n=document.getElementById("notifCount");
        if(n)n.style.display="none";
      }catch(e){}
    }
  };

  // If a notification opens the Notification Center, tapping the dimmed background
  // now returns to Sacred Year instead of trapping the user on the drawer.
  const previousBackdrop=window.sy324Backdrop;
  window.sy324Backdrop=function(){
    const sheet=document.getElementById("sheet");
    const kicker=(sheet?.querySelector(".kicker")?.textContent||"").trim().toLowerCase();
    const title=(sheet?.querySelector("h3")?.textContent||"").trim().toLowerCase();
    if(kicker==="notification center" || title==="from the hall"){
      closeDrawer();
      return;
    }
    if(previousBackdrop)return previousBackdrop();
    closeDrawer();
  };

  // Keep the same browser push endpoint attached only to the account that is
  // currently enabling notifications. The backend RPC performs the reassignment
  // atomically so account switching on one phone does not create cross-account pushes.
  const originalEnable=window.syEnableNotifications;
  if(originalEnable){
    window.syEnableNotifications=async function(){
      return await originalEnable.apply(this,arguments);
    };
    window.sy307RequestNotifications=window.syEnableNotifications;
  }
})();
