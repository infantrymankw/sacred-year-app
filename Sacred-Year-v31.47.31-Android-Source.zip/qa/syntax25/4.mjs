
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-app.js";
import {
  getAuth, onAuthStateChanged, createUserWithEmailAndPassword,
  signInWithEmailAndPassword, signOut as firebaseSignOut,
  sendPasswordResetEmail, sendEmailVerification, updatePassword
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-auth.js";
import {
  getFirestore, collection, doc, getDoc, getDocs, setDoc, addDoc,
  updateDoc, deleteDoc, query, where
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";
import {
  getStorage, ref as storageRef, uploadBytes, getDownloadURL, deleteObject
} from "https://www.gstatic.com/firebasejs/12.2.1/firebase-storage.js";

const CFG=window.SACRED_YEAR_CONFIG;
const firebaseApp=initializeApp(CFG.firebase);
const firebaseAuth=getAuth(firebaseApp);
const firebaseDb=getFirestore(firebaseApp);
const firebaseStorage=getStorage(firebaseApp);
window.syStorageUID=()=>firebaseAuth.currentUser?.uid||null;
onAuthStateChanged(firebaseAuth,()=>window.sy25ObserveAccount());

function fbErr(e){return {message:e?.message||String(e||"Unknown Firebase error"),code:e?.code||"firebase/error"}}
function fbUser(u){return u?{id:u.uid,uid:u.uid,email:u.email||"",email_confirmed_at:u.emailVerified?new Date().toISOString():null,user_metadata:{display_name:u.displayName||""},_firebase:u}:null}
function fbSession(u){return u?{user:fbUser(u),access_token:null,provider_token:null}:null}
function normalizeCollection(name){
  if(name==="community_events_public")return "community_events";
  if(name==="community_post_feed")return "community_posts";
  if(name==="community_reply_feed")return "community_replies";
  return name;
}
function deterministicId(name,row){
  if(row?.id)return String(row.id);
  const uid=row?.user_id||row?.id;
  if(["profiles","sacred_year_entitlements","subscription_entitlements","user_preferences","saved_runes","community_organizers","community_user_moderation"].includes(name)&&uid)return String(uid);
  if(name==="bookmarks"&&row?.user_id&&row?.work)return `${row.user_id}_${row.work}`;
  return null;
}
const SY_PRIVATE_TABLES=new Set(['bookmarks','rune_journal_entries','moon_journal_entries','library_favorites','library_notes','saved_rituals','sacred_year_hall_journal','sacred_year_hall_reminders','sacred_year_divination_readings','legal_consents','community_event_rsvps']);
const SY_UID_TABLES=new Set(['saved_runes','user_preferences','sacred_year_entitlements','subscription_entitlements']);
function pickFields(row,fields){
  if(!row||!fields||fields==="*")return row;
  const keys=String(fields).split(",").map(x=>x.trim()).filter(Boolean).map(x=>x.split(/\s+/)[0]).filter(x=>x!=="*");
  if(!keys.length)return row;
  const out={}; for(const k of keys) if(Object.prototype.hasOwnProperty.call(row,k)) out[k]=row[k];
  return out;
}
class FBQueryBuilder{
  constructor(name){this.authScope=window.sy25Scope();this.authUID=firebaseAuth.currentUser?.uid||null;this.originalName=name;this.name=normalizeCollection(name);this.filters=[];this.orders=[];this._limit=null;this._select="*";this._count=null;this._head=false;this.action="read";this.payload=null;this.upsertOpts=null;this.singleMode=null;}
  select(fields="*",opts={}){this._select=fields;this._count=opts?.count||null;this._head=!!opts?.head;return this;}
  eq(field,val){this.filters.push([field,"==",val]);return this;}
  in(field,vals){this.filters.push([field,"in",Array.isArray(vals)?vals:[]]);return this;}
  gte(field,val){this.filters.push([field,">=",val]);return this;}
  lte(field,val){this.filters.push([field,"<=",val]);return this;}
  gt(field,val){this.filters.push([field,">",val]);return this;}
  lt(field,val){this.filters.push([field,"<",val]);return this;}
  ilike(field,val){this.filters.push([field,"ilike",val]);return this;}
  contains(field,val){this.filters.push([field,"array-contains-any-local",val]);return this;}
  match(obj){for(const [k,v] of Object.entries(obj||{}))this.eq(k,v);return this;}
  filter(field,op,val){const map={eq:"==",gte:">=",lte:"<=",gt:">",lt:"<",in:"in"};this.filters.push([field,map[op]||op,val]);return this;}
  order(field,opts={}){this.orders.push([field,opts?.ascending!==false]);return this;}
  limit(n){this._limit=Number(n)||null;return this;}
  insert(payload){this.action="insert";this.payload=payload;return this;}
  upsert(payload,opts={}){this.action="upsert";this.payload=payload;this.upsertOpts=opts;return this;}
  update(payload){this.action="update";this.payload=payload;return this;}
  delete(){this.action="delete";return this;}
  maybeSingle(){this.singleMode="maybe";return this.execute();}
  single(){this.singleMode="single";return this.execute();}
  then(resolve,reject){return this.execute().then(resolve,reject);}
  async _docs(){
    window.sy25Assert(this.authScope);
    if((firebaseAuth.currentUser?.uid||null)!==this.authUID)throw new Error('Account changed. Please try again.');
    if(SY_UID_TABLES.has(this.name)){
      if(!this.authUID)throw new Error('Sign in to access personal data.');
      if(this.filters.some(([f,op,v])=>(f==='id'||f==='user_id')&&(op!=='=='||v!==this.authUID)))throw new Error('Personal data belongs to another account.');
      const snap=await getDoc(doc(firebaseDb,this.name,this.authUID));
      return snap.exists()?[{...snap.data(),id:snap.id}]:[];
    }
    const clauses=[];
    if(this.name==='user_blocks'){
      if(!this.authUID)throw new Error('Sign in to access personal data.');
      if(this.filters.some(([f,op,v])=>f==='blocker_id'&&(op!=='=='||v!==this.authUID)))throw new Error('Personal data belongs to another account.');
      if(!this.filters.some(x=>x[0]==='blocker_id'))clauses.push(where('blocker_id','==',this.authUID));
    }
    if(SY_PRIVATE_TABLES.has(this.name)){
      if(!this.authUID)throw new Error('Sign in to access personal data.');
      if(this.filters.some(([f,op,v])=>f==='user_id'&&(op!=='=='||v!==this.authUID)))throw new Error('Personal data belongs to another account.');
      if(!this.filters.some(x=>x[0]==='user_id'))clauses.push(where('user_id','==',this.authUID));
    }
    for(const [f,op,v] of this.filters){
      if(op==="ilike"||op==="array-contains-any-local")continue;
      if(op==="in"&&(!Array.isArray(v)||!v.length))return [];
      clauses.push(where(f,op,v));
    }
    if(this.originalName==="community_events_public"&&!this.filters.some(x=>x[0]==="status"))clauses.push(where("status","==","approved"));
    if((this.originalName==="community_post_feed"||this.originalName==="community_reply_feed")&&!this.filters.some(x=>x[0]==="is_hidden"))clauses.push(where("is_hidden","==",false));
    const snap=await getDocs(clauses.length?query(collection(firebaseDb,this.name),...clauses):collection(firebaseDb,this.name));
    let rows=snap.docs.map(d=>({...d.data(),id:d.id}));
    if(this.originalName==='community_post_feed'||this.originalName==='community_reply_feed'){
      // A separate status query supports the older approved-post schema.
      const otherFilters=this.filters.filter(([f])=>f!=='is_hidden'&&f!=='status').map(([f,op,v])=>where(f,op,v));
      let approved={docs:[]};
      try{approved=await getDocs(query(collection(firebaseDb,this.name),...otherFilters,where('status','in',['approved','published','visible'])));}catch(e){console.warn('Legacy approved-post query unavailable:',e.code||e.message);}
      rows=[...new Map([...rows,...approved.docs.map(d=>({...d.data(),id:d.id}))].map(r=>[r.id,r])).values()].filter(r=>r.is_hidden!==true);
    }
    if(this.originalName==='community_post_feed'||this.originalName==='community_reply_feed')rows=rows.filter(r=>!r.status||['published','approved','visible'].includes(r.status));
    for(const [f,op,v] of this.filters){
      if(op==="ilike"){
        const needle=String(v??"").replace(/%/g,"").toLowerCase();rows=rows.filter(r=>String(r?.[f]??"").toLowerCase().includes(needle));
      } else if(op==="array-contains-any-local"){
        const vals=Array.isArray(v)?v:[v];rows=rows.filter(r=>Array.isArray(r?.[f])&&vals.every(x=>r[f].includes(x)));
      }
    }
    for(let i=this.orders.length-1;i>=0;i--){const [f,asc]=this.orders[i];rows.sort((a,b)=>{const av=a?.[f],bv=b?.[f];if(av==bv)return 0;if(av==null)return 1;if(bv==null)return -1;return (av>bv?1:-1)*(asc?1:-1)});}
    if(this._limit!=null)rows=rows.slice(0,this._limit);
    return rows;
  }
  async execute(){
    try{
      window.sy25Assert(this.authScope);
      if((firebaseAuth.currentUser?.uid||null)!==this.authUID)throw new Error('Account changed. Please try again.');
      if(this.action==="read"){
        let rows=await this._docs();
        window.sy25Assert(this.authScope);
        if((firebaseAuth.currentUser?.uid||null)!==this.authUID)throw new Error('Account changed. Please try again.');
        const count=rows.length;
        if(this._head)return {data:null,error:null,count};
        rows=rows.map(r=>pickFields(r,this._select));
        if(this.singleMode){
          if(!rows.length)return this.singleMode==="maybe"?{data:null,error:null,count:0}:{data:null,error:fbErr(new Error("No matching document")),count:0};
          if(rows.length>1&&this.singleMode==="single")return {data:null,error:fbErr(new Error("Multiple documents matched")),count:rows.length};
          return {data:rows[0],error:null,count:rows.length};
        }
        return {data:rows,error:null,count};
      }
      if(this.action==="insert"||this.action==="upsert"){
        const input=Array.isArray(this.payload)?this.payload:[this.payload];const out=[];
        for(const original of input){
          const row={...(original||{})};
          if((firebaseAuth.currentUser?.uid||null)!==this.authUID)throw new Error('Account changed. Please try again.');
          if(SY_PRIVATE_TABLES.has(this.name)||SY_UID_TABLES.has(this.name)){
            if(!this.authUID||row.user_id&&row.user_id!==this.authUID)throw new Error('Personal data belongs to another account.');
            row.user_id=this.authUID;
            if(SY_UID_TABLES.has(this.name)&&row.id&&row.id!==this.authUID)throw new Error('Invalid personal document ID.');
          }
          if(this.name==='user_blocks'){
            if(!this.authUID||row.blocker_id&&row.blocker_id!==this.authUID)throw new Error('Personal data belongs to another account.');row.blocker_id=this.authUID;
          }
          if(['community_posts','community_replies','audio_hall_recordings','audio_hall_comments'].includes(this.name)){
            const owner=this.name.startsWith('audio_')?'author_id':'user_id';
            if(!this.authUID||row[owner]&&row[owner]!==this.authUID)throw new Error('Content belongs to another account.');row[owner]=this.authUID;
          }
          if(this.name==='community_posts'||this.name==='community_replies'){
            row.created_at=row.created_at||new Date().toISOString();
            row.is_hidden=row.is_hidden===true;
          }
          let id=deterministicId(this.name,row);
          if(!id&&this.action==="upsert"&&this.upsertOpts?.onConflict){
            const keys=String(this.upsertOpts.onConflict).split(",").map(x=>x.trim()).filter(Boolean);
            if(keys.length&&keys.every(k=>row[k]!=null))id=keys.map(k=>encodeURIComponent(String(row[k]))).join("__");
          }
          if(!id&&this.action==="upsert"&&this.name==="audio_hall_comment_blocks"&&row.recording_id&&row.blocked_user_id)id=`${row.recording_id}__${row.blocked_user_id}`;
          if(id&&(SY_PRIVATE_TABLES.has(this.name))){
            const existing=await getDoc(doc(firebaseDb,this.name,id));window.sy25Assert(this.authScope);
            if(existing.exists()&&existing.data().user_id!==this.authUID)throw new Error('Existing personal data has another or unknown owner.');
          }
          window.sy25Assert(this.authScope);
          if(id){row.id=row.id||id;await setDoc(doc(firebaseDb,this.name,id),row,{merge:this.action==="upsert"});out.push({id,...row});}
          else {const d=await addDoc(collection(firebaseDb,this.name),row);if(!row.id){try{window.sy25Assert(this.authScope);await updateDoc(d,{id:d.id})}catch(_){}}out.push({id:d.id,...row});}
        }
        const selected=out.map(r=>pickFields(r,this._select));
        if(this.singleMode)return {data:selected[0]||null,error:null,count:selected.length};
        return {data:Array.isArray(this.payload)?selected:selected,error:null,count:selected.length};
      }
      if(this.action==="update"||this.action==="delete"){
        const rows=await this._docs();const out=[];
        for(const row of rows){
          window.sy25Assert(this.authScope);
          if((firebaseAuth.currentUser?.uid||null)!==this.authUID)throw new Error('Account changed. Please try again.');
          if((SY_PRIVATE_TABLES.has(this.name)||SY_UID_TABLES.has(this.name))&&this.payload?.user_id&&this.payload.user_id!==this.authUID)throw new Error('Cannot change personal data owner.');
          const d=doc(firebaseDb,this.name,row.id);if(this.action==="delete")await deleteDoc(d);else await updateDoc(d,this.payload||{});out.push(this.action==="delete"?row:{...row,...(this.payload||{})});}
        const selected=out.map(r=>pickFields(r,this._select));
        if(this.singleMode)return {data:selected[0]||null,error:null,count:selected.length};
        return {data:selected,error:null,count:selected.length};
      }
      return {data:null,error:fbErr(new Error("Unsupported Firebase operation"))};
    }catch(e){return {data:null,error:fbErr(e),count:null};}
  }
}
async function ensureFirebaseProfile(u,displayName=""){
  if(!u)return;
  const pr=doc(firebaseDb,"profiles",u.uid);const ps=await getDoc(pr);
  if(!ps.exists())await setDoc(pr,{id:u.uid,display_name:displayName||u.email?.split("@")[0]||"Member",role:"member",created_at:new Date().toISOString()});
  const er=doc(firebaseDb,"sacred_year_entitlements",u.uid);const es=await getDoc(er);
  if(!es.exists())await setDoc(er,{user_id:u.uid,plan:"free",hall_plus_active:false,supporter:false,status:"inactive",capabilities:[],current_period_end:null,created_at:new Date().toISOString()});
}
const supabase={
  auth:{
    async getSession(){const u=firebaseAuth.currentUser;return {data:{session:fbSession(u)},error:null}},
    onAuthStateChange(cb){const unsub=onAuthStateChanged(firebaseAuth,u=>cb(u?"SIGNED_IN":"SIGNED_OUT",fbSession(u)));return {data:{subscription:{unsubscribe:unsub}}}},
    async signUp({email,password,options={}}){try{const c=await createUserWithEmailAndPassword(firebaseAuth,email,password);await ensureFirebaseProfile(c.user,options?.data?.display_name||"");try{await sendEmailVerification(c.user)}catch(_){}return {data:{user:fbUser(c.user),session:fbSession(c.user)},error:null}}catch(e){return {data:{user:null,session:null},error:fbErr(e)}}},
    async signInWithPassword({email,password}){try{const c=await signInWithEmailAndPassword(firebaseAuth,email,password);await ensureFirebaseProfile(c.user);return {data:{user:fbUser(c.user),session:fbSession(c.user)},error:null}}catch(e){return {data:{user:null,session:null},error:fbErr(e)}}},
    async signOut(){try{await firebaseSignOut(firebaseAuth);return {error:null}}catch(e){return {error:fbErr(e)}}},
    async resetPasswordForEmail(email){try{await sendPasswordResetEmail(firebaseAuth,email);return {data:{},error:null}}catch(e){return {data:null,error:fbErr(e)}}},
    async updateUser({password}={}){try{if(!firebaseAuth.currentUser)throw new Error("No signed-in recovery session is available. Use the newest password-reset email link.");if(password)await updatePassword(firebaseAuth.currentUser,password);return {data:{user:fbUser(firebaseAuth.currentUser)},error:null}}catch(e){return {data:null,error:fbErr(e)}}}
  },
  from(name){return new FBQueryBuilder(name)},
  async rpc(name){
    if(name!=="sacred_year_ensure_entitlement")return {data:null,error:fbErr(new Error("Unsupported Firebase RPC: "+name))};
    try{if(firebaseAuth.currentUser)await ensureFirebaseProfile(firebaseAuth.currentUser);return {data:true,error:null}}catch(e){return {data:null,error:fbErr(e)}}
  },
  storage:{
    from(bucket){const base=String(bucket||"").replace(/^\/+|\/+$/g,"");const fullPath=path=>base?`${base}/${String(path||"").replace(/^\/+/,"")}`:String(path||"").replace(/^\/+/,"");return {
      async upload(path,blob,opts={}){try{const objectPath=fullPath(path);const r=storageRef(firebaseStorage,objectPath);await uploadBytes(r,blob,{contentType:opts.contentType||blob?.type||"application/octet-stream"});return {data:{path,fullPath:objectPath},error:null}}catch(e){return {data:null,error:fbErr(e)}}},
      async createSignedUrl(path){try{const url=await getDownloadURL(storageRef(firebaseStorage,fullPath(path)));return {data:{signedUrl:url},error:null}}catch(e){return {data:null,error:fbErr(e)}}},
      async remove(paths){try{for(const p of paths||[])await deleteObject(storageRef(firebaseStorage,fullPath(p)));return {data:paths||[],error:null}}catch(e){return {data:null,error:fbErr(e)}}}
    }}
  },
  functions:{
    async invoke(name,{body={}}={}){
      try{
        const u=firebaseAuth.currentUser;
        if(!u)throw new Error("Sign in before continuing.");
        const token=await u.getIdToken();
        const map={"sacred-year-checkout":"/api/stripe-checkout","sacred-year-portal":"/api/stripe-portal","delete-account":"/api/delete-account"};
        const endpoint=map[name];
        if(!endpoint)throw new Error("Unsupported server function: "+name);
        const headers={"Content-Type":"application/json","Authorization":"Bearer "+token};
        const native=window.Capacitor?.isNativePlatform?.();
        if(native&&name!=="delete-account")throw new Error("Billing is managed separately from the Android companion app.");
        const result=native?await window.Capacitor.Plugins.CapacitorHttp.request({url:"https://www.sacredyear.app"+endpoint,method:"POST",headers,data:body||{}}):null;
        const r=native?{ok:result.status>=200&&result.status<300,status:result.status,json:async()=>typeof result.data==="string"?JSON.parse(result.data):result.data}:await fetch(endpoint,{method:"POST",headers,body:JSON.stringify(body||{})});
        const data=await r.json().catch(()=>({}));
        if(!r.ok)throw new Error(data?.error||("Server request failed ("+r.status+")"));
        return {data,error:null};
      }catch(e){return {data:null,error:fbErr(e)}}
    }
  }
};
window.syFirebase={app:firebaseApp,auth:firebaseAuth,db:firebaseDb,storage:firebaseStorage};
window.syFirebaseOps={collection,doc,getDoc,getDocs,setDoc,addDoc,updateDoc,deleteDoc,query,where};
window.syNativeNotificationAuthReady?.();
window.sySupabase=supabase; // compatibility name retained so the finished UI does not need to be rewritten.
supabaseClient=supabase;
let syUser=null, syProfile=null, syAccessError=null, syUsingCachedAccess=false;
let sySessionCheck=null, syLastAccessFailure=0;
const SY_ACCESS_RETRY_MS=30000, SY_ACCESS_GRACE_MS=7*24*60*60*1000;
const syAccessKey=id=>`sy_verified_access_v1_${id}`;
function syReadAccess(id){
  try{const x=JSON.parse(syLocalStorage.getItem(syAccessKey(id))||"null");return x&&Date.now()-Number(x.verified_at||0)<=SY_ACCESS_GRACE_MS?x:null}catch(_){return null}
}
function syWriteAccess(id,patch){
  try{const old=JSON.parse(syLocalStorage.getItem(syAccessKey(id))||"null")||{};syLocalStorage.setItem(syAccessKey(id),JSON.stringify({...old,...patch,verified_at:Date.now()}))}catch(_){}
}
function syOutageBanner(show){
  let bar=document.getElementById("syOutageBanner");
  if(!bar){
    bar=document.createElement("div");bar.id="syOutageBanner";
    bar.style.cssText="display:none;position:sticky;top:0;z-index:10000;padding:calc(10px + env(safe-area-inset-top, 0px)) 14px 10px;background:#5b2b20;color:#fff4df;border-bottom:1px solid #c58b55;text-align:center;font:600 14px/1.35 system-ui";
    bar.innerHTML='Online services are temporarily unavailable. Your account and purchases are safe. Bundled Sacred Year content remains available. <button id="syOutageRetry" style="margin-left:8px;padding:5px 10px;border:1px solid #e3bd80;border-radius:8px;background:#24130d;color:#fff4df">Try again</button>';
    document.body.prepend(bar);
    bar.querySelector("#syOutageRetry").onclick=async()=>{syLastAccessFailure=0;await syRefresh()};
  }
  bar.style.display=show?"block":"none";
}
const syCachedEntitlements=id=>syReadAccess(id)?.entitlements||null;
const syEsc=s=>String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));

async function syGetSession(){
  if(sySessionCheck)return sySessionCheck;
  sySessionCheck=(async()=>{
    const scope=window.sy25Scope();
    const {data}=await supabase.auth.getSession();
    window.sy25Assert(scope);
    syUser=data.session?.user||null;syProfile=null;syAccessError=null;syUsingCachedAccess=false;
    if(!syUser){syOutageBanner(false);return}
    const accessUID=syUser.id;
    const cached=syReadAccess(accessUID);
    if(cached&&Date.now()-syLastAccessFailure<SY_ACCESS_RETRY_MS){
      syProfile=cached.profile||null;syUsingCachedAccess=true;syAccessError="Online account verification is temporarily unavailable.";syOutageBanner(true);return;
    }
    // Firebase-native direct document read. Profiles use the Firebase UID as the
    // document ID, so reading the exact document avoids collection-query edge cases.
    try{
      const profileSnap=await getDoc(doc(firebaseDb,"profiles",accessUID));
      window.sy25Assert(scope);
      if(firebaseAuth.currentUser?.uid!==accessUID)return;
      syProfile=profileSnap.exists()?{id:profileSnap.id,...profileSnap.data()}:null;
      if(syProfile){
        syWriteAccess(syUser.id,{profile:syProfile});
        syLastAccessFailure=0;
        syOutageBanner(false);
      }else{
        syAccessError="Your Sacred Year profile could not be found.";
        syOutageBanner(false);
      }
    }catch(e){
      if(firebaseAuth.currentUser?.uid!==accessUID)return;
      syLastAccessFailure=Date.now();
      syAccessError=e?.message||"Account access could not be verified.";
      if(cached?.profile){syProfile=cached.profile;syUsingCachedAccess=true}
      syOutageBanner(true);
    }
  })();
  try{await sySessionCheck}finally{sySessionCheck=null}
}
async function syHeader(){
  await syGetSession();
  const b=document.getElementById("accountBtn");
  if(b)b.textContent=syUser?(syProfile?.role==="creator"?"Creator":"Account"):"Account";
}
const SY_CAPABILITIES={
  advanced_journal:"Advanced journal organization & search",
  cloud_backup:"Richer cross-device cloud backup",
  yearbook:"Personal Sacred Year annual Yearbook",
  advanced_reminders:"Advanced reminder schedules",
  expanded_study:"Expanded study collections & guided seasonal deep-dives",
  circle_tools:"Circle/organizer tools for groups"
};
async function syEnsureEntitlement(){
  if(!syUser)return null;
  try{
    const {error}=await supabase.rpc("sacred_year_ensure_entitlement");
    if(error){console.warn("Sacred Year entitlement setup:",error.message);return null;}
    return true;
  }catch(e){console.warn("Sacred Year entitlement setup:",e);return null;}
}
async function syGetEntitlements(){
  await syGetSession();
  const base={plan:"free",hall_plus:false,supporter:false,status:"inactive",capabilities:[]};
  if(!syUser)return base;
  const accessUID=syUser.id;
  const cached=syCachedEntitlements(accessUID);
  const creatorEnt={plan:"creator",hall_plus:true,supporter:!!cached?.supporter,status:"active",capabilities:["all_hall_plus"],current_period_end:null,creator_access:true};
  if(syUsingCachedAccess)return syProfile?.role==="creator"?creatorEnt:(cached||base);
  try{
    await syEnsureEntitlement();
    if(firebaseAuth.currentUser?.uid!==accessUID)return base;
    // Firebase-native direct entitlement read. The entitlement document ID is the
    // Firebase UID. hall_plus_active is the authoritative Hall+ unlock flag.
    const entSnap=await getDoc(doc(firebaseDb,"sacred_year_entitlements",accessUID));
    if(firebaseAuth.currentUser?.uid!==accessUID)return base;
    const data=entSnap.exists()?entSnap.data():null;
    if(syProfile?.role==="creator"){
      syWriteAccess(syUser.id,{entitlements:creatorEnt});
      syLastAccessFailure=0;syOutageBanner(false);
      return creatorEnt;
    }
    const ent=data?{
      plan:String(data.plan||"free").toLowerCase(),
      hall_plus:data.hall_plus_active===true,
      supporter:data.supporter===true,
      status:String(data.status||"inactive").toLowerCase(),
      capabilities:Array.isArray(data.capabilities)?data.capabilities:[],
      current_period_end:data.current_period_end||null
    }:base;
    syWriteAccess(syUser.id,{entitlements:ent});
    syLastAccessFailure=0;syAccessError=null;syOutageBanner(false);
    return ent;
  }catch(e){
    if(firebaseAuth.currentUser?.uid!==accessUID)return base;
    syAccessError=e?.message||"Online access is temporarily unavailable.";syLastAccessFailure=Date.now();syOutageBanner(true);
    return syProfile?.role==="creator"?creatorEnt:(cached||base);
  }
}
async function syHasCapability(cap){
  const e=await syGetEntitlements();
  return e.hall_plus && (e.capabilities.includes(cap)||e.capabilities.includes("all_hall_plus"));
}
window.syEnsureEntitlement=syEnsureEntitlement;
window.syGetEntitlements=syGetEntitlements;
window.syHasCapability=syHasCapability;

async function syOpenAccount(){
  await syGetSession();
  if(!syUser){
    openDrawer(`<div class="kicker">Sacred Year Account</div><h3>Sign in or create an account</h3>
    <label>Email</label><input id="syEmail" type="email" autocomplete="email"/>
    <label>Password</label><input id="syPass" type="password" autocomplete="current-password" placeholder="At least 8 characters"/>
    <label>Display name</label><input id="syName" placeholder="Only needed when creating an account"/>
    <div class="row" style="margin-top:14px"><button class="btn secondary" id="syLogin">Sign in</button><button class="btn" id="syCreate">Create account</button></div>
    <button class="btn secondary" style="margin-top:10px" id="syForgot">Forgot password?</button>
    <p class="note">Connected to Firebase Authentication and Cloud Firestore.</p>`);
    document.getElementById("syCreate").onclick=syRegister;
    document.getElementById("syLogin").onclick=syLogin;
    document.getElementById('syPass').setAttribute('enterkeyhint','go');
    for(const id of ['syEmail','syPass'])document.getElementById(id).addEventListener('keydown',e=>{
      if(e.key==='Enter'&&!e.isComposing){e.preventDefault();document.getElementById('syLogin')?.click();}
    });
    document.getElementById("syForgot").onclick=syForgotPassword;
    return;
  }
  if(syAccessError&&!syProfile){
    openDrawer(`<div class="kicker">Online services temporarily unavailable</div><h3>${syEsc(syUser.email)}</h3>
    <div class="notice warn"><b>Sacred Year cannot verify this account right now.</b><br>Your account and purchases are safe. Bundled reading and practice content remains available.</div>
    <button class="btn secondary" id="syRetryAccess">Try again</button>
    <button class="btn danger" style="margin-top:10px" id="syOut">Sign out</button>`);
    document.getElementById("syRetryAccess").onclick=()=>{syLastAccessFailure=0;syOpenAccount()};
    document.getElementById("syOut").onclick=sySignOut;
    return;
  }
  const creator=syProfile?.role==="creator";
  const ent=await syGetEntitlements();
  const planLabel=creator?"Creator + Hall+":(ent.hall_plus?"Hall+":"Free");
  openDrawer(`<div class="kicker">${creator?"Creator Account":"My Account"}</div><h3>${syEsc(syProfile?.display_name||syUser.email)}</h3><p>${syEsc(syUser.email)}</p>
  ${syUsingCachedAccess?'<div class="notice warn"><b>Offline account mode.</b> Showing access last verified on this device. Online changes are temporarily disabled.</div>':""}
  <div class="account-grid" style="margin:14px 0">
    <div class="account-card"><div class="kicker">Plan</div><h4>${planLabel}</h4><p>${creator?"Full creator and Hall+ tool access.":(ent.hall_plus?"Hall+ access is active.":"Core Sacred Year access.")}</p></div>
    <div class="account-card"><div class="kicker">Voluntary Support</div><h4>${ent.supporter?"Supporter":"Optional contribution"}</h4><p>${ent.supporter?"Thank you for helping keep the Hall burning. You can contribute again anytime.":"Optional support is separate from Hall+ and does not affect access."}</p><button class="btn secondary" style="margin-top:10px" id="sySupportDonate">Make a voluntary contribution</button></div>
  </div>
  ${creator&&!syUsingCachedAccess?'<button class="btn" id="syCreator">Open Creator Dashboard</button>':""}
  ${syUsingCachedAccess?"":'<button class="btn secondary" style="margin-top:10px" id="syPlan">Hall+ & Support</button>'}
  <button class="btn secondary" style="margin-top:10px" id="syPrefs">Practice & notifications</button>
  <button class="btn danger" style="margin-top:10px" id="syOut">Sign out</button>`);
  if(creator&&!syUsingCachedAccess)document.getElementById("syCreator").onclick=syOpenCreator;
  if(!syUsingCachedAccess)document.getElementById("syPlan").onclick=syOpenHallPlus;
  if(!syUsingCachedAccess)document.getElementById("sySupportDonate").onclick=sy307Donate;else document.getElementById("sySupportDonate").disabled=true;
  document.getElementById("syPrefs").onclick=syOpenPreferences;
  document.getElementById("syOut").onclick=sySignOut;
}
window.syOpenAccount=syOpenAccount;
window.openAccount=syOpenAccount;

async function syRegister(){
  const email=document.getElementById("syEmail").value.trim();
  const password=document.getElementById("syPass").value;
  const displayName=document.getElementById("syName").value.trim();
  if(password.length<8){alert("Use at least 8 characters.");return}
  const {data,error}=await supabase.auth.signUp({email,password,options:{data:{display_name:displayName}}});
  if(error){alert(error.message);return}
  alert(data.session?"Account created and signed in.":"Account created. Check your email if verification is enabled.");
  closeDrawer();
  setTimeout(()=>syRefresh().catch(()=>{}),0);
}
let syLoginBusy=false;
async function syLogin(){
  if(syLoginBusy)return;
  const emailInput=document.getElementById("syEmail"),passwordInput=document.getElementById("syPass");
  if(!emailInput.value.trim()||!emailInput.validity.valid){alert("Enter a valid email address.");emailInput.focus();return}
  if(!passwordInput.value){alert("Enter your password.");passwordInput.focus();return}
  syLoginBusy=true;
  const {error}=await supabase.auth.signInWithPassword({
    email:document.getElementById("syEmail").value.trim(),
    password:document.getElementById("syPass").value
  });
  syLoginBusy=false;
  if(error){alert(error.message);return}
  closeDrawer();
  setTimeout(()=>syRefresh().catch(()=>{}),0);
}
async function syForgotPassword(){
  const email=document.getElementById("syEmail")?.value.trim();
  if(!email){alert("Enter your email address first.");return}
  const {error}=await supabase.auth.resetPasswordForEmail(email,{redirectTo:window.location.origin});
  if(error){alert(error.message);return}
  alert("Password reset email sent. Check your inbox.");
}
window.syForgotPassword=syForgotPassword;

async function sySignOut(){await supabase.auth.signOut();closeDrawer();await syRefresh();}

async function syOpenCreator(){
  await syGetSession();
  if(syProfile?.role!=="creator"){alert("Creator access is not enabled for this account.");return}
  let reportCount=0,pendingCount=0;
  try{
    const [cr,mr,er,pe]=await Promise.all([
      supabase.from("community_reports").select("id",{count:"exact",head:true}).eq("status","open"),
      supabase.from("moderation_reports").select("id",{count:"exact",head:true}).in("status",["submitted","open"]),
      supabase.from("community_event_reports").select("id",{count:"exact",head:true}).eq("status","open"),
      supabase.from("community_events").select("id",{count:"exact",head:true}).eq("status","pending")
    ]);
    reportCount=(cr.count||0)+(mr.count||0)+(er.count||0);
    pendingCount=pe.count||0;
  }catch(e){}
  openDrawer(`<div class="kicker">Private Creator Dashboard</div><h3>Creator Control Center</h3>
  <p class="note">Publish Sacred Year content and manage the Community Hall from one place.</p>
  <div class="sy321-grid">
    <button class="sy321-card" id="sy324PublishCard"><div class="kicker">Publish</div><h4>Words from the Hall</h4><p>Create a new reflection, historical note, practice post, or announcement.</p></button>
    <button class="sy321-card" id="sy324ManageCard"><div class="kicker">Content</div><h4>Manage Published Content</h4><p>Edit or remove Words from the Hall posts you have already published.</p></button>
    <button class="sy321-card" id="sy324ModerationCard"><div class="kicker">Moderation</div><h4>Moderation Center</h4><p>${reportCount} open report${reportCount===1?"":"s"} • ${pendingCount} pending event${pendingCount===1?"":"s"}</p></button>
    <button class="sy321-card" id="sy324AudioCard"><div class="kicker">Hall+ Audio</div><h4>Manage Hall+ Recordings</h4><p>Review pending recordings, listen, edit details, publish or reject submissions, manage discussion settings, and remove recordings.</p></button>
  </div>
  <button class="btn secondary" id="sy324BackAccount">Back to account</button>`);
  requestAnimationFrame(()=>{
    document.getElementById("sy324PublishCard")?.addEventListener("click",()=>window.sy321OpenPublisher?.());
    document.getElementById("sy324ManageCard")?.addEventListener("click",()=>window.sy322CreatorPosts?.());
    document.getElementById("sy324ModerationCard")?.addEventListener("click",()=>window.sy321ModerationHome?.());
    document.getElementById("sy324AudioCard")?.addEventListener("click",()=>window.syOpenCreatorAudioManager?.());
    document.getElementById("sy324BackAccount")?.addEventListener("click",()=>openAccount());
  });
}
async function syPublish(){
  const message=document.getElementById("syPM").value.trim();
  if(!message){alert("Write a message first.");return}
  const row={author_id:syUser.id,title:document.getElementById("syPT").value.trim()||"Words from the Hall",message,label:document.getElementById("syPL").value,status:"published",send_notification:document.getElementById("syPN").checked,published_at:new Date().toISOString()};
  const {data,error}=await supabase.from("creator_posts").insert(row).select().single();
  if(error){alert(error.message);return}
  if(row.send_notification)try{await window.syPushSendCreatorPost(data.id);}catch(e){alert("Post published, but push failed: "+(e?.message||e));}
  closeDrawer();await syLoadWord();alert("Published to Sacred Year.");
}
async function syOpenPreferences(){
  await syGetSession();if(!syUser)return syOpenAccount();
  let {data:p}=await supabase.from("user_preferences").select("*").eq("user_id",syUser.id).maybeSingle();
  p=p||{tradition:"broad",notify_holidays:true,notify_moon:true,notify_words:true,notify_rituals:false};
  openDrawer(`<div class="kicker">Practice Settings</div><h3>Personalize the Hall</h3>
  <label>Tradition emphasis</label><select id="syTradition">
  <option value="broad" ${p.tradition==="broad"?"selected":""}>Broad Germanic/Norse</option>
  <option value="norse" ${p.tradition==="norse"?"selected":""}>Norse/Icelandic</option>
  <option value="anglo_saxon" ${p.tradition==="anglo_saxon"?"selected":""}>Anglo-Saxon</option>
  <option value="continental" ${p.tradition==="continental"?"selected":""}>Continental Germanic</option></select>
  <label><input id="syNH" type="checkbox" ${p.notify_holidays?"checked":""} style="width:auto;margin-right:7px">Sacred-day reminders</label>
  <label><input id="syNM" type="checkbox" ${p.notify_moon?"checked":""} style="width:auto;margin-right:7px">Moon-phase reminders</label>
  <label><input id="syNW" type="checkbox" ${p.notify_words?"checked":""} style="width:auto;margin-right:7px">Words from the Hall</label>
  <label><input id="syNR" type="checkbox" ${p.notify_rituals?"checked":""} style="width:auto;margin-right:7px">Ritual reminders</label>
  <button class="btn" style="margin-top:14px" id="sySaveP">Save</button>`);
  document.getElementById("sySaveP").onclick=sySavePreferences;
}
async function sySavePreferences(){
  const {error}=await supabase.from("user_preferences").upsert({
    user_id:syUser.id,tradition:document.getElementById("syTradition").value,
    notify_holidays:document.getElementById("syNH").checked,notify_moon:document.getElementById("syNM").checked,
    notify_words:document.getElementById("syNW").checked,notify_rituals:document.getElementById("syNR").checked,updated_at:new Date().toISOString()
  });
  if(error){alert(error.message);return}
  closeDrawer();alert("Preferences saved.");
}
async function syLoadWord(){
  const box=document.getElementById("latestWord");if(!box)return;
  const {data}=await supabase.from("creator_posts").select("title,message,label,published_at").eq("status","published").order("published_at",{ascending:false}).limit(1);
  if(data?.length){const p=data[0];box.innerHTML=`<div class="kicker">${syEsc(p.label)}</div><h4>${syEsc(p.title)}</h4><p>${syEsc(p.message)}</p><p class="note">${syDisplayDate(p.published_at)}</p>`;}
  else box.innerHTML='<div class="kicker">Words from the Hall</div><p class="note">No creator message has been published yet.</p>';
}
window.saveRune=async function(jsonString){
 const syAccountScope=window.sy25Scope();

  const r=JSON.parse(jsonString);syLocalStorage.setItem("sy_saved_rune",JSON.stringify(r));await window.sy25Await((window.sy25Assert(syAccountScope), (syGetSession())),syAccountScope);
  if(syUser)await window.sy25Await((window.sy25Assert(syAccountScope), (supabase.from("saved_runes").upsert({user_id:syUser.id,rune:r[1],rune_symbol:r[0],keywords:r[2],saved_at:new Date().toISOString()}))),syAccountScope);
  closeDrawer();syPersonal();alert(`${r[1]} saved.`);
};
window.saveReaderPlace=async function(){
 const syAccountScope=window.sy25Scope();

  const b={work:currentBook,title:currentBookData().title,position:{scrollTop:reader.scrollTop},saved_at:new Date().toISOString()};
  syLocalStorage.setItem("sy_reader_bookmark",JSON.stringify(b));await window.sy25Await((window.sy25Assert(syAccountScope), (syGetSession())),syAccountScope);
  if(syUser)await window.sy25Await((window.sy25Assert(syAccountScope), (supabase.from("bookmarks").upsert({user_id:syUser.id,work:currentBook,position:b.position,saved_at:b.saved_at},{onConflict:"user_id,work"}))),syAccountScope);
  updateContinueReading();syPersonal();alert(`${currentBookData().title} reading place saved.`);
};
async function syPull(){
 const syAccountScope=window.sy25Scope();

 const syLocalStorage=window.syLocalStorage.forUser(window.syStorageUID?.());
  await window.sy25Await((window.sy25Assert(syAccountScope), (syGetSession())),syAccountScope);if(!syUser)return;
  const uid=syUser.id;
  const {data:r,error:rError}=await window.sy25Await((window.sy25Assert(syAccountScope), (supabase.from("saved_runes").select("*").eq("user_id",uid).maybeSingle())),syAccountScope);
  if(!r&&!rError)syLocalStorage.removeItem("sy_saved_rune");
  if(r)syLocalStorage.setItem("sy_saved_rune",JSON.stringify([r.rune_symbol,r.rune,r.keywords]));
  const {data:b}=await window.sy25Await((window.sy25Assert(syAccountScope), (supabase.from("bookmarks").select("work,position,saved_at").eq("user_id",uid).order("saved_at",{ascending:false}).limit(1))),syAccountScope);
  if(Array.isArray(b)&&!b.length)syLocalStorage.removeItem("sy_reader_bookmark");
  if(b?.length){const x=b[0];syLocalStorage.setItem("sy_reader_bookmark",JSON.stringify({work:x.work,title:libraryBooks[x.work]?.title||x.work,position:x.position,saved_at:x.saved_at}));}
}
function syPersonal(){
  const r=JSON.parse(syLocalStorage.getItem("sy_saved_rune")||"null"),b=JSON.parse(syLocalStorage.getItem("sy_reader_bookmark")||"null");
  const rt=document.getElementById("savedRuneText"),bt=document.getElementById("savedReadingText");
  if(rt)rt.textContent=r?`${r[0]} ${r[1]} — ${r[2]}`:"None saved.";
  if(bt)bt.textContent=b?`${b.title||b.work} bookmark saved.`:"No bookmark.";
  if(typeof updateContinueReading==="function")updateContinueReading();
}
async function syRefresh(){await syHeader();await syPull();syPersonal();await syLoadWord();}
// v31.33: defer auth-dependent work so the triggering auth promise can settle,
// then repaint the account state without waiting for another interaction.
supabase.auth.onAuthStateChange((_event,session)=>{
  user=session?.user||null;syUser=user;syProfile=null;syUsingCachedAccess=false;sySessionCheck=null;
  setTimeout(async()=>{
    await syRefresh();
    if(syUser)await syEnsureEntitlement();
  },0);
});
await syRefresh();
await syGetSession();if(syUser)await syEnsureEntitlement();
