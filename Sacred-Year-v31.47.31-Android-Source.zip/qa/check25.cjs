const fs=require('fs'),cp=require('child_process');
const html=fs.readFileSync('android-project/www/index.html','utf8');
fs.mkdirSync('qa/syntax25',{recursive:true});let count=0;
for(const m of html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)){
 if(/type=["']text\/plain/.test(m[1])||!m[2].trim()||/application\/(ld\+)?json/.test(m[1]))continue;
 const file='qa/syntax25/'+count+(/type=["']module/.test(m[1])?'.mjs':'.js');fs.writeFileSync(file,m[2]);
 const r=cp.spawnSync(process.execPath,['--check',file],{encoding:'utf8'});if(r.status)throw Error(r.stderr);count++;
}
console.log('PASS: '+count+' inline JavaScript blocks parse.');
