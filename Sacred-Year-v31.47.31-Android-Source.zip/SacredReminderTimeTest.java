package com.alanwolfsie.sacredyear;
import java.util.*;
public class SacredReminderTimeTest {
 static long at(int y,int m,int d,int hour){Calendar c=Calendar.getInstance();c.clear();c.set(y,m-1,d,hour,0);return c.getTimeInMillis();}
 static void equal(long a,long b){if(a!=b)throw new AssertionError(new Date(a)+" != "+new Date(b));}
 public static void main(String[] args){
  TimeZone.setDefault(TimeZone.getTimeZone("America/New_York"));
  equal(SacredReminderTime.next(at(2026,1,31,9),"monthly",at(2026,2,1,9)),at(2026,2,28,9));
  equal(SacredReminderTime.next(at(2026,1,31,9),"monthly",at(2026,3,1,9)),at(2026,3,31,9));
  equal(SacredReminderTime.next(at(2024,2,29,9),"yearly",at(2025,1,1,9)),at(2025,2,28,9));
  equal(SacredReminderTime.next(at(2026,3,7,9),"daily",at(2026,3,7,10)),at(2026,3,8,9));
  equal(SacredReminderTime.next(at(2026,1,1,9),"none",at(2026,1,1,10)),-1);
  equal(SacredReminderTime.next(at(2026,1,1,9),"weekly",at(2026,1,1,10)),at(2026,1,8,9));
  System.out.println("PASS: monthly anchor, leap year, DST local time, one-shot expiry, weekly recurrence.");
 }
}
