package com.alanwolfsie.sacredyear;

import android.Manifest;
import android.os.Build;
import android.content.Intent;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import androidx.core.app.NotificationCompat;
import android.provider.Settings;
import androidx.core.app.NotificationManagerCompat;
import com.getcapacitor.*;
import com.getcapacitor.annotation.*;
import org.json.JSONArray;
import org.json.JSONObject;

@CapacitorPlugin(name="SacredNotifications", permissions=@Permission(alias="notifications", strings={Manifest.permission.POST_NOTIFICATIONS}))
public class SacredNotificationsPlugin extends Plugin {
    private boolean trusted(PluginCall call) {
        String url=getBridge().getWebView().getUrl();
        if (url==null || !AudioOriginPolicy.trusted(url)) { call.reject("Untrusted origin"); return false; }
        return true;
    }
    private void status(PluginCall call) {
        SacredReminderReceiver.channel(getContext());
        JSObject result=new JSObject();
        result.put("granted",SacredReminderReceiver.allowed(getContext()));
        result.put("scheduled",SacredReminderReceiver.read(getContext()).length());
        call.resolve(result);
    }
    @PluginMethod public void check(PluginCall call) {
        getActivity().runOnUiThread(() -> { if(trusted(call))status(call); 
        });
    }
    @PluginMethod public void enable(PluginCall call) {
        getActivity().runOnUiThread(() -> {
        if(!trusted(call))return;
        if(Build.VERSION.SDK_INT>=33 && getPermissionState("notifications")!=PermissionState.GRANTED) requestPermissionForAlias("notifications",call,"permissionResult");
        else status(call);
    
        });
    }
    @PermissionCallback private void permissionResult(PluginCall call) { if(trusted(call))status(call); }
    @PluginMethod public void settings(PluginCall call) {
        getActivity().runOnUiThread(() -> {
        if(!trusted(call))return;
        Intent intent=new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getContext().getPackageName());
        if(Build.VERSION.SDK_INT<26)intent=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+getContext().getPackageName()));
        getActivity().startActivity(intent);call.resolve();
    
        });
    }
    @PluginMethod public void show(PluginCall call) {
        getActivity().runOnUiThread(() -> {
        if(!trusted(call))return;
        if(!SacredReminderReceiver.allowed(getContext())){call.reject("Allow notifications in Android Settings first.");return;}
        String id=call.getString("id","activity");
        String title=call.getString("title","Sacred Year");
        String body=call.getString("body","");
        if(title.length()>200)title=title.substring(0,200);
        if(body.length()>1000)body=body.substring(0,1000);
        SacredReminderReceiver.show(getContext(),id,title,body,"");call.resolve();
        });
    }
    @PluginMethod public void consumeReminderTap(PluginCall call) {
        getActivity().runOnUiThread(() -> {
            if(!trusted(call))return;
            Intent intent=getActivity().getIntent();
            boolean tapped=intent!=null&&intent.getBooleanExtra("sacred_reminder_tap",false);
            String eventId=tapped?intent.getStringExtra("sacred_event_id"):null;
            if(tapped){intent.removeExtra("sacred_reminder_tap");intent.removeExtra("sacred_event_id");}
            JSObject result=new JSObject();result.put("tapped",tapped);if(eventId!=null)result.put("eventId",eventId);call.resolve(result);
        });
    }
    @PluginMethod public void consumePushTap(PluginCall call) {
        getActivity().runOnUiThread(() -> {
            if(!trusted(call))return;
            Intent intent=getActivity().getIntent();
            boolean tapped=intent!=null&&intent.getBooleanExtra("sacred_push_tap",false);
            if(tapped)intent.removeExtra("sacred_push_tap");
            JSObject result=new JSObject();result.put("tapped",tapped);call.resolve(result);
        });
    }
    @PluginMethod public void showPush(PluginCall call) {
        getActivity().runOnUiThread(() -> {
            if(!trusted(call))return;
            if(!NotificationManagerCompat.from(getContext()).areNotificationsEnabled()){call.reject("Android notifications are off.");return;}
            String title=call.getString("title","Sacred Year"),body=call.getString("body","");
            String id=call.getString("id","push");
            if(title.length()>200)title=title.substring(0,200);
            if(body.length()>1000)body=body.substring(0,1000);
            Intent open=new Intent(getContext(),MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("sacred_push_tap",true);
            PendingIntent tap=PendingIntent.getActivity(getContext(),id.hashCode(),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            NotificationCompat.Builder notification=new NotificationCompat.Builder(getContext(),"sacred_year_push").setSmallIcon(R.drawable.ic_notification).setContentTitle(title).setContentText(body).setContentIntent(tap).setAutoCancel(true).setVisibility(NotificationCompat.VISIBILITY_PRIVATE);
            try{NotificationManagerCompat.from(getContext()).notify(id,2,notification.build());call.resolve();}catch(SecurityException e){call.reject("Android notifications are off.",e);}
        });
    }
    @PluginMethod public void test(PluginCall call) {
        getActivity().runOnUiThread(() -> {
        if(!trusted(call))return;
        if(!SacredReminderReceiver.allowed(getContext())){call.reject("Allow notifications in Android Settings first.");return;}
        SacredReminderReceiver.show(getContext(),"test","Sacred Year","Notifications are working on this phone.","");call.resolve();
    
        });
    }
    @PluginMethod public void sync(PluginCall call) {
        getActivity().runOnUiThread(() -> {
        if(!trusted(call))return;
        try{
            JSONArray rows=call.getArray("reminders",new JSArray());
            if(rows.length()>200){call.reject("Too many reminders");return;}
            JSONArray clean=new JSONArray();
            for(int i=0;i<rows.length();i++){
                JSONObject row=rows.getJSONObject(i);String id=row.optString("id");long at=row.optLong("at");
                if(id.isEmpty()||id.length()>200||at<=0||!row.optBoolean("enabled",true))continue;
                JSONObject item=new JSONObject();item.put("id",id);item.put("at",at);item.put("title",row.optString("title","Sacred Year reminder").substring(0,Math.min(200,row.optString("title","Sacred Year reminder").length())));
                item.put("repeat",row.optString("repeat","none"));
                String eventId=row.optString("eventId","");if(!eventId.isEmpty()&&eventId.length()<=200)item.put("eventId",eventId);
                String body=row.optString("body","");if(!body.isEmpty())item.put("body",body.substring(0,Math.min(1000,body.length())));
                clean.put(item);
            }
            SacredReminderReceiver.replace(getContext(),clean);status(call);
        }catch(Exception e){call.reject("Could not schedule reminders",e);}
    
        });
    }
}
