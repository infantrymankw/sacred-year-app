(function(){
  if(!window.Capacitor?.isNativePlatform?.())return;
  const push=window.Capacitor.Plugins.PushNotifications;
  const native=window.Capacitor.Plugins.SacredNotifications;
  if(!push)return;
  const ENDPOINT='https://sacred-year-push-service.vercel.app/api/push';
  let token=null,uid=null,revision=0,registered='',authAttached=false;
  const user=()=>window.syFirebase?.auth?.currentUser||null;
  async function request(action,fields){
    const current=user();
    if(!current)throw new Error('Sign in before using push notifications.');
    const idToken=await current.getIdToken();
    if(user()?.uid!==current.uid)throw new Error('Account changed. Try again.');
    const response=await fetch(ENDPOINT,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+idToken},body:JSON.stringify({action,...fields})});
    let result={};try{result=await response.json();}catch(_){}
    if(!response.ok||result?.error)throw new Error(result?.error||'Push service returned '+response.status+'.');
    return result;
  }
  async function registerToken(){
    const current=user(),generation=revision;
    if(!current||!token)return;
    const key=current.uid+':'+token;
    if(registered===key)return;
    await request('register',{token,platform:'android'});
    if(generation===revision&&user()?.uid===current.uid)registered=key;
  }
  async function start(){
    const current=user();
    if(!current){uid=null;registered='';return;}
    if(uid!==current.uid){uid=current.uid;registered='';revision++;}
    try{
      const status=await push.checkPermissions();
      const permission=status.receive==='prompt'?await push.requestPermissions():status;
      if(permission.receive==='granted')await push.register();
      if(token)await registerToken();
    }catch(e){console.warn('Push registration unavailable:',e?.message||e);}
    consumeTap();
  }
  async function consumeTap(){
    try{if((await native?.consumePushTap?.())?.tapped)routeTap();}catch(_){}
  }
  function routeTap(){
    let attempts=0;const retry=()=>{if(user()&&typeof window.sy25Activity==='function')window.sy25Activity();else if(++attempts<40)setTimeout(retry,500);};
    retry();
  }
  window.syPushEnsureRegistered=start;
  window.syPushSendCreatorPost=async function(postId){
    if(!postId)throw new Error('The published post has no ID.');
    return request('send_creator_post',{post_id:postId,postId});
  };
  push.addListener('registration',event=>{if(token!==event.value){token=event.value;registered='';}registerToken().catch(e=>console.warn('Push device registration failed:',e?.message||e));});
  push.addListener('registrationError',error=>console.warn('FCM token unavailable:',error));
  push.addListener('pushNotificationReceived',event=>{
    const title=event.title||event.notification?.title||'Sacred Year';
    const body=event.body||event.notification?.body||'';
    const postId=event.data?.post_id||event.data?.postId||event.data?.reference_id;
    try{
      const store=window.syLocalStorage?.forUser?.(user()?.uid);
      if(postId&&store){const seen=new Set(JSON.parse(store.getItem('activity_native_seen')||'[]'));seen.add('creator_post:'+postId);store.setItem('activity_native_seen',JSON.stringify([...seen].slice(-500)));}
    }catch(_){}
    native?.showPush?.({id:String(event.id||Date.now()),title,body}).catch(e=>console.warn('Foreground push alert unavailable:',e?.message||e));
    window.sy25RefreshActivity?.();
  });
  push.addListener('pushNotificationActionPerformed',()=>routeTap());
  function attachAuth(){
    if(authAttached||!window.syFirebase?.auth)return false;
    authAttached=true;
    window.syFirebaseCompat?.auth?.onAuthStateChange?.(()=>start());
    start();return true;
  }
  const timer=setInterval(()=>{if(attachAuth())clearInterval(timer);},300);
  window.addEventListener('focus',()=>{start();consumeTap();});
  window.addEventListener('sy-push-tap',routeTap);
})();
